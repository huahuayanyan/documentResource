package com.huateng.scf.bas.mrn.model;

public class ExtInterface extends BMrnAcctBussInfo{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String txnCode;

	public String getTxnCode() {
		return txnCode;
	}

	public void setTxnCode(String txnCode) {
		this.txnCode = txnCode;
	}
	
}
