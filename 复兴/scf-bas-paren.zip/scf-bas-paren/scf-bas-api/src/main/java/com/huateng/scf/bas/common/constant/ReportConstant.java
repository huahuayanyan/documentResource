package com.huateng.scf.bas.common.constant;

public class ReportConstant {
	/*****报表参数 start*****/
	public static final String P_INPUTDATE = "p_inputdate"; // 输入日期
	public static final String BRCODE = "p_brcode"; // 机构号
	public static final String YEAR = "p_year"; // 年
	public static final String QUARTER = "p_quarter"; // 季度

	


}
