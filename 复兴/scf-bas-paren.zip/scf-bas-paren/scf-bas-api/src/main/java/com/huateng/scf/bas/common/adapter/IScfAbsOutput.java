/**
 * 
 */
package com.huateng.scf.bas.common.adapter;

/**
 * <p>
 * 	供应链统一输出对象抽象接口
 * </p>
 *
 * @author huangshuidan
 * @date 2017年5月19日下午4:44:26
 * @version 1.0
 * @Copyright Shanghai Huateng Software Systems Co., Ltd.
 *
 * <pre>
 * =================Modify Record=======================
 * Modifier			   date			              Content
 * huangshuidan		   2017年5月19日下午4:44:26             新增
 *
 * </pre>
 */
public interface IScfAbsOutput<E> {

}
