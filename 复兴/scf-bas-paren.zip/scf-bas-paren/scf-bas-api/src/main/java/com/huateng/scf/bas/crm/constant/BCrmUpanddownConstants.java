/**
 * 
 */
package com.huateng.scf.bas.crm.constant;

/**
 * <p>
 * </p>
 *
 * @author lihao
 * @date 2016年12月13日 下午1:43:04
 * @version 1.0
 * @Copyright Shanghai Huateng Software Systems Co., Ltd.
 *
 *            <pre>
 * =================Modify Record=======================
 * Modifier			date			          Content
 * lihao		2016年12月13日 下午1:43:04	                                    新增
 *
 *            </pre>
 */

public class BCrmUpanddownConstants {
	// 状态：1-正常、2-终止
	public static final String UPANDDOWN_STATE_VALID = "1";
	public static final String UPANDDOWN_STATE_INVALID = "2";
}
