/**
 * 
 */
package com.huateng.scf.bas.qry.model;

/**
 * <p>
 * </p>
 *
 * @author shangxiujuan
 * @date 2017年6月29日下午1:38:58
 * @version 1.0
 * @Copyright Shanghai Huateng Software Systems Co., Ltd.
 *
 *            <pre>
 * =================Modify Record=======================
 * Modifier			   date			              Content
 * shangxiujuan		   2017年6月29日下午1:38:58              新增
 *
 *            </pre>
 */
public class LineData {
	private String name;

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

}
