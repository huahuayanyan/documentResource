/**
 * 
 */
package com.huateng.scf.bas.common.startup;

/**
 * <p>系统 全局信息工具类</p>
 *
 * @author 	huangshuidan
 * @date 2016年11月25日下午4:19:45	
 * @version 1.0
 * @Copyright Shanghai Huateng Software Systems Co., Ltd.
 *
 * <pre>
 * =================Modify Record=======================
 * Modifier			   date			              Content
 * huangshuidan		   2016年11月25日下午4:19:45              新增
 *
 * </pre>
 */
public class ScfGlobalInfoUtil {
	public static ScfGlobalInfo getScfGlobalInfo(){
		return null;
	}
}
