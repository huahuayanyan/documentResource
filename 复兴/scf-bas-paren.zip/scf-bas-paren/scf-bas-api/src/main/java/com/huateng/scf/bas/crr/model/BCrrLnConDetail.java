package com.huateng.scf.bas.crr.model;

/**
 * @author liph
 */
public class BCrrLnConDetail extends BCrrLnCon{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String bigProductId;

	public String getBigProductId() {
		return bigProductId;
	}

	public void setBigProductId(String bigProductId) {
		this.bigProductId = bigProductId;
	}
	
}
