package com.huateng.scf.bas.pbc.service;

public interface IBPbcAppliOrderBussInfoService {

}
