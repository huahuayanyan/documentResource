﻿
insert into ODS_TOP_CITY (ID, AREA, AREA_NAME, ORD, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values ('201706281430001', '110000', '北京市', 1, null, null, null);

insert into ODS_TOP_CITY (ID, AREA, AREA_NAME, ORD, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values ('201706281430002', '310000', '上海市', 2, null, null, null);

insert into ODS_TOP_CITY (ID, AREA, AREA_NAME, ORD, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values ('201706281430003', '440100', '广州市', 3, null, null, null);

commit;
