﻿
insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD56', 'DynamicQualityApply', 'Check', 'bsystasktab.DynamicQualityApply', null, '{"nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD57', 'DynamicQualityApply', 'Receipt', 'bsystasktab.DynamicQualityApply', null, '{"nextName":"回执确认","nextHide":false}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD58', 'DynamicQualityApply', 'Write', 'bsystasktab.DynamicQualityApply', null, '{"nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD74', 'DebtPressingApply', 'Write', 'bsystasktab.debtPress', null, '{"nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD75', 'MultiPriceAdjustApply', 'Receipt', 'bsystasktab.debtPress', null, '{"approvalHide":false,"approvalName":"回执确认","nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD82', 'DisputeInvoicRemoveApply', 'Write', 'bsystasktab.disputeRW', null, '{"approvalHide":true,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD83', 'DisputeInvoicRemoveApply', 'Approve', 'bsystasktab.disputeRW', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DD69', 'FactoringDebtPoolChargeOffApply', 'Receipt', 'bsystasktab.writeoffPoolTask', null, '{"approvalHide":false,"approvalName":"回执确认","nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DD68', 'FactoringDebtPoolChargeOffApply', 'Write', 'bsystasktab.writeoffPoolTask', null, '{"nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD62', 'FactoringAccountCancelApply', 'Write', 'bsystasktab.writeoffTask', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD66', 'AdjustPriceApplyXphh', 'Receipt', 'bsystasktab.writeoffTask', null, '{"nextName":"提交","nextHide":false}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DD70', 'AllowancePoolApply', 'Write', 'bsystasktab.AllowancePoolApply', null, '{"approvalHide":true,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DD71', 'AllowancePoolApply', 'Approve', 'bsystasktab.AllowancePoolApply', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD29', 'FactoringLeaseBuyBackApply', 'Write', 'bicrinfoview', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD28', 'FactoringLeaseBuyBackApply', 'Approve', 'bicrinfoview', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD27', 'FactoringLeaseBuyBackApply', 'Receipt', 'bicrinfoview', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD39', 'BDcrLin', 'dcr_node3', 'bsystasktab.bdcrview', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":false,"rejectName":"否决","nextName":"审查","nextHide":false}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD44', 'BCrrDuebillApp(XD)', 'BCrrDuebillApp_approve', 'bsystasktab.duebillappview', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD48', 'BCrrDuebillApp', 'duebillConfirm', 'bsystasktab.repay', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE52', 'RBcpBussAppli', 'checkTransferAgain', 'bsystasktab.checkTransferAgain', null, '{"approvalHide":false,"approvalName":"回执确认","nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD67', 'poolRePay', 'Write', 'bsystasktab.poolRePayWrite', null, '{"nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD68', 'poolRePay', 'Check', 'bsystasktab.poolRePayCheck', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD69', 'poolRePay', 'Start', 'bsystasktab.poolRePayWrite', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD72', 'AccountsReceivableOutPool', 'Write', 'bsystasktab.debtOutPool', null, '{"nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD73', 'AccountsReceivableOutPool', 'Approve', 'bsystasktab.debtOutPool', null, '{"approvalHide":false,"approvalName":"审批通过","nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD30', 'BCrrLnApp', 'LnApp_approve', 'bsystasktab.lnapp', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD34', 'creditEvalPrcssCreate', 'credictEvalNode2', 'bsystasktab.evalapprview', null, '{"nextHide":true,"approvalHide":false,"approvalName":"审核通过","rejectHide":false,"rejectName":"审核否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD43', 'BCrrDuebillApp', 'duebilladd', 'bsystasktab.repay', null, '{"approvalHide":true,"approvalName":"通过","rejectHide":true,"rejectName":"否决","nextName":"审批通过","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD45', 'ThreeGuaBuybackApply', 'Write', 'bsystasktab.ThreeGuaBuybackApplyview', null, '{"nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD46', 'ThreeGuaBuybackApply', 'Receipt', 'bsystasktab.ThreeGuaBuybackApplyview', null, '{"approvalHide":false,"approvalName":"回执确认","nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD47', 'ThreeGuaBuybackApply', 'Approve', 'bsystasktab.ThreeGuaBuybackApplyview', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD51', 'RBcpBussAppli', 'confirmTransfer', 'bsystasktab.confirmTransfer', null, '{"approvalHide":true,"approvalName":"通过","rejectHide":true,"rejectName":"否决","nextName":"审批通过","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD52', 'RBcpBussAppli', 'checkTransfer', 'bsystasktab.checkTransfer', null, '{"approvalHide":true,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审批通过","nextHide":false}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD53', 'RBcpBussAppli', 'noticeConfirm', 'bsystasktab.noticeConfirm', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B2U8S2LS000A2C7FCAA00001728DD45', 'FactoringPoolBuyBackApply', 'Write', 'bsystasktab.backtransferpool', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001720DD01', 'FactoringPoolPaymentApply', 'Write', 'bsystasktab.FactoringPoolPaymentApply', null, '{"nextName":"提交","nextHide":false}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001720DD02', 'FactoringPoolPaymentApply', 'Check', 'bsystasktab.FactoringPoolPaymentApply', null, '{"approvalHide":false,"approvalName":"通过","rejectHide":false,"rejectName":"否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B2U8S2LS000A2C7FCAA00001728DD44', 'FactoringAccountRepurApply', 'Approve', 'bsystasktab.backtransfer', null, '{"nextHide":true,"approvalHide":false,"approvalName":"审批通过","IssuedHide":false,"IssuedName":"退回修改"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B2U8S2LS000A2C7FCAA00001728DD46', 'FactoringPoolBuyBackApply', 'Approve', 'bsystasktab.backtransferpool', null, '{"nextHide":true,"approvalHide":false,"approvalName":"审批通过","IssuedHide":false,"IssuedName":"退回修改"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD80', 'DisputePoolInvoicRemoveApply', 'Write', 'bsystasktab.disputePoolRW', null, '{"approvalHide":true,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD81', 'DisputePoolInvoicRemoveApply', 'Approve', 'bsystasktab.disputePoolRW', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD31', 'BCrrDuebillApp', 'Approve_DuebillApp', 'bsystasktab.duebillappview', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD38', 'BDcrLin', 'dcr_node1', 'bsystasktab.bdcrview', null, '{"approvalHide":true,"rejectHide":true,"nextName":"审查","nextHide":false}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD42', 'ThreeAccountConfirmApply', 'Write', 'bsystasktab.ThreeAccountConfirmApplyview', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD41', 'ThreeAccountConfirmApply', 'Receipt', 'bsystasktab.ThreeAccountConfirmApplyview', null, '{"approvalHide":false,"approvalName":"回执确认","nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C6FCAA00001728DD6A', 'MarginApply', 'Write', 'bsystasktab.lncimarginapply', null, '{"nextName":"提交","nextHide":false,"viewhide":false,"viewdisable":false}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B2U8S2LS000A2C7FCAA00001728DD57', 'CashEqualValueRegApply', 'Approve', 'bsystasktab.cashEqualValue', null, '{"nextHide":true,"approvalHide":false,"approvalName":"同意","IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B2U8S2LS000A2C7FCAA00001728DD49', 'DisMortgageBill', 'Write', 'bsystasktab.dismortgageBill', null, '{"nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C6FCAA00001728DD6C', 'MarginApply', 'Approve', 'bsystasktab.lncimarginapply', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":false,"rejectName":"否决","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B2U8S2LS000A2C7FCAA00001728DD50', 'DisMortgageBill', 'Approve', 'bsystasktab.dismortgageBill', null, '{"nextName":"同意","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B2U8S2LS000A2C7FCAA00001728DD52', 'DisMortgageBill', 'end', 'bsystasktab.dismortgageBill', null, '{"nextName":"同意","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B2U8S2LS000A2C7FCAA00001728DD51', 'DisMortgageBill', 'confirm', 'bsystasktab.dismortgageBill', null, '{"nextName":"同意","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B2U8S2LS000A2C7FCAA00001728DD53', 'MaxBailTransferOutApply', 'Write', 'bsystasktab.transferOutApply', null, '{"nextName":"提交审批","nextHide":false}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B2U8S2LS000A2C7FCAA00001728DD54', 'MaxBailTransferOutApply', 'Review', 'bsystasktab.transferOutApply', null, '{"nextName":"同意","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B2U8S2LS000A2C7FCAA00001728DD56', 'MaxBailTransferOutApply', 'Approve', 'bsystasktab.transferOutApply', null, '{"nextName":"同意","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B2U8S2LS000A2C7FCAA00001728DD55', 'MaxBailTransferOutApply', 'Check', 'bsystasktab.transferOutApply', null, '{"nextName":"同意","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE19', 'BillNormalCashLoanApply', 'Approve_DuebillApp', 'bsystasktab.duebillappview', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE20', 'BillNormalCashLoanApply', 'duebilladd', 'bsystasktab.repayBillNormalCash', null, '{"approvalHide":true,"approvalName":"通过","rejectHide":true,"rejectName":"否决","nextName":"审批通过","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE21', 'BillNormalCashLoanApply', 'duebillConfirm', 'bsystasktab.repayBillNormalCash', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE25', 'BillNormalDeliveryApply', 'Write', 'bsystasktab.billnormalDelivery', null, '{"nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE28', 'BillNormalAddApply', 'Write', 'bsystasktab.billnormalAdd', null, '{"nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE29', 'BillNormalAddApply', 'Check', 'bsystasktab.billnormalAdd', null, '{"nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE30', 'BillNormalAddApply', 'Review', 'bsystasktab.billnormalAdd', null, '{"nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE31', 'BillNormalAddApply', 'Receipt', 'bsystasktab.billnormalAdd', null, '{"nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE32', 'BillNormalUnpledgeApply', 'Write', 'bsystasktab.billnormalUnPledge', null, '{"nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE33', 'BillNormalUnpledgeApply', 'Review', 'bsystasktab.billnormalUnPledge', null, '{"nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE34', 'BillNormalUnpledgeApply', 'Check', 'bsystasktab.billnormalUnPledge', null, '{"nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE35', 'BillNormalUnpledgeApply', 'Confirm', 'bsystasktab.billnormalUnPledge', null, '{"nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DD78', 'AdjustPriceApplicationBill', 'Write', 'bsystasktab.adjustPriceApplicationBill', null, '{"approvalHide":true,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DD79', 'AdjustPriceApplicationBill', 'Approve', 'bsystasktab.adjustPriceApplicationBill', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DC59', 'StaticQualityApply', 'Write', 'bsystasktab.StaticQualityApply', null, '{"nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DC60', 'StaticQualityApply', 'Approve', 'bsystasktab.StaticQualityApply', null, '{"nextName":"提交","nextHide":false}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DC61', 'StaticQualityApply', 'Check', 'bsystasktab.StaticQualityApply', null, '{"nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DC62', 'StaticQualityApply', 'Receipt', 'bsystasktab.StaticQualityApply', null, '{"nextName":"回执确认","nextHide":false}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE43', 'MortgageBillLoanApply', 'Approve_DuebillApp', 'bsystasktab.duebillappview', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE44', 'MortgageBillLoanApply', 'duebilladd', 'bsystasktab.repayBillMtg', null, '{"approvalHide":true,"approvalName":"通过","rejectHide":true,"rejectName":"否决","nextName":"审批通过","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE48', 'MortgageBillLoanApply', 'duebillConfirm', 'bsystasktab.repayBillMtg', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DC08', 'N-FactoringAanwinstApply', 'Write', 'bsystasktab.Ntransfer', null, '{"approvalHide":true,"approvalName":"审批通过","rejectHide":true,"rejectName":"退回","nextName":"审批通过","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DD80', 'AdjustPriceApply', 'AdjusPrice_receipt', 'bsystasktab.adjustPriceApply', null, '{"nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DC10', 'N-FactoringAanwinstApply', 'Receipt', 'bsystasktab.Ntransfer', null, '{"approvalHide":false,"approvalName":"回执确认","rejectHide":false,"rejectName":"否决","IssuedHide":false,"IssuedName":"退回","nextName":"审批通过","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DD83', 'AdjustPriceApplyXphh', 'AdjusPrice_receipt', 'bsystasktab.adjustPriceApplyXphh', null, '{"nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DC13', 'N-FactoringPoolAanwinstApply', 'Receipt', 'bsystasktab.Ntransfer', null, '{"approvalHide":false,"approvalName":"回执确认","rejectHide":false,"rejectName":"否决","IssuedHide":false,"IssuedName":"退回","nextName":"审批通过","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE55', 'N-InvoiceFinancingApply', 'Write', 'bsystasktab.invoiceFinancingCash', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE56', 'N-InvoiceFinancingApply', 'Approve', 'bsystasktab.invoiceFinancingCash', null, '{"nextName":"审批通过","nextHide":false,"IssuedHide":false,"IssuedName":"退回","rejectHide":false,"rejectName":"否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE57', 'N-FinancingPoolApply', 'Write', 'bsystasktab.financingPoolCash', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE58', 'N-FinancingPoolApply', 'Approve', 'bsystasktab.financingPoolCash', null, '{"nextName":"审批通过","nextHide":false,"IssuedHide":false,"IssuedName":"退回","rejectHide":false,"rejectName":"否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DD81', 'AdjustPriceApplyXphh', 'Write', 'bsystasktab.adjustPriceApplyXphh', null, '{"approvalHide":true,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD89', 'FinancingPoolApply', 'duebilladd', 'bsystasktab.repay', null, '{"approvalHide":true,"approvalName":"通过","rejectHide":true,"rejectName":"否决","nextName":"审批通过","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD88', 'FinancingPoolApply', 'Approve_DuebillApp', 'bsystasktab.duebillappview', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE49', 'DeliveryApply', 'Write', 'bsystasktab.staticDeliveryApply', null, '{"nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD87', 'InvoiceFinancingApply', 'duebillConfirm', 'bsystasktab.repay', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD86', 'InvoiceFinancingApply', 'duebilladd', 'bsystasktab.repay', null, '{"approvalHide":true,"approvalName":"通过","rejectHide":true,"rejectName":"否决","nextName":"审批通过","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD85', 'InvoiceFinancingApply', 'Approve_DuebillApp', 'bsystasktab.duebillappview', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD90', 'FinancingPoolApply', 'duebillConfirm', 'bsystasktab.repay', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE50', 'DeliveryApply', 'Issued', 'bsystasktab.staticDeliveryApply', null, '{"nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE51', 'DeliveryApply', 'Receipt', 'bsystasktab.staticDeliveryApply', null, '{"nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD95', 'ThreeBillChargeOffApply', 'duebilladd', 'bsystasktab.repay', null, '{"approvalHide":true,"approvalName":"通过","rejectHide":true,"rejectName":"否决","nextName":"审批通过","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD94', 'ThreeBillChargeOffApply', 'Approve_DuebillApp', 'bsystasktab.duebillappview', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD96', 'ThreeBillChargeOffApply', 'duebillConfirm', 'bsystasktab.repay', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD98', 'FourLoanBillApply', 'duebilladd', 'bsystasktab.repayFourWare', null, '{"approvalHide":true,"approvalName":"通过","rejectHide":true,"rejectName":"否决","nextName":"审批通过","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD97', 'FourLoanBillApply', 'Approve_DuebillApp', 'bsystasktab.duebillappview', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD99', 'FourLoanBillApply', 'duebillConfirm', 'bsystasktab.repayFourWare', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DC55', 'FourhousePledgeApply', 'Approve', 'bsystasktab.FourhousePledgeApply', null, '{"nextName":"提交","nextHide":false}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DC56', 'FourhousePledgeApply', 'Check', 'bsystasktab.FourhousePledgeApply', null, '{"nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DC57', 'FourhousePledgeApply', 'Receipt', 'bsystasktab.FourhousePledgeApply', null, '{"nextName":"回执确认","nextHide":false}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DC58', 'FourhousePledgeApply', 'Write', 'bsystasktab.FourhousePledgeApply', null, '{"nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE01', 'One2OneFourDeliveryApply', 'Write', 'bsystasktab.One2OneFourDeliveryApply', null, '{"nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE02', 'One2OneFourDeliveryApply', 'Receipt', 'bsystasktab.One2OneFourDeliveryApply', null, '{"approvalHide":false,"approvalName":"回执确认","nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE03', 'One2OneFourDeliveryApply', 'Approve', 'bsystasktab.One2OneFourDeliveryApply', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE36', 'BillNormalReplaceApply', 'Write', 'bsystasktab.billnormalMngExcg', null, '{"nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE37', 'BillNormalReplaceApply', 'Pricing', 'bsystasktab.billnormalMngExcg', null, '{"nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE38', 'BillNormalReplaceApply', 'Review', 'bsystasktab.billnormalMngExcg', null, '{"nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE39', 'BillNormalReplaceApply', 'Confirm', 'bsystasktab.billnormalMngExcg', null, '{"nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE40', 'MortgageCashLoanApply', 'Approve_DuebillApp', 'bsystasktab.duebillappview', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE41', 'MortgageCashLoanApply', 'duebilladd', 'bsystasktab.repayCashMtg', null, '{"approvalHide":true,"approvalName":"通过","rejectHide":true,"rejectName":"否决","nextName":"审批通过","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE42', 'MortgageCashLoanApply', 'duebillConfirm', 'bsystasktab.repayCashMtg', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DD82', 'AdjustPriceApplyXphh', 'Approve', 'bsystasktab.adjustPriceApplyXphh', null, '{"approvalHide":true,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD76', 'N-DisputeInvoiceSetApply', 'Approve', 'bsystasktab.NdisputeRegister', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":false,"rejectName":"审批否决","IssuedHide":false,"IssuedName":"退回","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD77', 'N-PoolDisputeInvoiceReg', 'Approve', 'bsystasktab.NdisputeRegister', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":false,"rejectName":"审批否决","IssuedHide":false,"IssuedName":"退回","nextName":"审批通过","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE63', 'N-FactoringPoolBuyBackApply', 'Write', 'bsystasktab.debtBackTransferApply', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE64', 'N-FactoringPoolBuyBackApply', 'Approve', 'bsystasktab.debtBackTransferApply', null, '{"nextName":"审批通过","nextHide":false,"IssuedHide":false,"IssuedName":"退回","rejectHide":false,"rejectName":"否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE65', 'N-FactoringAccountRepurApply', 'Write', 'bsystasktab.debtPoolBackTransferApply', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE66', 'N-FactoringAccountRepurApply', 'Approve', 'bsystasktab.debtPoolBackTransferApply', null, '{"nextName":"审批通过","nextHide":false,"IssuedHide":false,"IssuedName":"退回","rejectHide":false,"rejectName":"否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA05001728DC60', 'DynamicQualityApply', 'Approve', 'bsystasktab.DynamicQualityApply', null, '{"nextName":"提交","nextHide":false}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DD92', 'N-AllowanceApply', 'Write', 'bsystasktab.debtImpairmentApply', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DD93', 'N-AllowanceApply', 'Approve', 'bsystasktab.debtImpairmentApply', null, '{"nextName":"审批通过","nextHide":false,"IssuedHide":false,"IssuedName":"退回","rejectHide":false,"rejectName":"否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DD94', 'N-AllowancePoolApply', 'Write', 'bsystasktab.debtPoolImpairmentApply', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DD95', 'N-AllowancePoolApply', 'Approve', 'bsystasktab.debtPoolImpairmentApply', null, '{"nextName":"审批通过","nextHide":false,"IssuedHide":false,"IssuedName":"退回","rejectHide":false,"rejectName":"否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728D142', 'FourAccountConfirmApply', 'Write', 'bsystasktab.FourAccountConfirmApplyview', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728D141', 'FourAccountConfirmApply', 'Receipt', 'bsystasktab.FourAccountConfirmApplyview', null, '{"approvalHide":false,"approvalName":"回执确认","nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE18', 'BillNormalQualityApply', 'Confirm', 'bsystasktab.billnormalPledge', null, '{"nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE17', 'BillNormalQualityApply', 'Review', 'bsystasktab.billnormalPledge', null, '{"nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE16', 'BillNormalQualityApply', 'Check', 'bsystasktab.billnormalPledge', null, '{"nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE26', 'BillNormalDeliveryApply', 'Issued', 'bsystasktab.billnormalDelivery', null, '{"nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE27', 'BillNormalDeliveryApply', 'Receipt', 'bsystasktab.billnormalDelivery', null, '{"nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE45', 'FourGuaBuybackApply', 'Write', 'bsystasktab.FourGuaBuybackApply', null, '{"nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE46', 'FourGuaBuybackApply', 'Receipt', 'bsystasktab.FourGuaBuybackApply', null, '{"approvalHide":false,"approvalName":"回执确认","nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE47', 'FourGuaBuybackApply', 'Approve', 'bsystasktab.FourGuaBuybackApply', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DD76', 'AdjustPriceApply', 'Write', 'bsystasktab.adjustPriceApply', null, '{"approvalHide":true,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DD77', 'AdjustPriceApply', 'Approve', 'bsystasktab.adjustPriceApply', null, '{"approvalHide":true,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE53', 'FactoringContApply', 'Approve', 'bsystasktab.factoringApply', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE54', 'FactoringContApply', 'Confirm', 'bsystasktab.factoringApply', null, '{"nextName":"回执确认","nextHide":false,"IssuedHide":false,"IssuedName":"退回","rejectHide":false,"rejectName":"否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE61', 'N-DebtPoolPressingApply', 'Write', 'bsystasktab.debtPressingApply', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE62', 'N-DebtPoolPressingApply', 'Receipt', 'bsystasktab.debtPressingApply', null, '{"nextName":"回执确认","nextHide":false,"IssuedHide":false,"IssuedName":"退回","rejectHide":false,"rejectName":"否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE59', 'N-DebtPressingApply', 'Write', 'bsystasktab.debtPressingApply', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE60', 'N-DebtPressingApply', 'Receipt', 'bsystasktab.debtPressingApply', null, '{"nextName":"回执确认","nextHide":false,"IssuedHide":false,"IssuedName":"退回","rejectHide":false,"rejectName":"否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DD86', 'MultiPriceAdjustApplyXhjt', 'Write', 'bsystasktab.multiPriceAdjustApplyXhjt', null, '{"approvalHide":true,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DD87', 'MultiPriceAdjustApplyXhjt', 'Approve', 'bsystasktab.multiPriceAdjustApplyXhjt', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A7C7FCAA00001728DD98', 'MultiPriceAdjustApplyXhjt', 'Receipt', 'bsystasktab.debtPress', null, '{"approvalHide":false,"approvalName":"回执确认","nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729ED83', 'AdjustPriceApplyXhdt', 'AdjusPrice_receipt', 'bsystasktab.adjustPriceApplyXhdt', null, '{"nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729ED81', 'AdjustPriceApplyXhdt', 'Write', 'bsystasktab.adjustPriceApplyXhdt', null, '{"approvalHide":true,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729ED82', 'AdjustPriceApplyXhdt', 'Approve', 'bsystasktab.adjustPriceApplyXhdt', null, '{"approvalHide":true,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DD88', 'N-FactoringAccountCancelApply', 'Write', 'bsystasktab.debtCancelApply', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DD89', 'N-FactoringAccountCancelApply', 'Receipt', 'bsystasktab.debtCancelApply', null, '{"nextName":"回执确认","nextHide":false,"IssuedHide":false,"IssuedName":"退回","rejectHide":false,"rejectName":"否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DD90', 'N-FactoringPoolChargeOffApply', 'Write', 'bsystasktab.debtPoolCancelApply', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DD91', 'N-FactoringPoolChargeOffApply', 'Receipt', 'bsystasktab.debtPoolCancelApply', null, '{"nextName":"回执确认","nextHide":false,"IssuedHide":false,"IssuedName":"退回","rejectHide":false,"rejectName":"否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DS01', 'StockListImportApply', 'Write', 'bsystasktab.stockListImportApply', null, '{"nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('2C0U8S2LS000A2C7FCAA00001720DD01', 'N-FactoringPoolPaymentApply', 'Write', 'bsystasktab.nCashPaymentApply', null, '{"nextName":"提交","nextHide":false}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('2C0U8S2LS000A2C7FCAA00001720DD02', 'N-FactoringPoolPaymentApply', 'Check', 'bsystasktab.nCashPaymentApply', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":false,"rejectName":"审批否决","IssuedHide":false,"IssuedName":"退回","nextName":"审批通过","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001739DD56', 'N-CashPaymentApply', 'Check', 'bsystasktab.nCashPaymentApply', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":false,"rejectName":"审批否决","IssuedHide":false,"IssuedName":"退回","nextName":"审批通过","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE04', 'N-DisputeInvoicRemoveApply', 'Approve', 'bsystasktab.NdisputeRemove', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":false,"rejectName":"审批否决","IssuedHide":false,"IssuedName":"退回","nextName":"审批通过","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE05', 'N-DisputePoolInvoicRemoveApply', 'Approve', 'bsystasktab.NdisputeRemove', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":false,"rejectName":"审批否决","IssuedHide":false,"IssuedName":"退回","nextName":"审批通过","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DS02', 'StockListImportApply', 'Approve', 'bsystasktab.stockListImportApply', null, '{"nextHide":true,"approvalHide":false,"approvalName":"审批通过","IssuedHide":false,"IssuedName":"退回修改"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DC14', 'N-FactoringDoubleAanwinstApply', 'Write', 'bsystasktab.Ntransfer', null, '{"nextName":"审批通过","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DC15', 'N-FactoringDoubleAanwinstApply', 'Approve', 'bsystasktab.Ntransfer', null, '{"approvalHide":false,"approvalName":"回执确认","rejectHide":false,"rejectName":"否决","IssuedHide":false,"IssuedName":"退回","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DJ86', 'MultiPriceAdjustApplyXhdt', 'Write', 'bsystasktab.multiPriceAdjustApplyXhdt', null, '{"approvalHide":true,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B2U8S2LS000A2C7FCAA00001728DD40', 'repayment', 'repayment_1', 'bsystasktab.payment', null, '{"approvalHide":false,"approvalName":"通过","rejectHide":false,"rejectName":"否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD63', 'ThreeDeliveryApply', 'Write', 'bsystasktab.ThreeDeliveryApplyview', null, '{"nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD64', 'ThreeDeliveryApply', 'Receipt', 'bsystasktab.ThreeDeliveryApplyview', null, '{"approvalHide":false,"approvalName":"回执确认","nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD65', 'ThreeDeliveryApply', 'Approve', 'bsystasktab.ThreeDeliveryApplyview', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B2U8S2LS000A2C7FCAA00001728DD41', 'PoolDisputeInvoiceReg', 'Write', 'bsystasktab.pooldisputeSubmit', null, '{"nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B2U8S2LS000A2C7FCAA00001728DD42', 'PoolDisputeInvoiceReg', 'PoolDisputeInvoiceApprove', 'bsystasktab.pooldisputeApprove', null, '{"nextHide":true,"approvalHide":false,"approvalName":"审批通过","rejectHide":false,"rejectName":"审批否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B2U8S2LS000A2C7FCAA00001728DD43', 'FactoringAccountRepurApply', 'Write', 'bsystasktab.backtransfer', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B2U8S2LS000A2C7FCAA00001728DD72', 'PoolDisputeInvoiceReg', 'PoolDisputeInvoiceSave', 'bsystasktab.pooldisputeSave', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD49', 'DisputeInvoiceSetApply', 'DisputeInvoiceSetSave', 'bsystasktab.recdisptregview', null, '{"nextHide":false}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD50', 'DisputeInvoiceSetApply', 'DisputeInvoiceSetSubmit', 'bsystasktab.recdisptregapprview', null, '{"nextHide":false,"approvalHide":false,"approvalName":"审批通过","rejectHide":false,"rejectName":"审批否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE14', 'PoolReturnAccTransferApply', 'Check', 'bsystasktab.poolRePayCheck', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD70', 'DebtPoolPressingApply', 'Write', 'bsystasktab.debtPoolPress', null, '{"nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD71', 'DebtPoolPressingApply', 'Receipt', 'bsystasktab.debtPoolPress', null, '{"approvalHide":false,"approvalName":"回执确认","nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DC06', 'AccountsReceivableInPool', 'Write', 'bsystasktab.debtInPool', null, '{"nextName":"提交","nextHide":false}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DC07', 'AccountsReceivableInPool', 'Approve', 'bsystasktab.debtInPool', null, '{"nextHide":true,"approvalHide":false,"approvalName":"审批通过","IssuedHide":false,"IssuedName":"退回修改"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD35', 'BCrrLnApp', 'LnApp_approve1', 'bsystasktab.lnapp', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD36', 'BCrrLnApp', 'LnApp_approve2', 'bsystasktab.lnapp', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD33', 'creditEvalPrcssCreate', 'credictEvalNode1', 'bsystasktab.evalapprview', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD37', 'BCrrLnApp', 'Complete_LnApp', 'bsystasktab.lnapp', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD59', 'ProtocolAmountApply', 'sbcpappli_check', 'bsystasktab.lowerprice', null, '{"nextHide":false,"nextName":"提交","approvalHide":false,"approvalName":"审批通过","rejectHide":false,"rejectName":"审批否决","IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD60', 'ProtocolAmountApply', 'sbcpappli_confirm', 'bsystasktab.lowerprice', null, '{"nextHide":false,"nextName":"回执确认","approvalHide":true,"approvalName":"审批通过","rejectHide":false,"rejectName":"审批否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD61', 'ProtocolAmountApply', 'sbcpappli_approve', 'bsystasktab.lowerprice', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE11', 'ReversePaymentTransferApply', 'Write', 'bsystasktab.rePayWrite', null, '{"approvalHide":true,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DC00', 'FactoringPoolAanwinstApply', 'Write', 'bsystasktab.confirmTransfer', null, '{"approvalHide":true,"approvalName":"通过","rejectHide":true,"rejectName":"否决","nextName":"审批通过","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DC01', 'FactoringPoolAanwinstApply', 'Approve', 'bsystasktab.checkTransfer', null, '{"approvalHide":true,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审批通过","nextHide":false}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DC02', 'FactoringPoolAanwinstApply', 'Receipt', 'bsystasktab.checkTransferAgain', null, '{"approvalHide":false,"approvalName":"回执确认","nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DC03', 'FactoringAanwinstApply', 'Write', 'bsystasktab.confirmTransfer', null, '{"approvalHide":true,"approvalName":"通过","rejectHide":true,"rejectName":"否决","nextName":"审批通过","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DC04', 'FactoringAanwinstApply', 'Approve', 'bsystasktab.checkTransfer', null, '{"approvalHide":true,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审批通过","nextHide":false}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DC05', 'FactoringAanwinstApply', 'Receipt', 'bsystasktab.checkTransferAgain', null, '{"approvalHide":false,"approvalName":"回执确认","nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001720DD03', 'CashPaymentApply', 'Write', 'bsystasktab.CashPaymentApply', null, '{"approvalHide":false,"approvalName":"通过","rejectHide":false,"rejectName":"否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DD72', 'AllowanceApply', 'Write', 'bsystasktab.AllowanceApply', null, '{"approvalHide":true,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE13', 'PoolReturnAccTransferApply', 'Write', 'bsystasktab.poolRePayWrite', null, '{"approvalHide":true,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE12', 'ReversePaymentTransferApply', 'Check', 'bsystasktab.rePayCheck', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DD73', 'AllowanceApply', 'Approve', 'bsystasktab.AllowanceApply', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE15', 'BillNormalQualityApply', 'Write', 'bsystasktab.billnormalPledge', null, '{"nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE22', 'BillNormalBillLoanApply', 'Approve_DuebillApp', 'bsystasktab.duebillappview', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE23', 'BillNormalBillLoanApply', 'duebilladd', 'bsystasktab.repayBillNormalBill', null, '{"approvalHide":true,"approvalName":"通过","rejectHide":true,"rejectName":"否决","nextName":"审批通过","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE24', 'BillNormalBillLoanApply', 'duebillConfirm', 'bsystasktab.repayBillNormalBill', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DD74', 'MultiPriceAdjustApply', 'Write', 'bsystasktab.multiPriceAdjustApply', null, '{"approvalHide":true,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DD75', 'MultiPriceAdjustApply', 'Approve', 'bsystasktab.multiPriceAdjustApply', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B2U8S2LS000A2C7FCAA00001728DD48', 'CashEqualValueRegApply', 'Write', 'bsystasktab.cashEqualValue', null, '{"nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001722DE98', 'FourLoanApply', 'duebilladd', 'bsystasktab.repayFourWareLiuDai', null, '{"approvalHide":true,"approvalName":"通过","rejectHide":true,"rejectName":"否决","nextName":"审批通过","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001722DE97', 'FourLoanApply', 'Approve_DuebillApp', 'bsystasktab.duebillappview', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001722DE99', 'FourLoanApply', 'duebillConfirm', 'bsystasktab.repayFourWareLiuDai', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DJ87', 'MultiPriceAdjustApplyXhdt', 'Approve', 'bsystasktab.multiPriceAdjustApplyXhdt', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":true,"rejectName":"否决","nextName":"审查","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DJ88', 'MultiPriceAdjustApplyXhdt', 'Receipt', 'bsystasktab.debtPress', null, '{"approvalHide":false,"approvalName":"回执确认","nextName":"提交","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DC09', 'N-FactoringAanwinstApply', 'Approve', 'bsystasktab.Ntransfer', null, '{"nextName":"审批通过","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DD96', 'N-DebtDoublePressingApply', 'Write', 'bsystasktab.debtPressingApply', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001729DD97', 'N-DebtDoublePressingApply', 'Receipt', 'bsystasktab.debtPressingApply', null, '{"nextName":"回执确认","nextHide":false,"IssuedHide":false,"IssuedName":"退回","rejectHide":false,"rejectName":"否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE71', 'N-DebtLeasePressingApply', 'Write', 'bsystasktab.debtPressingApply', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE72', 'N-DebtLeasePressingApply', 'Receipt', 'bsystasktab.debtPressingApply', null, '{"nextName":"回执确认","nextHide":false,"IssuedHide":false,"IssuedName":"退回","rejectHide":false,"rejectName":"否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE75', 'N-DebtCreditPressingApply', 'Write', 'bsystasktab.debtPressingApply', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE76', 'N-DebtCreditPressingApply', 'Receipt', 'bsystasktab.debtPressingApply', null, '{"nextName":"回执确认","nextHide":false,"IssuedHide":false,"IssuedName":"退回","rejectHide":false,"rejectName":"否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE77', 'N-DisputeDoubleInvoiceSetApply', 'Write', 'bsystasktab.NdisputeRegister', null, '{"nextHide":false,"nextName":"提交","IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE78', 'N-DisputeDoubleInvoiceSetApply', 'Approve', 'bsystasktab.NdisputeRegister', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":false,"rejectName":"审批否决","IssuedHide":false,"IssuedName":"退回","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE79', 'N-DisputeCreditInvoiceSetApply', 'Write', 'bsystasktab.NdisputeRegister', null, '{"nextHide":false,"nextName":"提交","IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE80', 'N-DisputeCreditInvoiceSetApply', 'Approve', 'bsystasktab.NdisputeRegister', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":false,"rejectName":"审批否决","IssuedHide":false,"IssuedName":"退回","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE81', 'N-DisputeLeaseInvoiceSetApply', 'Write', 'bsystasktab.NdisputeRegister', null, '{"nextHide":false,"nextName":"提交","IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE82', 'N-DisputeLeaseInvoiceSetApply', 'Approve', 'bsystasktab.NdisputeRegister', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":false,"rejectName":"审批否决","IssuedHide":false,"IssuedName":"退回","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE83', 'N-DisputeDoubleInvoicRemoveApply', 'Write', 'bsystasktab.NdisputeRemove', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE84', 'N-DisputeDoubleInvoicRemoveApply', 'Approve', 'bsystasktab.NdisputeRemove', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":false,"rejectName":"审批否决","IssuedHide":false,"IssuedName":"退回","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE85', 'N-DisputeCreditInvoicRemoveApply', 'Write', 'bsystasktab.NdisputeRemove', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE86', 'N-DisputeCreditInvoicRemoveApply', 'Approve', 'bsystasktab.NdisputeRemove', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":false,"rejectName":"审批否决","IssuedHide":false,"IssuedName":"退回","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE87', 'N-DisputeLeaseInvoicRemoveApply', 'Write', 'bsystasktab.NdisputeRemove', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE88', 'N-DisputeLeaseInvoicRemoveApply', 'Approve', 'bsystasktab.NdisputeRemove', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":false,"rejectName":"审批否决","IssuedHide":false,"IssuedName":"退回","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE89', 'N-AllowanceCreditApply', 'Write', 'bsystasktab.debtImpairmentApply', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE90', 'N-AllowanceCreditApply', 'Approve', 'bsystasktab.debtImpairmentApply', null, '{"nextName":"审批通过","nextHide":false,"IssuedHide":false,"IssuedName":"退回","rejectHide":false,"rejectName":"否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE91', 'N-AllowanceDoubleApply', 'Write', 'bsystasktab.debtImpairmentApply', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE92', 'N-AllowanceDoubleApply', 'Approve', 'bsystasktab.debtImpairmentApply', null, '{"nextName":"审批通过","nextHide":false,"IssuedHide":false,"IssuedName":"退回","rejectHide":false,"rejectName":"否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE93', 'N-AllowanceLeaseApply', 'Write', 'bsystasktab.debtImpairmentApply', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE94', 'N-AllowanceLeaseApply', 'Approve', 'bsystasktab.debtImpairmentApply', null, '{"nextName":"审批通过","nextHide":false,"IssuedHide":false,"IssuedName":"退回","rejectHide":false,"rejectName":"否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE95', 'N-FactoringDoubleBuyBackApply', 'Write', 'bsystasktab.debtPoolBackTransferApply', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE96', 'N-FactoringDoubleBuyBackApply', 'Approve', 'bsystasktab.debtPoolBackTransferApply', null, '{"nextName":"审批通过","nextHide":false,"IssuedHide":false,"IssuedName":"退回","rejectHide":false,"rejectName":"否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE97', 'N-FactoringLeaseBuyBackApply', 'Write', 'bsystasktab.debtPoolBackTransferApply', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE98', 'N-FactoringLeaseBuyBackApply', 'Approve', 'bsystasktab.debtPoolBackTransferApply', null, '{"nextName":"审批通过","nextHide":false,"IssuedHide":false,"IssuedName":"退回","rejectHide":false,"rejectName":"否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE99', 'N-FactoringCreditBuyBackApply', 'Write', 'bsystasktab.debtPoolBackTransferApply', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DF01', 'N-FactoringCreditBuyBackApply', 'Approve', 'bsystasktab.debtPoolBackTransferApply', null, '{"nextName":"审批通过","nextHide":false,"IssuedHide":false,"IssuedName":"退回","rejectHide":false,"rejectName":"否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DC12', 'N-FactoringPoolAanwinstApply', 'Approve', 'bsystasktab.Ntransfer', null, '{"nextName":"审批通过","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DF07', 'N-FactoringCreditPaymentApply', 'Check', 'bsystasktab.nCashPaymentApply', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":false,"rejectName":"审批否决","IssuedHide":false,"IssuedName":"退回","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DF08', 'N-FactoringLeasePaymentApply', 'Write', 'bsystasktab.nCashPaymentApply', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DF02', 'N-FactoringLeaseAanwinstApply', 'Write', 'bsystasktab.Ntransfer', null, '{"nextName":"审批通过","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DF03', 'N-FactoringLeaseAanwinstApply', 'Approve', 'bsystasktab.Ntransfer', null, '{"approvalHide":false,"approvalName":"回执确认","rejectHide":false,"rejectName":"否决","IssuedHide":false,"IssuedName":"退回","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DF04', 'N-FactoringCreditAanwinstApply', 'Write', 'bsystasktab.Ntransfer', null, '{"nextName":"审批通过","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DF05', 'N-FactoringCreditAanwinstApply', 'Approve', 'bsystasktab.Ntransfer', null, '{"approvalHide":false,"approvalName":"回执确认","rejectHide":false,"rejectName":"否决","IssuedHide":false,"IssuedName":"退回","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DF06', 'N-FactoringCreditPaymentApply', 'Write', 'bsystasktab.nCashPaymentApply', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DF09', 'N-FactoringLeasePaymentApply', 'Check', 'bsystasktab.nCashPaymentApply', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":false,"rejectName":"审批否决","IssuedHide":false,"IssuedName":"退回","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DC17', 'N-AccountsReceivableInPool', 'Write', 'bsystasktab.NdebtInPool', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DC18', 'N-AccountsReceivableInPool', 'Approve', 'bsystasktab.NdebtInPool', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":false,"rejectName":"否决","IssuedHide":false,"IssuedName":"退回","nextName":"审批通过","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD78', 'N-AccountsReceivableOutPool', 'Write', 'bsystasktab.NdebtOutPool', null, null);

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD79', 'N-AccountsReceivableOutPool', 'Approve', 'bsystasktab.NdebtOutPool', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":false,"rejectName":"否决","IssuedHide":false,"IssuedName":"退回","nextName":"审批通过","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE67', 'N-DoubleFactFinancingApply', 'Write', 'bsystasktab.invoiceFinancingCash', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE68', 'N-DoubleFactFinancingApply', 'Approve', 'bsystasktab.invoiceFinancingCash', null, '{"nextName":"审批通过","nextHide":false,"IssuedHide":false,"IssuedName":"退回","rejectHide":false,"rejectName":"否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE69', 'N-FactoringDoublePaymentApply', 'Write', 'bsystasktab.nCashPaymentApply', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DE70', 'N-FactoringDoublePaymentApply', 'Check', 'bsystasktab.nCashPaymentApply', null, '{"approvalHide":false,"approvalName":"审批通过","rejectHide":false,"rejectName":"审批否决","IssuedHide":false,"IssuedName":"退回","nextHide":true}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DF10', 'N-FactoringCreditChargeOffApply', 'Write', 'bsystasktab.debtCancelApply', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DF11', 'N-FactoringCreditChargeOffApply', 'Receipt', 'bsystasktab.debtCancelApply', null, '{"nextName":"回执确认","nextHide":false,"IssuedHide":false,"IssuedName":"退回","rejectHide":false,"rejectName":"否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DF12', 'N-FactoringLeaseChargeOffApply', 'Write', 'bsystasktab.debtCancelApply', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DF13', 'N-FactoringLeaseChargeOffApply', 'Receipt', 'bsystasktab.debtCancelApply', null, '{"nextName":"回执确认","nextHide":false,"IssuedHide":false,"IssuedName":"退回","rejectHide":false,"rejectName":"否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DF14', 'N-FactoringDoubleChargeOffApply', 'Write', 'bsystasktab.debtCancelApply', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DF15', 'N-FactoringDoubleChargeOffApply', 'Receipt', 'bsystasktab.debtCancelApply', null, '{"nextName":"回执确认","nextHide":false,"IssuedHide":false,"IssuedName":"退回","rejectHide":false,"rejectName":"否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DF16', 'N-LeaseFactFinancingApply', 'Write', 'bsystasktab.invoiceFinancingCash', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DF17', 'N-LeaseFactFinancingApply', 'Approve', 'bsystasktab.invoiceFinancingCash', null, '{"nextName":"审批通过","nextHide":false,"IssuedHide":false,"IssuedName":"退回","rejectHide":false,"rejectName":"否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DF18', 'N-CreditFactFinancingApply', 'Write', 'bsystasktab.invoiceFinancingCash', null, '{"nextName":"提交","nextHide":false,"IssuedHide":false,"IssuedName":"退回"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DF19', 'N-CreditFactFinancingApply', 'Approve', 'bsystasktab.invoiceFinancingCash', null, '{"nextName":"审批通过","nextHide":false,"IssuedHide":false,"IssuedName":"退回","rejectHide":false,"rejectName":"否决"}');

insert into B_SYS_FLOW_URL_REL (ID, FLOW_ID, NODE_ID, PG_URL, BUSS_TYPE, NODE_BUTTON)
values ('1B0U8S2LS000A2C7FCAA00001728DD55', 'N-CashPaymentApply', 'Write', 'bsystasktab.nCashPaymentApply', null, '{"nextName":"提交","nextHide":false}');

commit;
