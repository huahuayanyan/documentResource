﻿
insert into B_DCR_LIN_TYP (CR_ID, CR_NM, CHK_EXPR, STAT, CIRC_FLAG)
values ('002', '专项额度', '23', '1', '1');

insert into B_DCR_LIN_TYP (CR_ID, CR_NM, CHK_EXPR, STAT, CIRC_FLAG)
values ('credit001', '综合授信', 'CheckCredit', '1', '1');

insert into B_DCR_LIN_TYP (CR_ID, CR_NM, CHK_EXPR, STAT, CIRC_FLAG)
values ('3', '3', '3', '1', '2');

insert into B_DCR_LIN_TYP (CR_ID, CR_NM, CHK_EXPR, STAT, CIRC_FLAG)
values ('4', '4', '4', '1', '1');

insert into B_DCR_LIN_TYP (CR_ID, CR_NM, CHK_EXPR, STAT, CIRC_FLAG)
values ('5', '5', '5', '0', '1');

insert into B_DCR_LIN_TYP (CR_ID, CR_NM, CHK_EXPR, STAT, CIRC_FLAG)
values ('6', '6', '6', '0', '1');

insert into B_DCR_LIN_TYP (CR_ID, CR_NM, CHK_EXPR, STAT, CIRC_FLAG)
values ('7', '7', '7', '1', '1');

insert into B_DCR_LIN_TYP (CR_ID, CR_NM, CHK_EXPR, STAT, CIRC_FLAG)
values ('8', '8', '8', '0', '1');

insert into B_DCR_LIN_TYP (CR_ID, CR_NM, CHK_EXPR, STAT, CIRC_FLAG)
values ('9', '9', '9', '1', '1');

insert into B_DCR_LIN_TYP (CR_ID, CR_NM, CHK_EXPR, STAT, CIRC_FLAG)
values ('2', '2', '2', '1', '2');

commit;
