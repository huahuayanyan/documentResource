﻿
insert into B_BRP_FILE_PARAM (ID, CONT_NAME, CONT_CODE, EXT1, EXT2, EXT3, EXT4, EXT5, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values ('C001', '企业注册资料', 'C001', null, null, null, null, null, '008', '17-6月 -17 02.11.29.381000 下午', '100', '008', '17-6月 -17 02.11.29.381000 下午', '100');

insert into B_BRP_FILE_PARAM (ID, CONT_NAME, CONT_CODE, EXT1, EXT2, EXT3, EXT4, EXT5, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values ('C002', '企业营业执照', 'C002', null, null, null, null, null, '008', '17-6月 -17 02.12.30.213000 下午', '100', '008', '17-6月 -17 02.12.30.213000 下午', '100');

insert into B_BRP_FILE_PARAM (ID, CONT_NAME, CONT_CODE, EXT1, EXT2, EXT3, EXT4, EXT5, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values ('C003', '企业法人信息', 'C003', null, null, null, null, null, '100', '14-7月 -17 02.01.08.289000 下午', '200', '100', '14-7月 -17 02.01.08.289000 下午', '200');

commit;
