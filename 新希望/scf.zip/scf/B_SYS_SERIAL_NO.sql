﻿
insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('PLSY_T_TYPE_22', 17, '20170517', '现货静态质押提货通知书', 'TZ22[yyyyMMdd]{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('FCZ_APP_NO', 22, '20170526', '出账登记业务编号', 'FCZ-[yyyyMMdd]{########}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('YSJZ_T_APP_NO', 27, '20170605', '应收账款减值业务申请编号', 'YSJZ[yyyyMMdd]{#######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('CEVDJ_APP_NO', 9, '20170215', '现金等价物质押登记', 'CEVDJ[yyyyMMdd]{#######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('PROTOCOL_CODE_JGJT', 27, '20170501', '监管合同号(现货静态)', 'JGJT[yyyyMMdd]{#####}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('FCNT_APP_NO', 71, '20170519', '应收类业务申请编号', 'FCNT[yyyyMMdd]{########}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('FHT_APP_NO', 47, '20170519', '应收类业务合同编号', 'FHT-[yyyyMMdd]{########}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('YSZR_APP_NO', 87, '20170606', '应收账款转让出质业务申请编号', 'YSZR[yyyyMMdd]{#######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('PROTOCOL_CODE_XP', 38, '20170407', '先票后货协议纸质编号', 'XPHH[yyyyMMdd]{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('CHECK_REPORT_NO', 46, '20170414', '核库编号', 'HK[yyyyMMdd]{#####}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('INSPECT_REPORT_NO', 25, '20170414', '巡库编号', 'XK[yyyyMMdd]{#####}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('INDEX_APP_NO', 358, '20170414', '业务申请编号', '{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('SKQR_F_APP_NO', 9, '20170419', '先票/款后货收款确认申请号', 'SKQRF[yyyyMMdd]{#####}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('SKQR_T2_NOTICE_NO', 14, '20170419', '担保提货收款确认银承通知书编号', 'TZ78{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('SKQR_F_NOTICE_NO', 0, '20170419', '先票/款后货收款确认流贷通知书编号', 'TZ77{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('SKQR_F2_NOTICE_NO', 0, '20170419', '先票/款后货收款确认银承通知书编号', 'TZ79{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('ZY_CONT_NO', 15, '20170423', '抵质押合同号', 'ZY{########}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('DZGL_F_APP_NO', 17, '20170427', '先票/款后货对账管理', 'DZGL[yyyyMMdd]{#######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('DZGL_F_NOTICE_NO', 17, '20170427', '先票/款后货对账管理发货对账通知书编号', 'TZ99{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('FBZJ_APP_NO', 14, '20170502', '非标仓单追加申请业务编号', 'FBZJ[yyyyMMdd]{########}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('CETK_F_NOTICE_NO', 8, '20170504', '先票/款后货差额退款通知书编号', 'TZ85{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('FFK_APP_NO', 54, '20170523', '应收类融资放款业务编号', 'FFK-[yyyyMMdd]{########}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('NOTICE_TYPE_111', 0, '20170704', '国内双保理催收通知书', 'TZ111[yyyyMMdd]{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('NOTICE_TYPE_112', 0, '20170704', '信保保理催收通知书', 'TZ112[yyyyMMdd]{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('NOTICE_TYPE_113', 0, '20170704', '租赁保理催收通知书', 'TZ113[yyyyMMdd]{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('NOTICE_TYPE_115', 0, '20170704', '应收账款质押催收通知书', 'TZ115[yyyyMMdd]{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('YSZK_C_NOTICE_NO', 3, '20170221', '应收账款应收账款催收通知书编号', 'TZ33{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('YSZK_T_NOTICE_NO', 16, '20170221', '应收账款应收账款提示付款通知书编号', 'TZ116{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('YSCS_T_APP_NO', 21, '20170213', '应收账款催收申请编号', 'YSCST[yyyyMMdd]{#####}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('YSHX_T_APP_NO', 40, '20170301', '应收账款入池申请编号', 'YSHX[yyyyMMdd]{#######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('YSHX_T_NOTICE_NO', 47, '20170301', '应收账款核销通知书编号', 'TZ25{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('YSZR_T_NOTICE_NO', 29, '20170301', '应收账款减值通知书编号', 'TZ17{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('CHK_DIR_NO', 60, null, '授信额度目录编号', 'CDN[yyyyMMdd]{#########}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('SKQR_T_APP_NO', 177, '20161214', '担保提货收款确认申请号', 'SKQRT[yyyyMMdd]{#####}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('THSQ_T_NOTICE_NO', 65, '20161227', '担保提货提货申请通知书编号', 'TZ62{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('YSRC_T_APP_NO', 67, '20170117', '应收账款入池申请编号', 'YSRC[yyyyMMdd]{#######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('SUBJ_NO', 73, '20170118', '财务报表科目编号', 'SUBJ{####}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('BCOP_NO', 25, '20161201', '业务组件编号', 'BIZ{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('INT_CNFG', 42, null, '拦截项流水号', 'CNFG[yyyyMMdd]{####}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('INT_PL', 51, null, '拦截方案流水号', 'PL[yyyyMMdd]{####}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('CZRK_APP_NO', 183, null, '出质入库申请编号', 'CZRK[yyyyMMdd]{########}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('SKQR_T_NOTICE_NO', 51, '20161223', '担保提货收款确认通知书编号', 'TZ75{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('XHDY_L_NOTCIE_NO', 52, '20161226', '现货抵押放款借据通知书编号', 'TZJJ{#######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('LOW_PRICE', 152, '20161228', '最低控货价值调整申请编号', 'LPRCE[yyyyMMdd]{#######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('LPRCE_D_NOTICE_NO', 50, '20161229', '最低控货价值调整申请通知书编号', 'TZLP{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('YS_HK_NO', 303, null, '应收回款申请流水号', 'YSHK[yyyyMMdd]{########}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('FHDZ_T_APP_NO', 60, '20170106', '担保提货发货对账APPNO', 'FHDZ[yyyyMMdd]{#######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('FHDZ_T_NOTICE_NO', 59, '20170106', '担保提货发货对账通知书编号', 'TZ40{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('HHZZ_APP_NO', 251, null, '回款专户转账申请编号', 'HHZZ[yyyyMMdd]{########}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('CREDIT_TYPE_NO', 1205, '20161105', '额度类型编号', 'EDZL[yyyyMMdd]{########}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('THREE_PROTOCOL_NO', 136, '20161124', '担保提货协议编号', 'DBTH[yyyyMMdd]{#####}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('GNBL_CONT_NO', 36, '20161202', '国内保理合同号', 'GNBL[yyyyMMdd]{#####}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('YSZY_CONT_NO', 4, '20161202', '应收账款质押合同号', 'YSZY[yyyyMMdd]{#####}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('FXBL_CONT_NO', 7, '20161202', '反向保理合同号', 'FXBL[yyyyMMdd]{#####}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('CREDIT_LIMIT_BUYER_NO', 18, '20161202', '买方信用限额编号', 'MSED[yyyyMMdd]{#####}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('INDIRECT_CREDIT_NO', 147, '20161202', '间接额度编号', 'JJED[yyyyMMdd]{#####}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('R_BCP_DEBT_DTL_APPLY_NO', 2678, '20161217', '应收账款单据明细信息申请号', '[yyyyMMdd]{####}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('CETK_T_NOTICE_NO', 34, '20161223', '担保提货差额退款通知书编号', 'TZ71{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('R_BCP_DEBT_APPLY_NO', 0, '20161216', '应收账款单据基本信息申请号', '[yyyyMMdd]{#####}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('R_BCP_BUSS_APP_NO', 454, '20161224', '应收账款转让业务申请号', 'RBB[yyyyMMdd]{#######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('THSQ_T_APP_NO', 87, '20170110', '担保提货提货申请号', 'THSQT[yyyyMMdd]{#####}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('GNBLC_CONT_NO', 41, '20170111', '国内保理池合同号', 'BLC[yyyyMMdd]{#####}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('YSZYC_CONT_NO', 8, '20170111', '应收账款质押池合同号', 'ZYC[yyyyMMdd]{#####}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('CKTSC_CONT_NO', 1, '20170111', '出口退税池合同号', 'TSC[yyyyMMdd]{#####}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('YSZKC_T_NOTICE_NO', 34, '20170113', '应收账款池应收账款提示付款通知书编号', 'TZ117{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('YSZKC_C_NOTICE_NO', 5, '20170113', '应收账款池应收账款催收通知书编号', 'TZ110{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('YSCS_F_APP_NO', 63, '20170114', '应收账款池催收申请编号', 'YSCSF[yyyyMMdd]{#####}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('BAS_CUST_CD', 281, '20161105', '客户编号', 'C[yyyyMMdd]{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('CR_LIN_NO', 276, null, '授信额度编号', 'CRLIN[yyyyMMdd]{#########}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('PROTOCOL_CODE_JGDT', 160, '20161203', '监管合同号', 'JGDT[yyyyMMdd]{#####}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('INV_NO', 186, null, '发票/票据流水号', 'INV[yyyyMMdd]{#########}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('MORTGAGE_NO', 493, null, '押品编号', 'YP{########}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('CETK_T_APP_NO', 45, '20161222', '担保提货差额退款申请号', 'CETKT[yyyyMMdd]{#####}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('B_NTE_NOTICE_NUM_13', 207, '20161226', '应收账款转让通知书编号', 'TZ13{#######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('YSFZR_T_APP_NO', 175, '20161229', '应收账款反转让申请号', 'YSFZR[yyyyMMdd]{#######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('YSCC_T_APP_NO', 49, '20170118', '应收账款入池申请编号', 'YSCC[yyyyMMdd]{#######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('CR_APP_NO', 160, null, '授信额度申请编号', 'CRAPP[yyyyMMdd]{#########}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('CHK_DETAIL_NO', 47, null, '授信额度检查对象流水号', 'CDD[yyyyMMdd]{#########}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('CR_BC_NO', 54, null, '授信协议流水号', 'CRBC[yyyyMMdd]{#########}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('FIN_NO', 57, null, '客户财务信息编号', 'FIN[yyyyMMdd]{#########}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('LN_APP_NO', 459, null, '贷款业务流水号', 'LNAPP[yyyyMMdd]{#####}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('EXT_NO', 458, null, '贷款业务品种类型流水号', 'EXT[yyyyMMdd]{#########}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('LN_CON_NO', 239, null, '贷款合同流水号', 'LNCON[yyyyMMdd]{#######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('GNTY_CON_NO', 291, null, '担保合同流水号', 'GYCON[yyyyMMdd]{#######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('GNTY_INFO_NO', 181, null, '担保物编号', 'GYIF[yyyyMMdd]{########}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('DUE_APP_NO', 500, null, '出账流水号', 'DUAPP[yyyyMMdd]{#######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('DUE_NO', 298, null, '台帐流水号/借据号', 'DUN[yyyyMMdd]{#########}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('B_NTE_NOTICE_NUM_101', 88, '20161226', '池融资应收账款转让通知书编号', 'TZ101{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('CEVJY_APP_NO', 20, '20170220', '现金等价物解押', 'CEVJY[yyyyMMdd]{#######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('FBZY_APP_NO', 28, '20170417', '非标仓单质押业务申请编号', 'FBZY[yyyyMMdd]{########}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('FBCD_ZY_NOTICE_NO', 50, '20170419', '非标仓单质押通知书编号', 'TZ128[yyyyMMdd]{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('NOTICE_TYPE_0', 93, '20170427', '押品价格确定调整通知书编号', 'TZ0[yyyyMMdd]{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('NOTICE_TYPE_81', 21, '20170427', '先票/款后货出质通知书编号', 'TZ81[yyyyMMdd]{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('FBCD_JY_NOTICE_NO', 15, '20170503', '普通仓单解押通知书编号', 'TZ127[yyyyMMdd]{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('FBZH_APP_NO', 15, '20170508', '普通非标仓单置换申请业务编号', 'FBZH[yyyyMMdd]{########}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('NOTICE_TYPE_1', 11, '20170516', '押品监管下限通知书编号', 'TZ1[yyyyMMdd]{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('NOTICE_TYPE_90', 39, '20170516', '动产出质入库通知书', 'TZ90[yyyyMMdd]{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('PLTH_APP_NO', 37, '20170516', '现货静态提货申请编号', 'PLTH[yyyyMMdd]{########}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('CCMS_CUSTCD', 66, null, '信贷系统客户号', '[yyyyMdHHmmss]{###}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('CZRK_F_APP_NO', 33, '20170426', '先票/款后货出质入库申请号', 'CZRKF[yyyyMMdd]{#####}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('FBTH_APP_NO', 23, '20170426', '非标仓单提货业务申请编号', 'FBTH[yyyyMMdd]{########}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('FBCD_TH_NOTICE_NO', 0, '20170426', '非标仓单提货通知书编号', 'TZ130[yyyyMMdd]{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('THSQ_F_NOTICE_NO', 51, '20170502', '先票/款后货提货申请通知书编号', 'TZ70{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('THSQ_F_APP_NO', 64, '20170502', '先票/款后货提货申请号', 'THSQF[yyyyMMdd]{#####}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('XYPJ_NO', 384, null, '评估流水号', 'XYPJ[yyyyMMdd]{#######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('FBK_APP_NO', 15, '20170626', '模拟银行返回凭证编号', 'FBK-[yyyyMMdd]{########}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('MAXI_APP_NO', 34, '20170228', '最高额保证金转出申请编号', 'MAXI[yyyyMMdd]{########}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('DSBH_PRODUCT_ID', 15, null, '盯市编号', 'DS{########}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('PROTOCOL_CODE_JGFBC', 27, '20170413', '非标仓单协议纸质编号', 'JGFBC[yyyyMMdd]{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('PROTOCOL_CODE_JGXPHH', 21, '20170413', '先票后货监管合同协议纸质编号', 'JGXPHH[yyyyMMdd]{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('YFFU_T_NOTICE_NO', 23, '20170419', '预付类发货通知书编号', 'TZ122{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('DJBC_T_NOTICE_NO', 13, '20170423', '跌价补偿通知书编号', 'TZ23{######}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('FBJY_APP_NO', 10, '20170503', '普通非标仓单解押申请业务编号', 'FBJY[yyyyMMdd]{########}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('CETK_F_APP_NO', 7, '20170504', '先票/款后货差额退款申请号', 'CETKF[yyyyMMdd]{#####}');

insert into B_SYS_SERIAL_NO (SERIAL_CODE, SERIAL_VALUE, PRE_DATE, SERIAL_NAME, SERIAL_FORMAT)
values ('NOTICE_TYPE_2', 7, '20170509', '押品变更及回执通知书编号', 'TZ2[yyyyMMdd]{######}');

commit;
