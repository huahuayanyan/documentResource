﻿
insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (314, '金威啤酒', 64, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (318, '健力宝饮料', 66, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (319, '半成品牛皮', 67, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (325, '兰板羊皮', 67, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (329, '生羊皮', 67, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (333, '湿法革', 69, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (342, '毛片', 72, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (360, '宝马', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (368, '锐志', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (370, '马自达', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (372, '雪佛兰', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (374, '比亚迪', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (378, '长城', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (382, '东风本田', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (384, '东风起亚', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (399, '吉利', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (401, '东风日产', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (406, '上海大众', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (408, '上海英伦', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (412, '双龙汽车', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (418, '一汽丰田', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (429, '大运汽车', 78, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (432, '东风牵引车', 78, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (437, '搅拌车', 78, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (447, '柳汽中轻卡', 78, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (449, '山重建机系列挖机', 78, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (453, '郑州宇通', 78, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (462, '豪江摩托车', 80, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (469, '五羊款系列sk125普款', 80, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (476, '奥铃', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (484, '东风汽车', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (485, '东风轻卡', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (489, '福迪汽车', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (496, '红岩', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (505, '解放牌汽车', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (525, '五菱', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (529, '江铃', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (533, '一汽日野', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (541, '车床', 85, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (558, 'RGB线', 87, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (559, '变压器', 87, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (565, '铁芯', 87, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (568, '网络线', 87, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (572, '冰箱', 89, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (577, '挂烫机', 89, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (578, '空气净化器', 89, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (582, '笔记本电脑', 91, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (586, '米色家电', 91, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (12, '皮革', 0, '1', '2   ', '1', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (19, '家电', 0, '1', '2   ', '1', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (22, '线螺', 1, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, '1', null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (28, '特钢', 1, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (38, '布类', 5, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (49, '原料', 8, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (57, '玻璃', 10, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (64, '啤酒', 11, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (68, '皮革制品', 12, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (72, '羽绒原材料', 14, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (76, '石油化工类', 15, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (77, '乘用车', 16, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (82, '商用车', 16, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (88, '计算机配件及其他', 18, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (96, '线材', 22, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (99, '镀锌板', 23, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (100, '不锈钢板', 23, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (103, '镀锡板', 23, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (104, '大梁板', 23, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (108, '热轧硅钢', 24, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (112, 'H型材', 25, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (115, '普碳圆钢', 25, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (124, '不锈钢无缝管', 27, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (132, '冷镦钢', 28, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (136, 'B钢', 28, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (145, '球墨铸铁', 29, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (154, '铁精粉', 31, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (159, '炼焦煤', 33, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (171, '纯涤纱', 35, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (175, '亚麻纱', 35, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (176, '涤纶DTY', 36, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (189, '梭织牛仔布', 38, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (210, '锌锭', 42, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (215, '镍板', 43, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (216, '镍铁', 43, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (237, '溶剂油', 48, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (241, '液化气', 48, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (248, '牛卡纸', 50, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (249, '新闻纸', 51, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (253, '轻涂纸', 51, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (257, '小麦', 52, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (261, '大豆', 52, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (264, '豆制品', 53, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (593, '超白玻璃', 57, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (0, '押品类型', null, '1', '2   ', '0', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (1, '黑色金属', 0, '1', '2   ', '1', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (4, '纺织原料', 0, '1', '2   ', '1', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (11, '酒类及饮料', 0, '1', '2   ', '1', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (16, '机动车及配件', 0, '1', '2   ', '1', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (23, '板材', 1, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (24, '硅钢', 1, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (25, '型材', 1, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (30, '铁合金', 1, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, '2', null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (39, '铜', 6, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (43, '镍', 6, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (44, '锡', 6, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (54, '饲料', 9, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (58, '木材', 10, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (61, '果汁饮料', 11, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (67, '皮革', 12, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (73, '羽绒制品', 14, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (78, '工程车', 16, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (86, '专用机械设备', 17, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (91, '米色家电', 19, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (92, '医药', 20, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (93, '医疗器械', 20, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (95, '螺纹钢', 22, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (116, '棒材圆钢', 25, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (120, '方坯', 26, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (125, '不锈钢焊管', 27, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (128, '圆钢', 28, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (129, '齿轮钢', 28, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (140, '废钢', 28, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (146, '直接还原铁', 29, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (148, '硅锰', 30, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (153, '原矿', 31, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (156, '焦炭', 32, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (158, '动力煤', 33, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (163, '喷吹煤', 33, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (166, '丙纶短纤', 34, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (172, '锦纶纱', 35, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (180, '锦纶FDY', 36, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (181, '锦纶POY', 36, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (194, '粗铜', 39, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (203, '氟化铝', 40, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (204, '铅精矿', 41, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (205, '铅锭', 41, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (211, '锌粉', 42, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (222, '钴', 45, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (226, '黄金', 46, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (233, '煤油', 48, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (236, '润滑油', 48, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (245, '白板纸', 50, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (250, '铜板纸', 51, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (254, '食糖', 52, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (255, '白砂糖', 52, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (256, '稻米', 52, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (269, '花生油', 55, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (283, '浮法玻璃', 57, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (286, '蓝玻', 57, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (287, '绿玻', 57, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (295, '茅台', 60, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (300, '泸州老窖', 60, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (303, '五粮液', 60, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (304, '西凤酒', 60, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (309, '普通红酒', 62, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (316, '高档洋酒', 65, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (322, '成品羊皮', 67, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (327, '人造革', 67, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (328, '生牛皮', 67, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (330, '皮衣', 68, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (335, '合成橡胶', 70, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (340, '子午线轮胎', 71, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (347, '磷肥', 74, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (352, '聚氯乙烯', 75, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (356, '乙烯', 76, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (357, '聚苯乙烯', 76, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (366, '皇冠', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (369, '凯美瑞', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (371, '沃尔沃', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (383, '东风皮卡', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (398, '欢动', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (400, '江淮', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (402, '庆铃', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (403, '上汽', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (405, '三菱汽车', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (411, '双龙', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (419, '一汽佳宝', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (421, '一汽轿车', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (425, '永源UFO', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (427, '郑州日产尼桑', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (430, '鼎力自缷', 78, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (431, '高空作业车', 78, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (434, '格尔发自缷', 78, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (440, '解放水泥搅拌车', 78, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (442, '解放重型载货车', 78, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (444, '亮剑载货', 78, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (454, '苏州金龙', 79, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (492, '哈飞', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (501, '江淮轻卡', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (508, '金杯', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (512, '其它品牌汽车', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (516, '全顺牌汽车', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (518, '日野重卡', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (526, '五菱微型车', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (527, '五菱系列汽车', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (540, '不锈钢贮罐', 85, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (544, '发动机', 85, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (560, '电源线', 87, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (566, '同轴线', 87, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (567, '铜板', 87, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (573, '电烤箱', 89, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (576, '热水器', 89, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (579, '音响及其配件', 90, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (588, '显示器', 91, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (589, '原料', 92, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (590, '中药', 92, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (7, '石油产品', 0, '1', '2   ', '1', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (8, '纸品类', 0, '1', '2   ', '1', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (13, '橡胶及轮胎', 0, '1', '2   ', '1', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (17, '机械设备', 0, '1', '2   ', '1', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (21, '电线电缆', 0, '1', '2   ', '1', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (27, '钢管', 1, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (36, '长丝', 4, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (59, '建筑陶瓷', 10, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (60, '白酒', 11, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (62, '红酒', 11, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (63, '黄酒', 11, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (69, '其他', 12, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (70, '橡胶', 13, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (71, '轮胎', 13, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (85, '通用机械设备', 17, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (89, '白色家电', 19, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (105, '钢卷', 23, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (106, '板卷', 23, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (110, '无取向硅钢', 24, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (117, '角钢', 25, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (127, '合结钢', 28, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (130, '轴承钢', 28, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (134, '拉丝材', 28, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (135, '硬线', 28, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (151, '锰矿', 30, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (157, '煤焦油', 32, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (160, '褐煤', 33, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (164, '涤纶短纤', 34, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (169, '纯棉纱', 35, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (173, '腈纶纱', 35, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (174, '丙纶纱', 35, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (179, '锦纶DTY', 36, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (183, '粘胶长丝', 36, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (192, '铜精矿', 39, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (193, '电解铜', 39, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (202, '废铝', 40, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (206, '粗铅', 41, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (218, '锡锭', 44, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (228, '铂', 46, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (231, '燃料油', 48, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (235, '沥青', 48, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (243, '废纸', 49, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (247, '牛皮纸', 50, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (263, '淀粉', 53, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (267, '鱼粉', 54, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (281, '鸡肉', 56, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (289, '人造板', 58, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (294, '陶管', 59, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (310, '王朝', 62, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (320, '半成品羊皮', 67, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (336, '特种橡胶', 70, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (341, '鹅绒', 72, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (345, '氮肥', 74, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (350, '聚丙烯', 75, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (361, '雷克萨斯', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (380, '大众', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (386, '东风悦达轿车', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (422, '一汽夏利轿车', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (426, '郑州日产', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (451, '陕汽翻斗车', 78, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (460, '大阳', 80, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (461, '广州飞狐', 80, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (481, '长安汽车', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (498, '华菱汽车', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (500, '江淮汽车', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (502, '江淮重卡', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (513, '奇瑞', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (521, '陕汽通家汽车', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (528, '扬子皮卡', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (532, '一汽解放重卡', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (545, '混凝土输送泵', 85, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (547, '摊铺机', 86, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (550, '二次浆料生产线', 86, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (551, '发电机组', 86, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (554, '棉籽榨油机', 86, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (555, '生产线', 86, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (570, '网线', 88, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (571, '空调', 89, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (581, '液晶电视机', 90, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (583, '打印机', 91, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (587, '品牌台式电脑', 91, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (10, '建材', 0, '1', '2   ', '1', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (14, '羽绒及其制品', 0, '1', '2   ', '1', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (18, '计算机配件及电子元件', 0, '1', '2   ', '1', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (26, '钢坯', 1, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (32, '煤炭制品', 3, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (33, '原煤', 3, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (41, '铅', 6, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (42, '锌', 6, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (45, '其它产品', 6, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (47, '原油', 7, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (53, '加工产品', 9, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (66, '碳酸饮料', 11, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (74, '化肥', 15, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (80, '摩托车', 16, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (83, '特种车', 16, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (84, '其他', 17, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (90, '黑色家电', 19, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (94, '电线电缆', 21, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (97, '彩板', 23, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (101, '热轧板', 23, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (109, '取向硅钢', 24, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (270, '豆油', 55, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (273, '棕榈油', 55, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (277, '牛肉', 56, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (278, '鸭肉', 56, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (282, '原片', 57, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (290, '锯材', 58, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (299, '六和液', 60, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (307, '娃哈哈系列产品', 61, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (317, '普通洋酒', 65, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (321, '成品牛皮', 67, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (324, '兰板牛皮头层', 67, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (332, '合成革', 69, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (334, '天然橡胶', 70, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (338, '再生橡胶', 70, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (339, '斜交线轮胎', 71, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (348, '钾肥', 74, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (358, 'EVO汽车', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (367, '花冠', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (375, '别克', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (377, '长安铃木', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (379, '大发森雅', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (381, '戴姆勒-克莱斯勒牌汽车', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (393, '格兰迪', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (395, '海福星', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (413, '斯巴鲁汽车', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (415, '一汽奥迪', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (417, '一汽大众', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (438, '江潍牵引车', 78, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (448, '挖机', 78, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (450, '五十铃', 78, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (452, '五菱牌汽车合格证', 78, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (458, '沃尔沃', 79, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (464, '火鸟摩托车', 80, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (465, '铃木', 80, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (467, '轻骑', 80, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (470, '雅马哈摩托车', 80, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (472, '重庆建设摩托车', 80, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (474, '电动车', 81, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (479, '北京福田', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (483, '乘龙', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (486, '东风小康', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (490, '福田汽车', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (494, '海马王子', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (499, '济南重汽重卡', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (503, '江南奥拓', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (531, '一汽解放轻卡', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (534, '郑州日产东风', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (538, '喷墨打印机', 84, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (539, '变压器', 85, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (548, '艾里逊变速箱', 86, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (549, '电力设备及材料', 86, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (552, '发动机', 86, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (556, '针车', 86, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (562, '绝缘板', 87, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (574, '微波炉', 89, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (575, '洗衣机', 89, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (580, '彩电', 90, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (594, '超薄玻璃', 57, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (177, '涤纶FDY', 36, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (188, '坯布', 38, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (195, '铜材', 39, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (199, '铝合金锭', 40, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (200, '铝材', 40, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (208, '锌矿', 42, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (220, '锡合金', 44, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (223, '锑', 45, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (227, '白银', 46, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (232, '汽油', 48, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (239, '石油焦', 48, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (244, '白卡纸', 50, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (252, '轻型纸', 51, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (260, '稻谷', 52, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (265, '玉米', 54, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (266, '豆粕', 54, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (274, '调和油', 55, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (291, '饰面瓦', 59, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (292, '陶瓷墙地砖', 59, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (296, '飞仙牌诸葛酿', 60, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (306, '汇源桃果汁', 61, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (315, '蓝带啤酒', 64, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (331, '表处剂', 69, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (343, '鸭绒', 72, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (344, '羽绒服', 73, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (351, '聚乙烯', 75, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (355, '乙二醇MEG', 76, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (359, '奥迪', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (362, '北京现代', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (363, '北汽皮卡', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (373, '标致', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (385, '东风雪铁龙', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (387, '东南汽车', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (389, '福迪', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (391, '福特', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (396, '海马', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (407, '上海斯柯达', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (409, '上汽通用五菱(雪弗莱)', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (423, '伊柯丽斯', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (435, '工程车', 78, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (446, '柳汽牵引车', 78, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (455, '中通客车', 79, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (459, '徐工', 79, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (466, '摩托车', 80, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (475, '机动车零部件', 81, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (478, '宝威牌汽车', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (482, '长丰猎豹', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (488, '福迪', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (497, '华晨金杯', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (506, '解放汽车', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (510, '欧曼汽车', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (514, '青年牌汽车', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (520, '山东凯马', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (522, '商用车', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (524, '唐骏欧铃轻卡', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (530, '一汽红塔汽车', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (535, '仓栅式运输车', 83, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (536, '厦门金龙防弹运钞车', 83, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (543, '发电机组', 85, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (553, '卡特彼勒发动机', 86, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (561, '监控线', 87, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (563, '漆包线', 87, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (569, '在对数电缆', 87, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (584, '服务器', 91, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (585, '机箱', 91, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (2, '矿产品', 0, '1', '2   ', '1', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (5, '纺织品', 0, '1', '2   ', '1', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (9, '农产品', 0, '1', '2   ', '1', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (29, '生铁', 1, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (31, '铁矿石', 2, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (37, '天然纤维', 4, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (48, '石油制品', 7, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (51, '印刷纸', 8, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (52, '粮食', 9, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (56, '肉类', 9, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (75, '塑料产品', 15, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (79, '客车', 16, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (98, '中厚板', 23, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (102, '冷板', 23, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (113, '扁钢', 25, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (118, '槽钢', 25, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (119, '冷弯型钢', 25, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (121, '管坯', 26, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (122, '无缝管', 27, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (123, '焊管', 27, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (126, '碳结钢', 28, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (131, '高工钢', 28, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (137, 'PC钢', 28, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (139, '模具钢', 28, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (141, '气阀钢', 28, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (147, '球墨铸管', 29, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (155, '进口矿', 31, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (161, '烟煤', 33, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (178, '涤纶POY', 36, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (182, '丙纶长丝', 36, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (184, '氨纶丝', 36, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (185, '棉花', 37, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (191, '针织布', 38, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (197, '氧化铝', 40, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (209, '锌合金', 42, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (212, '废锌', 42, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (214, '镍矿', 43, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (217, '废镍', 43, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (219, '锡精矿', 44, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (224, '镁', 45, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (225, '锂', 45, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (234, '柴油', 48, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (114, '方钢', 25, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (143, '炼钢生铁', 29, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (144, '铸造生铁', 29, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (150, '铬铁', 30, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (165, '锦纶短纤', 34, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (168, '粘胶短纤', 34, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (170, '人棉纱', 35, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (186, '化纤布', 38, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (187, '棉布', 38, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (190, '休闲布', 38, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (196, '废铜', 39, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (198, '铝锭', 40, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (201, '铝土矿', 40, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (207, '再生铅', 41, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (213, '电解镍', 43, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (221, '废锡', 44, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (229, '原油', 47, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (230, '成品油', 48, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (238, '硫磺', 48, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (246, '瓦楞纸', 50, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (251, '双胶纸', 51, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (259, '花生', 52, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (271, '菜油', 55, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (275, '玉米油', 55, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (276, '葵花籽油', 55, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (279, '羊肉', 56, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (297, '黄花郎酒', 60, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (301, '水井坊', 60, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (305, '伊力特曲', 60, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (312, '塔牌', 63, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (323, '兰板牛皮', 67, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (326, '兰板羊皮头层', 67, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (337, '橡胶助剂', 70, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (346, '复合肥', 74, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (349, '工程塑料', 75, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (353, '聚酯切片', 75, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (354, '钛白粉', 75, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (364, '奔驰', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (365, '本田', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (376, '长安福特', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (388, '丰田', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (390, '福美来', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (392, '福田', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (394, '哈飞', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (397, '华晨中华', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (404, '荣威牌汽车', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (410, '圣达菲汽车', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (414, '通用汽车', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (416, '一汽奔腾', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (420, '一汽佳星轿车', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (424, '颐达', 77, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (428, '成都神钢', 78, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (433, '东风中轻卡', 78, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (436, '混凝土工程车', 78, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (439, '解放牵引车', 78, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (441, '解放中型载货车', 78, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (443, '解放重型自卸车', 78, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (445, '柳汽翻斗车', 78, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (456, '厦门金旅', 79, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (457, '奔驰', 79, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (463, '豪进', 80, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (468, '五羊本田', 80, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (471, '众城', 80, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (473, '珠峰', 80, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (477, '宝典牌汽车', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (480, '长安轿车', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (487, '东凤小康', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (491, '福田时代', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (493, '海马福仕达', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (495, '红星SCEO', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (504, '解放', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (507, '解放轻卡', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (509, '陆风牌汽车', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (511, '欧曼重卡', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (515, '庆铃', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (517, '日产轻卡', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (519, '瑞风', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (523, '随州天龙', 82, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (537, '自御汽车-新大地', 83, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (542, '电球', 85, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (546, '压路机', 86, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (557, '其他', 86, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (564, '鼠标', 87, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (591, '西药', 92, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (592, '电线电缆', 94, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (3, '煤炭', 0, '1', '2   ', '1', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (6, '有色产品', 0, '1', '2   ', '1', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (15, '化工类产品', 0, '1', '2   ', '1', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (20, '医药及医疗器械', 0, '1', '2   ', '1', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (34, '化纤纤维', 4, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (35, '纱线', 4, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (40, '铝', 6, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (46, '贵金属', 6, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (50, '包装纸', 8, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (55, '油脂类', 9, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (65, '洋酒', 11, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (81, '其他', 16, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (87, '电子元件', 18, '1', '2   ', '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (107, '热轧带钢', 24, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (111, '大中型材', 25, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (133, '弹簧钢', 28, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (138, '焊线', 28, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (142, '耐磨钢', 28, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (149, '锰铁', 30, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (152, '铬矿', 30, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (162, '无烟煤', 33, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (167, '腈纶短纤', 34, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (240, '天然气', 48, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (242, '纸浆', 49, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (258, '菜籽', 52, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (262, '面粉', 53, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (268, '肉骨粉', 54, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (272, '棉油', 55, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (280, '猪肉', 56, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (284, '白玻', 57, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (285, '灰玻', 57, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (288, '原木', 58, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (293, '卫生陶瓷', 59, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (298, '剑南春', 60, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (302, '塔牌', 60, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (308, '长城', 62, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (311, '古越龙山', 63, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into B_PBC_MTG_CLASS (MORTGAGE_CODE, MORTGAGE_NAME, PARENT_CODE, STATUS, MORTGAGE_TYPE, LEVELS, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6, EXT7, EXT8, RATION, UNITS, UNITSNAME, REVALUATION_INTERVAL, TLRCD, CRT_TIME, BRCODE, LAST_UPD_TLRCD, LAST_UPD_TIME, LAST_UPD_BRCODE)
values (313, '百威啤酒', 64, '1', '2   ', '3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

commit;
