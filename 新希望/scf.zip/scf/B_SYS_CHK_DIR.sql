﻿
insert into B_SYS_CHK_DIR (MDL_ID, MDL_NM, STAT)
values ('DUEBILLCHK', '出账申请拦截', null);

insert into B_SYS_CHK_DIR (MDL_ID, MDL_NM, STAT)
values ('LNAPPCHK', '业务申请拦截', null);

insert into B_SYS_CHK_DIR (MDL_ID, MDL_NM, STAT)
values ('LNCONCHK', '合同生效拦截', null);

insert into B_SYS_CHK_DIR (MDL_ID, MDL_NM, STAT)
values ('ADDGNTYCONCHK', '抵/质押合同补录拦截', null);

insert into B_SYS_CHK_DIR (MDL_ID, MDL_NM, STAT)
values ('FFKCHK', '应收类放款申请拦截', null);

insert into B_SYS_CHK_DIR (MDL_ID, MDL_NM, STAT)
values ('FPRESSCHK', '应收账款催收业务申请拦截', null);

insert into B_SYS_CHK_DIR (MDL_ID, MDL_NM, STAT)
values ('FIMPAIRMENTCHK', '应收账款减值业务申请拦截', null);

insert into B_SYS_CHK_DIR (MDL_ID, MDL_NM, STAT)
values ('FCHARGEOFFCHK', '应收账款核销业务申请拦截', null);

insert into B_SYS_CHK_DIR (MDL_ID, MDL_NM, STAT)
values ('FCNTCHK', '应收类合同签订业务拦截', null);

insert into B_SYS_CHK_DIR (MDL_ID, MDL_NM, STAT)
values ('FAPPLICHK', '应收类业务申请拦截', null);

insert into B_SYS_CHK_DIR (MDL_ID, MDL_NM, STAT)
values ('YSZRDEBTINFO', '应收类转让单据唯一性', null);

insert into B_SYS_CHK_DIR (MDL_ID, MDL_NM, STAT)
values ('FBACKTRANSFERCHK', '应收账款反转让业务申请拦截', null);

insert into B_SYS_CHK_DIR (MDL_ID, MDL_NM, STAT)
values ('DCRCHK', '授信额度申请拦截', '1');

insert into B_SYS_CHK_DIR (MDL_ID, MDL_NM, STAT)
values ('22', '22', null);

insert into B_SYS_CHK_DIR (MDL_ID, MDL_NM, STAT)
values ('123', '123', null);

insert into B_SYS_CHK_DIR (MDL_ID, MDL_NM, STAT)
values ('FREPAYMENT', '应收账款回款业务申请拦截', null);

insert into B_SYS_CHK_DIR (MDL_ID, MDL_NM, STAT)
values ('FDEBTOUTPOOL', '应收账款出池业务申请拦截', null);

insert into B_SYS_CHK_DIR (MDL_ID, MDL_NM, STAT)
values ('FDISPUTEREGISTER', '应收账款商纠登记业务拦截', null);

commit;
