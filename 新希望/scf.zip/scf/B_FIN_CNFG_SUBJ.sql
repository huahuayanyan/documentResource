﻿
insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2100', '流动负债合计', null, '0', 80, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2299', '非流动负债：', null, '0', 82, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2211', '　长期借款', null, '0', 83, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2212', '　应付债券', null, '0', 84, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2213', '　长期应付款', null, '0', 85, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2214', '　专项应付款', null, '0', 86, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2215', '　预计负债', null, '0', 87, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2216', '　递延所得税负债', null, '0', 88, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2221', '　其他非流动负债', null, '0', 91, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2200', '非流动负债合计', null, '0', 93, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2300', '负债合计', null, '0', 95, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2499', '所有者权益（或股东权益）：', null, '0', 97, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2411', '　实收资本（或股本）', null, '0', 99, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2412', '　资本公积', null, '0', 100, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2413', '　　减：库存股', null, '0', 101, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2414', '　盈余公积', null, '0', 102, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2415', '　一般风险准备', null, '0', 103, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2416', '　未分配利润', null, '0', 104, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2417', '　外币报表折算差额', null, '0', 106, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2418', '　归属于母公司所有者权益', null, '0', 108, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2421', '　少数股东权益', null, '0', 110, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2431', '　所有者权益合计', null, '0', 112, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2400', '负债和所有者(或股东)权益总计', null, '0', 114, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4100', '一、经营活动产生的现金流量：', null, '0', 1, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4111', '　销售商品、提供劳务收到的现金', null, '0', 2, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4112', '　收到的税费返还', null, '0', 3, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4113', '　收到的其他与经营活动有关的现金', null, '0', 4, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4114', '　　　经营活动现金流入小计', null, '0', 5, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4121', '　购买商品、接受劳务支付的现金', null, '0', 6, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4122', '　支付给职工以及为职工支付的现金', null, '0', 7, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4123', '　支付的各项税费', null, '0', 8, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4124', '　支付的其它与经营活动有关现金', null, '0', 9, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4125', '　　　经营活动现金流出小计', null, '0', 10, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4126', '　　经营活动产生的现金流量净额', null, '0', 11, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4200', '二、投资活动产生的现金流量：', null, '0', 12, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4211', '　收回投资所收到的现金', null, '0', 13, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4212', '　　其中：收回转让给集团外公司（集团外关联方和非关联方）的投资所收到的现金', null, '0', 14, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4213', '	　取得投资收益所收到的现金', null, '0', 15, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4214', '　　其中：从集团外公司（集团外关联方和非关联方）取得的投资收益所收到的现金', null, '0', 16, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4215', '　处置固定资产、无形资产和其他长期资产收回的现金净额', null, '0', 17, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4216', '　处置子公司及其他营业单位收到的现金净额', null, '0', 18, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4217', '　收到的其他与投资活动有关的现金', null, '0', 19, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4218', '　　　投资活动现金流入小计', null, '0', 20, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4221', '　购建固定资产、无形资产和其他长期资产所支付的现金', null, '0', 21, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4222', '　投资所支付的现金', null, '0', 22, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4223', '　　其中：投资集团外公司（集团外关联方和非关联方）所支付的现金', null, '0', 23, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4224', '　取得子公司及其他营业单位支付的现金净额', null, '0', 24, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4225', '　支付的其他与投资活动有关的现金', null, '0', 25, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4227', '　　　投资活动现金流出小计', null, '0', 26, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4228', '　　投资活动产生的现金流量净额', null, '0', 27, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4300', '三、筹资活动产生的现金流量：', null, '0', 28, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4301', '　吸收投资所收到的现金', null, '0', 29, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4302', '　　其中：吸收集团外公司（集团外关联方和非关联方）投资所收到的现金', null, '0', 30, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4303', '　取得借款收到的现金', null, '0', 31, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4304', '　　其中：从集团外公司（集团外关联方和非关联方）借款所收到的现金', null, '0', 32, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4305', '　发行债券收到的现金', null, '0', 33, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4306', '　收到的其他与筹资活动有关的现金', null, '0', 34, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4307', '　　　筹资活动现金流入小计', null, '0', 35, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4311', '　偿还债务所支付的现金', null, '0', 36, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4312', '　　其中：偿还集团外公司（集团外关联方和非关联方）债务所支付的现金', null, '0', 37, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4313', '　分配股利、利润和偿付利息所支付的现金', null, '0', 38, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4314', '　　其中：支付给集团外公司（集团外关联方和非关联方）的股利、利润', null, '0', 39, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1199', '流动资产：', null, '0', 1, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1111', '　货币资金', null, '0', 2, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1198', null, null, '0', 113, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1121', '　拆出资金', null, '0', 4, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1131', '　交易性金融资产', null, '0', 5, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1141', '　应收票据', null, '0', 6, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1142', '　应收账款', null, '0', 7, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1143', '　　减：应收账款坏账准备', null, '0', 8, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1144', '　应收账款净额', null, '0', 9, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1151', '　保理应收账款', null, '0', 10, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1152', '　预付款项', null, '0', 11, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1153', '　应收利息', null, '0', 12, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1154', '　应收股利', null, '0', 13, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1161', '　其他应收款', null, '0', 14, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1162', '　　减：其他应收款坏账准备', null, '0', 15, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1163', '　其他应收款净额', null, '0', 16, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1164', '　买入返售金融资产', null, '0', 17, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1171', '　存货', null, '0', 18, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1172', '　　减：存货跌价准备', null, '0', 19, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1173', '　存货净额', null, '0', 20, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1181', '　一年内到期的非流动资产', null, '0', 21, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1191', '　其他流动资产', null, '0', 22, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1100', '流动资产合计', null, '0', 23, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1299', '非流动资产：', null, '0', 25, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1211', '　发放贷款及垫款', null, '0', 26, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1212', '　可供出售金融资产', null, '0', 27, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1213', '　持有至到期投资', null, '0', 28, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1214', '　　减:持有至到期投资减值准备', null, '0', 29, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1215', '　持有至到期投资净额', null, '0', 30, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1221', '　长期应收款', null, '0', 31, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1222', '　长期股权投资', null, '0', 32, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1223', '　　减：长期股权投资减值准备', null, '0', 33, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1224', '　长期股权投资净额', null, '0', 34, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1241', '　投资性房地产', null, '0', 35, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1242', '　固定资产', null, '0', 36, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1243', '　　减：累计折旧', null, '0', 37, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1244', '　　减：固定资产减值准备', null, '0', 38, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1245', '　固定资产净额', null, '0', 39, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1251', '　在建工程', null, '0', 40, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1252', '　　减：在建工程减值准备', null, '0', 41, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1253', '　在建工程净额', null, '0', 42, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1261', '　工程物资', null, '0', 43, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1262', '　固定资产清理', null, '0', 44, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1271', '　无形资产', null, '0', 45, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1272', '　　减：累计摊销', null, '0', 46, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1273', '　　减：无形资产减值准备', null, '0', 47, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1274', '　无形资产净额', null, '0', 48, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1281', '　开发支出', null, '0', 49, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1282', '　商誉', null, '0', 50, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1283', '　　减:商誉减值准备', null, '0', 51, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1284', '　商誉净额', null, '0', 52, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1291', '　长期待摊费用', null, '0', 53, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1292', '　递延所得税资产', null, '0', 54, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1293', '　其他非流动资产', null, '0', 55, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1200', '非流动资产合计', null, '0', 56, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ1000', '资产总计', null, '0', 57, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2199', '流动负债：', null, '0', 58, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2111', '　短期借款', null, '0', 59, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2112', '　保理借款', null, '0', 60, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2113', '　向中央银行借款', null, '0', 61, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2114', '　吸收存款及同业存放', null, '0', 62, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2115', '　拆入资金', null, '0', 63, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2116', '　交易性金融负债', null, '0', 64, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2121', '　应付票据', null, '0', 65, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2122', '　应付账款', null, '0', 66, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2123', '　预收款项', null, '0', 67, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2124', '　卖出回购金融资产款', null, '0', 68, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2131', '　应付短期融资券', null, '0', 69, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2132', '　应付职工薪酬', null, '0', 70, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2133', '　应交税费', null, '0', 71, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2134', '　应付利息', null, '0', 72, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2135', '　应付股利', null, '0', 73, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2141', '　其他应付款', null, '0', 74, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2151', '　一年内到期的非流动负债', null, '0', 78, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4316', '　支付的其他与筹资活动有关的现金', null, '0', 41, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4317', '　　　筹资活动现金流出小计', null, '0', 42, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4318', '　　筹资活动产生的现金流量净额', null, '0', 43, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4400', '四、汇率变动对现金的影响额', null, '0', 44, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4500', '五、现金及现金等价物净增加额', null, '0', 45, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4501', '加：期初现金及现金等价物余额', null, '0', 46, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4600', '六、期末现金及现金等价物余额', null, '0', 47, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL1198', null, null, '0', 78, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL5999', '补充资料', null, '0', 49, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL5100', '1.将净利润调节为经营活动的现金流量：', null, '0', 50, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL5111', '　　净利润', null, '0', 51, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL5112', '　　　加：资产减值准备', null, '0', 52, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL5113', '　　固定资产折旧、油气资产折耗、生产性生物资产折旧', null, '0', 53, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL5114', '　　无形资产摊销', null, '0', 54, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL5115', '　　长期待摊费用摊销', null, '0', 55, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL5116', '　　处置固定资产、无形资产和其他长期资产的损失（收益以“－”号填列）', null, '0', 56, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL5117', '　　固定资产报废损失（收益以“－”号填列）', null, '0', 57, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL5118', '　　公允价值变动损失（收益以“－”号填列）', null, '0', 58, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL5119', '　　财务费用（收益以“－”号填列）', null, '0', 59, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL5120', '　　投资损失（收益以“－”号填列）', null, '0', 60, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL5121', '　递延所得税资产减少（增加以“－”号填列）', null, '0', 61, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL5122', '　递延所得税负债增加（减少以“－”号填列）', null, '0', 62, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL5123', '　存货的减少（增加以“－”号填列）', null, '0', 63, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL5124', '　经营性应收项目的减少（增加以“－”号填列）', null, '0', 64, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL5125', '　经营性应付项目的增加（减少以“－”号填列）', null, '0', 65, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL5126', '　其他', null, '0', 66, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL5127', '　经营活动产生的现金流量净额', null, '0', 67, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL5200', '2.不涉及现金收支的投资和筹资活动：', null, '0', 68, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL5201', '　　债务转为资本', null, '0', 69, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL5202', '　　一年内到期的可转换公司债券', null, '0', 70, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL5203', '　　融资租入固定资产', null, '0', 71, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL5300', '3.现金及现金等价物净增加情况：', null, '0', 72, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL5301', '　现金的期末余额', null, '0', 73, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL5302', '　减：现金的期初余额', null, '0', 74, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL5303', '　加：现金等价物的期末余额', null, '0', 75, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL5304', '　减：现金等价物的期初余额', null, '0', 76, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL5404', '　现金及现金等价物净增加额', null, '0', 77, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL6100', '一、现金', null, '0', 79, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL6101', '　其中：库存现金', null, '0', 80, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL6102', '　　可随时用于支付的银行存款', null, '0', 81, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL6103', '　　可随时用于支付的其他货币资金', null, '0', 82, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL6104', '　　可用于支付的存放中央银行款项', null, '0', 83, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL6105', '　　存放同业款项', null, '0', 84, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL6106', '　　拆放同业款项', null, '0', 85, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL6200', '二、现金等价物', null, '0', 86, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL6201', '　其中：三个月内到期的债券投资', null, '0', 87, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL6300', '三、银行透支（以负数填列）', null, '0', 88, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL6400', '四、期末现金及现金等价物余额', null, '0', 89, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL6401', '　其中：母公司或集团内子公司使用受限制的现金和现金等价物', null, '0', 90, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SUBJ0062', '偿债能力', null, '0', null, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SUBJ0063', '运营能力', null, '0', null, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SUBJ0064', '发展能力', null, '0', null, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SUBJ0065', '现金流', null, '0', null, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SYB3100', '一、营业收入', null, '0', 1, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SYB3111', '其中:主营业务收入', null, '0', 2, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SYB3112', '　　　其他业务收入', null, '0', 3, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SYB3200', '二、营业成本', null, '0', 4, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SYB3211', '其中:主营业务成本', null, '0', 5, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SYB3212', '　　　其他业务支出', null, '0', 6, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SYB3213', '　减:营业税金及附加', null, '0', 7, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SYB3214', '　减:销售费用', null, '0', 8, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SYB3215', '　　　管理费用', null, '0', 9, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SYB3216', '　　　财务费用', null, '0', 10, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SYB3221', '　　　资产减值损失', null, '0', 11, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SYB3222', '　加:公允价值变动收益（损失以“-”填列）', null, '0', 12, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SYB3223', '　加:投资收益（亏损以“-”填列）', null, '0', 13, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SYB3224', '　　　其中:对联营企业的投资收益', null, '0', 14, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SYB3225', '　　　　　对合营企业的投资收益', null, '0', 15, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SYB3300', '三、营业利润（亏损以“-”填列）', null, '0', 16, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SYB3331', '　加: 营业外收入', null, '0', 17, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SYB3332', '　减: 营业外支出', null, '0', 18, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SYB3333', '　　　其中:非流动资产处置损失', null, '0', 19, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SYB3400', '四、利润总额（亏损总额以“-”填列）', null, '0', 20, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SYB3411', '　减:所得税费用', null, '0', 21, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SYB3500', '五、净利润（净亏损以“-”填列）', null, '0', 22, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SYB3501', '　归属于母公司所有者的净利润', null, '0', 23, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SYB3502', '　少数股东损益', null, '0', 24, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SYB3600', '六、每股收益', null, '0', 25, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SYB3601', '　（一）基本每股收益', null, '0', 26, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SYB3602', '　（二）稀释每股收益', null, '0', 27, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('XJLL4315', '　　其中：支付给集团外公司（集团外关联方和非关联方）的利息', null, '0', 40, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0820', '总资产报酬率(%)', null, '0', null, 'N3400[3]*100*2/(A1000[3]+N1000[3]) ', '01');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0839', '资本积累率(%)', null, '0', null, '(N2431[3]-A2431[3])*100/A2431[3]', '01');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0821', '存货周转率(次)', null, '0', null, 'N3211[3]*2/(A1171[3]+N1171[3])', '01');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0822', '应收帐款周转率(次)', null, '0', null, 'N3111[3]*2/(A1142[3]+N1142[3])', '01');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0402', '速动比率', null, '0', null, '(N1100[3]-N1171[3])*100/N2100[3]', '01');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0823', '现金比率', null, '0', null, '(N1111[3]+N1131[3]+N1141[3])*100/N2100[3]', '01');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0824', '经营活动现金净流量/短期债务', null, '0', null, 'N5127[3]/N2100[3]', '01');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0825', '资产负债率(%)', null, '0', null, 'N2300[3]*100/N1000[3]', '01');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0826', '经营活动现金净流量/总债务', null, '0', null, 'N5127[3]/N2300[3]', '01');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0202', '净资产收益率(%)', null, '0', null, 'N3500[3]*100*2/(A2431[3]+N2431[3])', '01');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0827', '现金流动负债比率', null, '0', null, 'N5127[3]*100/N2100[3]', '01');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0103', '净利润增长率(%)', null, '0', null, '(N3500[3]-A3500[3])*100/A3500[3]', '01');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0828', '长期资产适合率(%)', null, '0', null, '(N2431[3]+N2200[3])*100/(N1242[3]+N1213[3]+N1222[3])', '01');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0829', '总资产周转率(次)', null, '0', null, 'N3111[3]*2/(A1000[3]+N1000[3])', '01');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0830', '利息保障倍数', null, '0', null, '(N3400[3]+N4315[3])/N4315[3]', '01');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0831', '总债务/EBITDA(%)', null, '0', null, 'N2300[3]*100/(N3500[3]+N1292[3]+N1243[3]+N1272[3]+N1291[3]+N4315[3])', '01');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0832', '运营毛利润率(%)', null, '0', null, '(N3111[3]-N3211[3]-N3214[3])*100/N3111[3]', '01');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0833', '后台费用率(%)', null, '0', null, '(N3215[3]+N3111[3])*100/N3215[3]', '01');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0834', '净利润率(%)', null, '0', null, 'N3500[3]*100/N3111[3]', '01');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0835', '资金运营周期(天)', null, '0', null, '360*((A1142[3]+N1142[3])/(N3111[3]*2)+(A1171[3]+N1171[3])/(N3211[3]*2)-(A2122[3]+N2122[3])/(N3211[3]*2))', '01');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0104', '销售收入增长率(%)', null, '0', null, '(N3111[3]-A3111[3])*100/A3111[3]', '01');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0837', '研发投入比', null, '0', null, 'N1281[3]/N3111[3]', '01');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0838', '带息负债比率(%)', null, '0', null, '(N2111[3]+N2134[3]+N2151[3]+N2211[3])*100/N2300[3]', '01');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0502', '流动比率', null, '0', null, 'N1100[3]*100/N2100[3]', '01');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0105', '净利润增长率(%)', null, '0', null, '(N3500[3]-A3500[3])*100/A3500[3]', '03');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0106', '销售收入增长率(%)', null, '0', null, '(N3111[3]-A3111[3])*100/A3111[3]', '03');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0203', '净资产收益率(%)', null, '0', null, 'N3500[3]*100*2*2/(A2431[3]+N2431[3])', '03');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0403', '速动比率', null, '0', null, '(N1100[3]-N1171[3])*100/N2100[3]', '03');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0503', '流动比率', null, '0', null, 'N1100[3]*100/N2100[3]', '03');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0840', '总资产报酬率(%)', null, '0', null, 'N3400[3]*100*2*2/(A1000[3]+N1000[3]) ', '03');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0841', '存货周转率(次)', null, '0', null, 'N3211[3]*2*2/(A1171[3]+N1171[3])', '03');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0842', '应收帐款周转率(次)', null, '0', null, 'N3111[3]*2*2/(A1142[3]+N1142[3])', '03');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0843', '现金比率', null, '0', null, '(N1111[3]+N1131[3]+N1141[3])*100/N2100[3]', '03');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0844', '经营活动现金净流量/短期债务', null, '0', null, 'N5127[3]/N2100[3]', '03');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0845', '资产负债率(%)', null, '0', null, 'N2300[3]*100/N1000[3]', '03');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0846', '经营活动现金净流量/总债务', null, '0', null, 'N5127[3]/N2300[3]', '03');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0847', '现金流动负债比率', null, '0', null, 'N5127[3]*100*2/N2100[3]', '03');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0848', '长期资产适合率(%)', null, '0', null, '(N2431[3]+N2200[3])*100/(N1242[3]+N1213[3]+N1222[3])', '03');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0849', '总资产周转率(次)', null, '0', null, 'N3111[3]*2*2/(A1000[3]+N1000[3])', '03');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0850', '利息保障倍数', null, '0', null, '(N3400[3]+N4315[3])/N4315[3]', '03');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0851', '总债务/EBITDA(%)', null, '0', null, 'N2300[3]*100*2/(N3500[3]+N1292[3]+N1243[3]+N1272[3]+N1291[3]+N4315[3])', '03');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0852', '运营毛利润率(%)', null, '0', null, '(N3111[3]-N3211[3]-N3214[3])*100/N3111[3]', '03');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0853', '后台费用率(%)', null, '0', null, '(N3215[3]+N3111[3])*100/N3215[3]', '03');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0854', '净利润率(%)', null, '0', null, 'N3500[3]*100/N3111[3]', '03');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0855', '资金运营周期(天)', null, '0', null, '360*((A1142[3]+N1142[3])/(N3111[3]*2)+(A1171[3]+N1171[3])/(N3211[3]*2)-(A2122[3]+N2122[3])/(N3211[3]*2)*2)', '03');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0856', '研发投入比', null, '0', null, 'N1281[3]/N3111[3]', '03');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0857', '带息负债比率(%)', null, '0', null, '(N2111[3]+N2134[3]+N2151[3]+N2211[3])*100/N2300[3]', '03');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0858', '资本积累率(%)', null, '0', null, '(N2431[3]-A2431[3])*100/A2431[3]', '03');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0801', '总资产报酬率(%)', null, '0', null, 'N3400[3]*100*2/(A1000[3]+N1000[3]) ', '04');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0816', '资本积累率(%)', null, '0', null, '(N2431[3]-A2431[3])*100/A2431[3]', '04');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0802', '存货周转率(次)', null, '0', null, 'N3211[3]*2/(A1171[3]+N1171[3])', '04');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0803', '应收帐款周转率(次)', null, '0', null, 'N3111[3]*2/(A1142[3]+N1142[3])', '04');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0401', '速动比率', null, '0', null, '(N1100[3]-N1171[3])*100/N2100[3]', '04');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0817', '现金比率', null, '0', null, '(N1111[3]+N1131[3]+N1141[3])*100/N2100[3]', '04');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0819', '经营活动现金净流量/短期债务', null, '0', null, 'N5127[3]/N2100[3]', '04');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0804', '资产负债率(%)', null, '0', null, 'N2300[3]*100/N1000[3]', '04');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0818', '经营活动现金净流量/总债务', null, '0', null, 'N5127[3]/N2300[3]', '04');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0201', '净资产收益率(%)', null, '0', null, 'N3500[3]*100*2/(A2431[3]+N2431[3])', '04');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0805', '现金流动负债比率', null, '0', null, 'N5127[3]*100/N2100[3]', '04');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0101', '净利润增长率1(%)', '111', '0', null, '(N3500[3]-A3500[3])*100/A3500[3]', '04');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0809', '长期资产适合率(%)', null, '0', null, '(N2431[3]+N2200[3])*100/(N1242[3]+N1213[3]+N1222[3])', '04');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0806', '总资产周转率(次)', null, '0', null, 'N3111[3]*2/(A1000[3]+N1000[3])', '04');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0807', '利息保障倍数', null, '0', null, '(N3400[3]+N4315[3])/N4315[3]', '04');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0808', '总债务/EBITDA(%)', null, '0', null, 'N2300[3]*100/(N3500[3]+N1292[3]+N1243[3]+N1272[3]+N1291[3]+N4315[3])', '04');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0810', '运营毛利润率(%)', null, '0', null, '(N3111[3]-N3211[3]-N3214[3])*100/N3111[3]', '04');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0811', '后台费用率(%)', null, '0', null, '(N3215[3]+N3111[3])*100/N3215[3]', '04');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0812', '净利润率(%)', null, '0', null, 'N3500[3]*100/N3111[3]', '04');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0813', '资金运营周期(天)', null, '0', null, '360*((A1142[3]+N1142[3])/(N3111[3]*2)+(A1171[3]+N1171[3])/(N3211[3]*2)-(A2122[3]+N2122[3])/(N3211[3]*2))', '04');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0102', '销售收入增长率(%)', null, '0', null, '(N3111[3]-A3111[3])*100/A3111[3]', '04');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0814', '研发投入比', null, '0', null, 'N1281[3]/N3111[3]', '04');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0815', '带息负债比率(%)', null, '0', null, '(N2111[3]+N2134[3]+N2151[3]+N2211[3])*100/N2300[3]', '04');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('CWZB0501', '流动比率', null, '0', null, 'N1100[3]*100/N2100[3]', '04');

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SUBJ0066', '集团财务指标测试测试', null, '0', null, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SUBJ0061', '盈利能力', null, '0', null, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('ZCFZ2161', '　其他流动负债', null, '0', 79, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SUBJ0069', '333', '财报333', '0', null, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SUBJ0068', '2', '2', '0', null, null, null);

insert into B_FIN_CNFG_SUBJ (SUBJ_ID, SUBJ_NM, REM, DEL_FLG, ROW_NUMBER, INDEX_EXPRESS, RP_SOURCE)
values ('SUBJ0072', '2222', '2', '0', null, null, null);

commit;
