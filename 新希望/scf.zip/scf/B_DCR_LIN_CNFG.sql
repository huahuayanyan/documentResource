﻿
insert into B_DCR_LIN_CNFG (TYP_ID, TYP_NM, CHK_EXPR, RLT_TYP)
values ('chk03', '限制币种', null, 'curcd');

insert into B_DCR_LIN_CNFG (TYP_ID, TYP_NM, CHK_EXPR, RLT_TYP)
values ('chk01', '限制机构', 'chk01', 'selectOrgCd');

insert into B_DCR_LIN_CNFG (TYP_ID, TYP_NM, CHK_EXPR, RLT_TYP)
values ('chk04', '保证金比例', null, null);

insert into B_DCR_LIN_CNFG (TYP_ID, TYP_NM, CHK_EXPR, RLT_TYP)
values ('01', '01', '01', 'selectOrgCd');

insert into B_DCR_LIN_CNFG (TYP_ID, TYP_NM, CHK_EXPR, RLT_TYP)
values ('chk02', '限制担保方式', null, 'guaranteeType');

insert into B_DCR_LIN_CNFG (TYP_ID, TYP_NM, CHK_EXPR, RLT_TYP)
values ('1', '1', '1', 'curcd');

insert into B_DCR_LIN_CNFG (TYP_ID, TYP_NM, CHK_EXPR, RLT_TYP)
values ('2', '2', '2', 'selectOrgCd');

insert into B_DCR_LIN_CNFG (TYP_ID, TYP_NM, CHK_EXPR, RLT_TYP)
values ('3', '3', '3', 'guaranteeType');

insert into B_DCR_LIN_CNFG (TYP_ID, TYP_NM, CHK_EXPR, RLT_TYP)
values ('4', '4', '4', null);

insert into B_DCR_LIN_CNFG (TYP_ID, TYP_NM, CHK_EXPR, RLT_TYP)
values ('5', '5', null, null);

insert into B_DCR_LIN_CNFG (TYP_ID, TYP_NM, CHK_EXPR, RLT_TYP)
values ('6', '6', null, null);

commit;
