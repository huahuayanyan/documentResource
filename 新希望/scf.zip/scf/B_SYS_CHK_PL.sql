﻿
insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201701090023', 'CNFG201701090012', '检查出账模式', 'DUEBILL', 1, '1', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201612300021', 'CNFG201612300010', '检查冻结保证金列表是否为空', 'LOWERPRICE', 1, '1', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201612300022', 'CNFG201612300011', '检查冻结保证金列表信息完整性', 'LOWERPRICE', 2, '1', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201701090024', 'CNFG201701090012', '检查出账模式', 'DUEBILLCHK', 1, '1', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201612100014', 'CNFG201612100003', '检查客户分项额度', 'DCRCHK', 2, '1', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201612150015', 'CNFG201612150004', '检查业务申请产品信息', 'LNAPPCHK', 1, '1', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201612150016', 'CNFG201612150005', '检查业务申请担保合同信息', 'LNAPPCHK', 2, '1', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201612220018', 'CNFG201612220007', '检查业务申请与担保合同类型一致性', 'LNAPPCHK', 3, '1', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201612230020', 'CNFG201612230009', '检查业务合同信息完整性', 'LNCONCHK', 1, '1', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201612090012', 'CNFG201612090002', '检查客户综合授信唯一性', 'DCRCHK', 1, '1', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201701090025', 'CNFG201701090014', '检查抵/质押合同是否补录成功', 'ADDGNTYCONCHK', 1, '1', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201612150017', 'CNFG201612150006', '检查业务申请担保物信息', 'LNAPPCHK', 4, '1', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201705190026', 'CNFG201706010034', '业务合同完整性校验', 'FCNTCHK', 1, '1', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201705270027', 'CNFG201705270033', '放款申请数据失衡', 'FFKCHK', 1, '1', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201706150030', 'CNFG201706150036', '校验金额平衡性', 'FPRESSCHK', 1, '1', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201706150031', 'CNFG201706150036', '校验金额平衡性', 'FIMPAIRMENTCHK', 1, '1', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201706150032', 'CNFG201706150036', '校验金额平衡性', 'FBACKTRANSFERCHK', 1, '1', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201706010028', 'CNFG201705190032', '应收类业务校验', 'FAPPLICHK', 1, '1', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201706150033', 'CNFG201706150036', '校验金额平衡性', 'FCHARGEOFFCHK', 1, '1', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201706210034', 'CNFG201706210037', '应收类文件完整性校验', 'FAPPLICHK', 2, '1', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201706070029', 'CNFG201706070035', '应收类转让单据唯一性校验', 'YSZRDEBTINFO', 1, '1', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201612230019', 'CNFG201612230008', '检查担保合同信息完整性', 'LNCONCHK', 2, '1', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201707170037', 'CNFG201612230008', '12', '1', 12, '0', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201707170038', 'CNFG201612150004', '2', '1', 2, '0', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201707170039', 'CNFG201612150004', '3', '1', 3, '0', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201707170040', 'CNFG201612150004', '4', '1', 4, '0', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201707170041', 'CNFG201701090012', '5', '1', 5, '0', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201707170042', 'CNFG201701090012', '6', '1', 6, '0', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201707170043', 'CNFG201612230008', '7', '1', 7, '0', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201707170044', 'CNFG201612090002', '8', '1', 8, '1', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201707170045', 'CNFG201701090012', '9', '1', 9, '0', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201707170046', 'CNFG201612090002', '10', '1', 10, '0', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201707170047', 'CNFG201612150004', '11', '1', 11, '0', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201707120035', 'CNFG201707120038', '应收类商纠登记业务拦截', 'FSJDJCHECK', 1, '1', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201707120036', 'CNFG201707120039', '应收类商纠解除业务拦截', 'FSJJCCHK', 1, '1', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201707200048', 'CNFG201612230008', '11', '11', 11, '0', '0');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201707240050', 'CNFG201612150004', '123', '123', 123, '0', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201707180040', 'CNFG201707180038', '检验池信息风险敞口', 'FDISPUTEREGISTER', 1, '0', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201707180041', 'CNFG201707180038', '检验池信息风险敞口', 'FDEBTOUTPOOL', 1, '0', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201707180035', 'CNFG201707180038', '检验池信息风险敞口', 'FIMPAIRMENTCHK', 2, '0', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201707180036', 'CNFG201707180038', '检验池信息风险敞口', 'FCHARGEOFFCHK', 2, '0', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201707180037', 'CNFG201707180038', '检验池信息风险敞口', 'FFKCHK', 2, '1', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201707180038', 'CNFG201707180038', '检验池信息风险敞口', 'FBACKTRANSFERCHK', 2, '0', '1');

insert into B_SYS_CHK_PL (CHK_PL_ID, CHK_IT_ID, NM, MDL_ID, ORD, DEAL, STAT)
values ('PL201707180039', 'CNFG201707180038', '检验池信息风险敞口', 'FREPAYMENT', 1, '0', '1');

commit;
