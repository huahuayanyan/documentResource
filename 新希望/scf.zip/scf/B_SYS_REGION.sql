﻿
insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('939', '320401', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2033', '430203', '芦淞区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2034', '430204', '石峰区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2035', '430211', '天元区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2036', '430221', '株洲县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2037', '430223', '攸县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2038', '430224', '茶陵县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2039', '430225', '炎陵县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2040', '430281', '醴陵市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2041', '430300', '湘潭市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2042', '430301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2043', '430302', '雨湖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2044', '430304', '岳塘区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2045', '430321', '湘潭县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2046', '430381', '湘乡市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2047', '430382', '韶山市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2048', '430400', '衡阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2049', '430401', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2050', '430405', '珠晖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2051', '430406', '雁峰区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2052', '430407', '石鼓区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2053', '430408', '蒸湘区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2054', '430412', '南岳区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2055', '430421', '衡阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2056', '430422', '衡南县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2057', '430423', '衡山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2058', '430424', '衡东县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2059', '430426', '祁东县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2060', '430481', '耒阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2061', '430482', '常宁市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2062', '430500', '邵阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2063', '430501', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2064', '430502', '双清区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2065', '430503', '大祥区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2066', '430511', '北塔区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2067', '430521', '邵东县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2068', '430522', '新邵县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2069', '430523', '邵阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2070', '430524', '隆回县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2071', '430525', '洞口县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2072', '430527', '绥宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2073', '430528', '新宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2074', '430529', '城步苗族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2075', '430581', '武冈市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2076', '430600', '岳阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2077', '430601', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2078', '430602', '岳阳楼区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2079', '430603', '云溪区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2080', '430611', '君山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2081', '430621', '岳阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2082', '430623', '华容县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2083', '430624', '湘阴县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2084', '430626', '平江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2085', '430681', '汨罗市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2086', '430682', '临湘市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2087', '430700', '常德市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2088', '430701', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2089', '430702', '武陵区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2090', '430703', '鼎城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2091', '430721', '安乡县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2092', '430722', '汉寿县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2093', '430723', '澧县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2094', '430724', '临澧县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2095', '430725', '桃源县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2096', '430726', '石门县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2097', '430781', '津市市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2098', '430800', '张家界市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2099', '430801', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2100', '430802', '永定区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2101', '430811', '武陵源区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2102', '430821', '慈利县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2103', '430822', '桑植县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2104', '430900', '益阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2105', '430901', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2106', '430902', '资阳区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2107', '430903', '赫山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2108', '430921', '南县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2109', '430922', '桃江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2110', '430923', '安化县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2111', '430981', '沅江市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2112', '431000', '郴州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2113', '431001', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2114', '431002', '北湖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2115', '431003', '苏仙区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2116', '431021', '桂阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2117', '431022', '宜章县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2118', '431023', '永兴县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2119', '431024', '嘉禾县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2120', '431025', '临武县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2121', '431026', '汝城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2122', '431027', '桂东县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2123', '431028', '安仁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2124', '431081', '资兴市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2125', '431100', '永州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('761', '230305', '梨树区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('762', '230306', '城子河区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('763', '230307', '麻山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('764', '230321', '鸡东县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('765', '230381', '虎林市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('766', '230382', '密山市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('767', '230400', '鹤岗市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('768', '230401', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('769', '230402', '向阳区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('770', '230403', '工农区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('771', '230404', '南山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('772', '230405', '兴安区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('773', '230406', '东山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('774', '230407', '兴山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('775', '230421', '萝北县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('776', '230422', '绥滨县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('777', '230500', '双鸭山市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('778', '230501', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('779', '230502', '尖山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('780', '230503', '岭东区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('781', '230505', '四方台区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('782', '230506', '宝山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('783', '230521', '集贤县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('784', '230522', '友谊县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('785', '230523', '宝清县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('786', '230524', '饶河县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('787', '230600', '大庆市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('788', '230601', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('789', '230602', '萨尔图区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('790', '230603', '龙凤区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('791', '230604', '让胡路区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('792', '230605', '红岗区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('793', '230606', '大同区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('794', '230621', '肇州县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('795', '230622', '肇源县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('796', '230623', '林甸县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('797', '230624', '杜尔伯特蒙古族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('798', '230700', '伊春市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('799', '230701', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('800', '230702', '伊春区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('801', '230703', '南岔区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('802', '230704', '友好区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('803', '230705', '西林区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('804', '230706', '翠峦区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('805', '230707', '新青区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('806', '230708', '美溪区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('807', '230709', '金山屯区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('808', '230710', '五营区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('809', '230711', '乌马河区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('810', '230712', '汤旺河区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('811', '230713', '带岭区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('812', '230714', '乌伊岭区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('813', '230715', '红星区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('814', '230716', '上甘岭区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('815', '230722', '嘉荫县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('816', '230781', '铁力市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('817', '230800', '佳木斯市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('818', '230801', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('819', '230802', '佳木斯永红区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('820', '230803', '向阳区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('821', '230804', '前进区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('822', '230805', '东风区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('823', '230811', '郊区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('824', '230822', '桦南县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('825', '230826', '桦川县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('826', '230828', '汤原县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('827', '230833', '抚远县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('828', '230881', '同江市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('829', '230882', '富锦市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('830', '230900', '七台河市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('831', '230901', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('832', '230902', '新兴区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('833', '230903', '桃山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('834', '230904', '茄子河区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('835', '230921', '勃利县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('836', '231000', '牡丹江市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('837', '231001', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('838', '231002', '东安区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('839', '231003', '阳明区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('840', '231004', '爱民区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('841', '231005', '西安区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('842', '231024', '东宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('843', '231025', '林口县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('844', '231081', '绥芬河市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('845', '231083', '海林市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('846', '231084', '宁安市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('847', '231085', '穆棱市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('848', '231100', '黑河市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('849', '231101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('850', '231102', '爱辉区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('851', '231121', '嫩江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('852', '231123', '逊克县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('853', '231124', '孙吴县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('854', '231181', '北安市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('855', '231182', '五大连池市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('856', '231200', '绥化市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('857', '231201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('858', '231202', '北林区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('859', '231221', '望奎县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('860', '231222', '兰西县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('861', '231223', '青冈县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('862', '231224', '庆安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('863', '231225', '明水县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('864', '231226', '绥棱县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('865', '231281', '安达市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('866', '231282', '肇东市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('867', '231283', '海伦市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('868', '232700', '大兴安岭地区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('869', '232701', '加格达奇区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('870', '232702', '松岭区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('871', '232703', '新林区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('872', '232704', '呼中区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('873', '232721', '呼玛县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('874', '232722', '塔河县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('875', '232723', '漠河县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('876', '310000', '上海市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('877', '310100', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('878', '310101', '黄浦区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('879', '310103', '卢湾区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('880', '310104', '徐汇区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('881', '310105', '长宁区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('882', '310106', '静安区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('883', '310107', '普陀区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('884', '310108', '闸北区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('885', '310109', '虹口区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('886', '310110', '杨浦区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('887', '310112', '闵行区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('888', '310113', '宝山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('889', '310114', '嘉定区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('890', '310115', '浦东新区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('891', '310116', '金山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('892', '310117', '松江区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('893', '310118', '青浦区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('894', '310119', '南汇区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('895', '310120', '奉贤区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('896', '310200', '县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('897', '310230', '崇明县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('898', '320000', '江苏省', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('899', '320100', '南京市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('900', '320101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('901', '320102', '玄武区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('902', '320103', '白下区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('903', '320104', '秦淮区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('904', '320105', '建邺区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('905', '320106', '鼓楼区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('906', '320107', '下关区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('907', '320111', '浦口区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('908', '320113', '栖霞区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('909', '320114', '雨花台区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('910', '320115', '江宁区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('911', '320116', '六合区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('912', '320124', '溧水县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('913', '320125', '高淳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('914', '320200', '无锡市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('915', '320201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('916', '320202', '崇安区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('917', '320203', '南长区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('918', '320204', '北塘区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('919', '320205', '锡山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('920', '320206', '惠山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('921', '320211', '滨湖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('922', '320281', '江阴市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('923', '320282', '宜兴市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('924', '320292', '江苏省无锡市经济开发区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('925', '320300', '徐州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('926', '320301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('927', '320302', '鼓楼区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('928', '320303', '云龙区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('929', '320304', '九里区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('930', '320305', '贾汪区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('931', '320311', '泉山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('932', '320321', '丰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('933', '320322', '沛县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('934', '320323', '铜山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('935', '320324', '睢宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('936', '320381', '新沂市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('937', '320382', '邳州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('940', '320402', '天宁区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1525', '370200', '青岛市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1526', '370201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1527', '370202', '市南区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1528', '370203', '市北区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1529', '370205', '四方区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1530', '370211', '黄岛区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1531', '370212', '崂山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1532', '370213', '李沧区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1533', '370214', '城阳区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1534', '370281', '胶州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1535', '370282', '即墨市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1536', '370283', '平度市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1537', '370284', '胶南市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1538', '370285', '莱西市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1539', '370300', '淄博市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1540', '370301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1541', '370302', '淄川区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1542', '370303', '张店区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1543', '370304', '博山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1544', '370305', '临淄区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1545', '370306', '周村区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1546', '370321', '桓台县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1547', '370322', '高青县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1548', '370323', '沂源县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1549', '370400', '枣庄市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1550', '370401', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1551', '370402', '市中区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1552', '370403', '薛城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1553', '370404', '峄城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1554', '370405', '台儿庄区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1555', '370406', '山亭区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1556', '370481', '滕州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1557', '370500', '东营市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('321', '140823', '闻喜县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('322', '140824', '稷山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('323', '140825', '新绛县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('324', '140826', '绛县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('325', '140827', '垣曲县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('326', '140828', '夏县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('327', '140829', '平陆县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('328', '140830', '芮城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('329', '140881', '永济市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('330', '140882', '河津市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('331', '140900', '忻州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('332', '140901', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('333', '140902', '忻府区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('334', '140921', '定襄县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('335', '140922', '五台县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('336', '140923', '代县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('337', '140924', '繁峙县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('338', '140925', '宁武县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('339', '140926', '静乐县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('340', '140927', '神池县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('341', '140928', '五寨县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('342', '140929', '岢岚县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('343', '140930', '河曲县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('344', '140931', '保德县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('345', '140932', '偏关县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('346', '140981', '原平市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('347', '141000', '临汾市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('348', '141001', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('349', '141002', '尧都区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('350', '141021', '曲沃县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('351', '141022', '翼城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('352', '141023', '襄汾县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('353', '141024', '洪洞县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('354', '141025', '古县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('355', '141026', '安泽县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('356', '141027', '浮山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('357', '141028', '吉县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('358', '141029', '乡宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('359', '141030', '大宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('360', '141031', '隰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('361', '141032', '永和县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('362', '141033', '蒲县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('363', '141034', '汾西县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('364', '141081', '侯马市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('365', '141082', '霍州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('366', '141100', '吕梁市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('367', '141101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('368', '141102', '离石区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('369', '141121', '文水县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('370', '141122', '交城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('371', '141123', '兴县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('372', '141124', '临县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('373', '141125', '柳林县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('374', '141126', '石楼县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('375', '141127', '岚县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('376', '141128', '方山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('377', '141129', '中阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('378', '141130', '交口县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('379', '141181', '孝义市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('380', '141182', '汾阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('381', '150000', '内蒙古自治区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('382', '150100', '呼和浩特市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('383', '150101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('384', '150102', '新城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('385', '150103', '回民区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('386', '150104', '玉泉区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('387', '150105', '赛罕区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('388', '150121', '土默特左旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('389', '150122', '托克托县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('390', '150123', '和林格尔县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('391', '150124', '清水河县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('392', '150125', '武川县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('393', '150200', '包头市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('394', '150201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('395', '150202', '东河区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('396', '150203', '昆都仑区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('397', '150204', '青山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('398', '150205', '石拐区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('399', '150206', '白云鄂博矿区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('400', '150207', '九原区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('401', '150221', '土默特右旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('402', '150222', '固阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('403', '150223', '达尔罕茂明安联合旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('404', '150300', '乌海市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('405', '150301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('406', '150302', '海勃湾区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('407', '150303', '海南区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('408', '150304', '乌达区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('409', '150400', '赤峰市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('410', '150401', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('411', '150402', '红山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('412', '150403', '元宝山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('413', '150404', '松山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('414', '150421', '阿鲁科尔沁旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('415', '150422', '巴林左旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('416', '150423', '巴林右旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('417', '150424', '林西县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('418', '150425', '克什克腾旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('419', '150426', '翁牛特旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('420', '150428', '喀喇沁旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('421', '150429', '宁城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('422', '150430', '敖汉旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('423', '150500', '通辽市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('424', '150501', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('425', '150502', '科尔沁区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('426', '150521', '科尔沁左翼中旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('427', '150522', '科尔沁左翼后旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('428', '150523', '开鲁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('429', '150524', '库伦旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('430', '150525', '奈曼旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('431', '150526', '扎鲁特旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('432', '150581', '霍林郭勒市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('433', '150600', '鄂尔多斯市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('434', '150601', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('435', '150602', '东胜区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('436', '150621', '达拉特旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('437', '150622', '准格尔旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('438', '150623', '鄂托克前旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('439', '150624', '鄂托克旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('440', '150625', '杭锦旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('441', '150626', '乌审旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('442', '150627', '伊金霍洛旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('443', '150700', '呼伦贝尔市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('444', '150701', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('445', '150702', '海拉尔区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('446', '150721', '阿荣旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('447', '150722', '莫力达瓦达斡尔族自治旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('448', '150723', '鄂伦春自治旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('449', '150724', '鄂温克族自治旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('450', '150725', '陈巴尔虎旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('451', '150726', '新巴尔虎左旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('452', '150727', '新巴尔虎右旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('453', '150781', '满洲里市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('454', '150782', '牙克石市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('455', '150783', '扎兰屯市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('456', '150784', '额尔古纳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('457', '150785', '根河市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('458', '150800', '巴彦淖尔市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('459', '150801', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('460', '150802', '临河区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('461', '150821', '五原县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('462', '150822', '磴口县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('463', '150823', '乌拉特前旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('464', '150824', '乌拉特中旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('465', '150825', '乌拉特后旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('466', '150826', '杭锦后旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('467', '150900', '乌兰察布市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('468', '150901', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('469', '150902', '集宁区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('470', '150921', '卓资县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('471', '150922', '化德县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('472', '150923', '商都县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('473', '150924', '兴和县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('474', '150925', '凉城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('475', '150926', '察哈尔右翼前旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('476', '150927', '察哈尔右翼中旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('477', '150928', '察哈尔右翼后旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('478', '150929', '四子王旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('479', '150981', '丰镇市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('480', '152200', '兴安盟', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('481', '152201', '乌兰浩特市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('482', '152202', '阿尔山市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('483', '152221', '科尔沁右翼前旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('484', '152222', '科尔沁右翼中旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('485', '152223', '扎赉特旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('486', '152224', '突泉县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('487', '152500', '锡林郭勒盟', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('488', '152501', '二连浩特市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('489', '152502', '锡林浩特市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('490', '152522', '阿巴嘎旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('491', '152523', '苏尼特左旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('492', '152524', '苏尼特右旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('493', '152525', '东乌珠穆沁旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('494', '152526', '西乌珠穆沁旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('495', '152527', '太仆寺旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('496', '152528', '镶黄旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('497', '152529', '正镶白旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('498', '152530', '正蓝旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('499', '152531', '多伦县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('500', '152600', '乌兰察布盟', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('501', '152900', '阿拉善盟', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('502', '152921', '阿拉善左旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('503', '152922', '阿拉善右旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('504', '152923', '额济纳旗', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('505', '210000', '辽宁省', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('506', '210100', '沈阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('507', '210101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('508', '210102', '和平区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('509', '210103', '沈河区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('510', '210104', '大东区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('511', '210105', '皇姑区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('512', '210106', '铁西区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('513', '210111', '苏家屯区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('514', '210112', '东陵区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('515', '210113', '沈北新区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('516', '210114', '于洪区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('517', '210122', '辽中县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('518', '210123', '康平县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('519', '210124', '法库县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('520', '210181', '新民市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('521', '210200', '大连市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('522', '210201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('523', '210202', '中山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('524', '210203', '西岗区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('525', '210204', '沙河口区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('526', '210211', '甘井子区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('527', '210212', '旅顺口区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('528', '210213', '金州区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('529', '210224', '长海县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('530', '210281', '瓦房店市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('531', '210282', '普兰店市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('532', '210283', '庄河市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('533', '210300', '鞍山市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('534', '210301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('535', '210302', '铁东区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('536', '210303', '铁西区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('537', '210304', '立山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('538', '210311', '千山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2703', '511702', '通川区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2704', '511721', '达县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2705', '511722', '宣汉县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2706', '511723', '开江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2707', '511724', '大竹县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2708', '511725', '渠县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2709', '511781', '万源市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('719', '230104', '道外区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('720', '230106', '哈尔滨香坊区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('721', '230107', '哈尔滨动力区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('722', '230108', '平房区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('723', '230109', '松北区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('724', '230110', '香坊区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('725', '230111', '呼兰区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('726', '230112', '阿城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('727', '230123', '依兰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('728', '230124', '方正县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('729', '230125', '宾县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('730', '230126', '巴彦县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('731', '230127', '木兰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('732', '230128', '通河县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('733', '230129', '延寿县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('734', '230181', '哈尔滨阿城市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('735', '230182', '双城市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('736', '230183', '尚志市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('737', '230184', '五常市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('738', '230200', '齐齐哈尔市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('739', '230201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('740', '230202', '龙沙区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('741', '230203', '建华区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('742', '230204', '铁锋区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('743', '230205', '昂昂溪区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('744', '230206', '富拉尔基区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('745', '230207', '碾子山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('746', '230208', '梅里斯达斡尔族区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('747', '230221', '龙江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('748', '230223', '依安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('749', '230224', '泰来县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('750', '230225', '甘南县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('751', '230227', '富裕县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('752', '230229', '克山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('753', '230230', '克东县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('754', '230231', '拜泉县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('755', '230281', '讷河市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('756', '230300', '鸡西市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('757', '230301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('758', '230302', '鸡冠区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('759', '230303', '恒山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('760', '230304', '滴道区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2921', '530427', '新平彝族傣族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2922', '530428', '元江哈尼族彝族傣族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2923', '530500', '保山市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2924', '530501', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2925', '530502', '隆阳区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2926', '530521', '施甸县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2927', '530522', '腾冲县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2928', '530523', '龙陵县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2929', '530524', '昌宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2930', '530600', '昭通市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2931', '530601', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2932', '530602', '昭阳区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2933', '530621', '鲁甸县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2934', '530622', '巧家县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2935', '530623', '盐津县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2936', '530624', '大关县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2937', '530625', '永善县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2938', '530626', '绥江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2939', '530627', '镇雄县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2940', '530628', '彝良县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2941', '530629', '威信县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2942', '530630', '水富县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2943', '530700', '丽江市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2944', '530701', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2945', '530702', '古城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2946', '530721', '玉龙纳西族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2947', '530722', '永胜县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2948', '530723', '华坪县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2949', '530724', '宁蒗彝族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2950', '530800', '普洱市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2951', '530801', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2952', '530802', '思茅区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2953', '530821', '宁洱哈尼族彝族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2954', '530822', '墨江哈尼族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2955', '530823', '景东彝族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2956', '530824', '景谷傣族彝族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2957', '530825', '镇沅彝族哈尼族拉祜族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2958', '530826', '江城哈尼族彝族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2959', '530827', '孟连傣族拉祜族佤族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2960', '530828', '澜沧拉祜族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2961', '530829', '西盟佤族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2962', '530900', '临沧市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2963', '530901', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2964', '530902', '临翔区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2965', '530921', '凤庆县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2966', '530922', '云县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2967', '530923', '永德县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2968', '530924', '镇康县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2969', '530925', '双江拉祜族佤族布朗族傣族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2970', '530926', '耿马傣族佤族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2971', '530927', '沧源佤族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2972', '532300', '楚雄彝族自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2973', '532301', '楚雄市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2974', '532322', '双柏县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2975', '532323', '牟定县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2976', '532324', '南华县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2977', '532325', '姚安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2978', '532326', '大姚县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2979', '532327', '永仁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2980', '532328', '元谋县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2981', '532329', '武定县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2982', '532331', '禄丰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2983', '532500', '红河哈尼族彝族自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2984', '532501', '个旧市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2985', '532502', '开远市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2986', '532522', '蒙自县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2987', '532523', '屏边苗族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2988', '532524', '建水县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2989', '532525', '石屏县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2990', '532526', '弥勒县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2991', '532527', '泸西县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2992', '532528', '元阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2993', '532529', '红河县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2994', '532530', '金平苗族瑶族傣族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2995', '532531', '绿春县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1902', '420119', '湖北省武汉市东湖技术开发区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1903', '420200', '黄石市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1904', '420201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1905', '420202', '黄石港区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1906', '420203', '西塞山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1907', '420204', '下陆区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1908', '420205', '铁山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1909', '420222', '阳新县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1910', '420281', '大冶市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1911', '420300', '十堰市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1912', '420301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1913', '420302', '茅箭区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1914', '420303', '张湾区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1915', '420321', '郧县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1916', '420322', '郧西县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1917', '420323', '竹山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1918', '420324', '竹溪县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1919', '420325', '房县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1920', '420381', '丹江口市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1921', '420500', '宜昌市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1922', '420501', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1923', '420502', '西陵区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1924', '420503', '伍家岗区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1925', '420504', '点军区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1926', '420505', '猇亭区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1927', '420506', '夷陵区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1928', '420525', '远安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1929', '420526', '兴山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1930', '420527', '秭归县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1931', '420528', '长阳土家族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1932', '420529', '五峰土家族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1933', '420581', '宜都市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1934', '420582', '当阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1935', '420583', '枝江市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1936', '420600', '襄樊市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1937', '420601', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1938', '420602', '襄城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1939', '420606', '樊城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1940', '420607', '襄阳区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1941', '420624', '南漳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1942', '420625', '谷城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1943', '420626', '保康县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1944', '420682', '老河口市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1945', '420683', '枣阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1946', '420684', '宜城市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1947', '420685', '湖北省襄樊市高新技术开发区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1948', '420686', '湖北省襄樊市汽车产业开发区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1949', '420700', '鄂州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1950', '420701', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1951', '420702', '梁子湖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1952', '420703', '华容区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1953', '420704', '鄂城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1954', '420800', '荆门市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1955', '420801', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1956', '420802', '东宝区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1957', '420804', '掇刀区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1958', '420821', '京山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1959', '420822', '沙洋县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1960', '420881', '钟祥市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1961', '420900', '孝感市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1962', '420901', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1963', '420902', '孝南区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1964', '420921', '孝昌县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1965', '420922', '大悟县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1966', '420923', '云梦县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1967', '420981', '应城市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1968', '420982', '安陆市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1969', '420984', '汉川市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1970', '421000', '荆州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1971', '421001', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1972', '421002', '沙市区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1973', '421003', '荆州区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1974', '421022', '公安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1975', '421023', '监利县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1976', '421024', '江陵县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1977', '421081', '石首市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1978', '421083', '洪湖市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1979', '421087', '松滋市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1980', '421100', '黄冈市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1981', '421101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1982', '421102', '黄州区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1983', '421121', '团风县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1984', '421122', '红安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1985', '421123', '罗田县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1986', '421124', '英山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1987', '421125', '浠水县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1988', '421126', '蕲春县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1989', '421127', '黄梅县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1990', '421181', '麻城市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1991', '421182', '武穴市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1992', '421200', '咸宁市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1993', '421201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1994', '421202', '咸安区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1995', '421221', '嘉鱼县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1996', '421222', '通城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1997', '421223', '崇阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1998', '421224', '通山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1999', '421281', '赤壁市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2000', '421300', '随州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2001', '421301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2002', '421302', '曾都区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2003', '421381', '广水市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2004', '422800', '恩施土家族苗族自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2005', '422801', '恩施市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2006', '422802', '利川市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2007', '422822', '建始县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2008', '422823', '巴东县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2009', '422825', '宣恩县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2010', '422826', '咸丰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2011', '422827', '来凤县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2012', '422828', '鹤峰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2013', '429000', '省直辖县级行政区划', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2014', '429004', '仙桃市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2015', '429005', '潜江市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2016', '429006', '天门市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2017', '429021', '神农架林区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2018', '430000', '湖南省', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2019', '430100', '长沙市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2020', '430101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2021', '430102', '芙蓉区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2022', '430103', '天心区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2023', '430104', '岳麓区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2024', '430105', '开福区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2025', '430111', '雨花区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2026', '430121', '长沙县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2027', '430122', '望城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2028', '430124', '宁乡县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2029', '430181', '浏阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2030', '430200', '株洲市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2031', '430201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2032', '430202', '荷塘区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('941', '320404', '钟楼区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('942', '320405', '戚墅堰区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('943', '320411', '新北区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('944', '320412', '武进区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('945', '320481', '溧阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('946', '320482', '金坛市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('947', '320500', '苏州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('948', '320501', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('949', '320502', '沧浪区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('950', '320503', '平江区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('951', '320504', '金阊区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('952', '320505', '虎丘区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('953', '320506', '吴中区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('954', '320507', '相城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('955', '320581', '常熟市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('956', '320582', '张家港市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('957', '320583', '昆山市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('958', '320584', '吴江市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('959', '320585', '太仓市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('960', '320600', '南通市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('961', '320601', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('962', '320602', '崇川区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('963', '320611', '港闸区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('964', '320621', '海安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('965', '320623', '如东县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('966', '320681', '启东市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('967', '320682', '如皋市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('968', '320683', '通州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('969', '320684', '海门市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('970', '320700', '连云港市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('971', '320701', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('972', '320703', '连云区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('973', '320705', '新浦区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('974', '320706', '海州区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('975', '320721', '赣榆县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('976', '320722', '东海县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('977', '320723', '灌云县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('978', '320724', '灌南县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('979', '320800', '淮安市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('980', '320801', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('981', '320802', '清河区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('982', '320803', '楚州区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('983', '320804', '淮阴区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('984', '320811', '清浦区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('985', '320826', '涟水县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('986', '320829', '洪泽县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('987', '320830', '盱眙县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('988', '320831', '金湖县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('989', '320900', '盐城市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('990', '320901', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('991', '320902', '亭湖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('992', '320903', '盐都区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('993', '320921', '响水县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('994', '320922', '滨海县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('995', '320923', '阜宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('996', '320924', '射阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('997', '320925', '建湖县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('998', '320981', '东台市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('999', '320982', '大丰市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1000', '321000', '扬州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1001', '321001', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1002', '321002', '广陵区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1003', '321003', '邗江区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1004', '321011', '维扬区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1005', '321023', '宝应县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1006', '321081', '仪征市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1007', '321084', '高邮市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1008', '321088', '江都市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1009', '321100', '镇江市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1010', '321101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1011', '321102', '京口区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1012', '321111', '润州区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1013', '321112', '丹徒区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1014', '321181', '丹阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1015', '321182', '扬中市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1016', '321183', '句容市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1017', '321200', '泰州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1018', '321201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1019', '321202', '海陵区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1020', '321203', '高港区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1021', '321281', '兴化市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1022', '321282', '靖江市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1023', '321283', '泰兴市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1024', '321284', '姜堰市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1025', '321300', '宿迁市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1026', '321301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1027', '321302', '宿城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1028', '321311', '宿豫区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1029', '321322', '沭阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1030', '321323', '泗阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1031', '321324', '泗洪县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1032', '330000', '浙江省', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1033', '330100', '杭州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1034', '330101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1035', '330102', '上城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1036', '330103', '下城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1037', '330104', '江干区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1038', '330105', '拱墅区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1039', '330106', '西湖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1040', '330108', '滨江区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1041', '330109', '萧山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1042', '330110', '余杭区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1043', '330122', '桐庐县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1044', '330127', '淳安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1045', '330182', '建德市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1046', '330183', '富阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1047', '330185', '临安市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1048', '330200', '宁波市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1049', '330201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1050', '330203', '海曙区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1051', '330204', '江东区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1052', '330205', '江北区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1053', '330206', '北仑区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1054', '330211', '镇海区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1055', '330212', '鄞州区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1056', '330225', '象山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1057', '330226', '宁海县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1058', '330281', '余姚市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1059', '330282', '慈溪市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1060', '330283', '奉化市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1061', '330300', '温州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1062', '330301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1063', '330302', '鹿城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1064', '330303', '龙湾区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1065', '330304', '瓯海区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1066', '330322', '洞头县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1067', '330324', '永嘉县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1068', '330326', '平阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1069', '330327', '苍南县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1070', '330328', '文成县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1071', '330329', '泰顺县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1072', '330381', '瑞安市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1818', '411281', '义马市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1819', '411282', '灵宝市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1820', '411300', '南阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1821', '411301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1822', '411302', '宛城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1823', '411303', '卧龙区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1824', '411321', '南召县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1825', '411322', '方城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1826', '411323', '西峡县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1827', '411324', '镇平县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1828', '411325', '内乡县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1829', '411326', '淅川县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1830', '411327', '社旗县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1831', '411328', '唐河县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1832', '411329', '新野县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1833', '411330', '桐柏县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1834', '411381', '邓州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1835', '411382', '南阳市河南油田', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1836', '411400', '商丘市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1837', '411401', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1838', '411402', '梁园区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1839', '411403', '睢阳区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1840', '411421', '民权县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1841', '411422', '睢县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1842', '411423', '宁陵县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1843', '411424', '柘城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1844', '411425', '虞城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1845', '411426', '夏邑县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1846', '411481', '永城市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1847', '411500', '信阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1848', '411501', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1849', '411502', '浉河区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1850', '411503', '平桥区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1851', '411521', '罗山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1852', '411522', '光山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1853', '411523', '新县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1854', '411524', '商城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1855', '411525', '固始县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1856', '411526', '潢川县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1857', '411527', '淮滨县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1858', '411528', '息县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1859', '411600', '周口市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1860', '411601', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1861', '411602', '川汇区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1862', '411621', '扶沟县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1863', '411622', '西华县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1864', '411623', '商水县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1865', '411624', '沈丘县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1866', '411625', '郸城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1867', '411626', '淮阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1868', '411627', '太康县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1869', '411628', '鹿邑县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1870', '411681', '项城市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1871', '411700', '驻马店市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1872', '411701', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1873', '411702', '驿城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1874', '411721', '西平县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1875', '411722', '上蔡县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1876', '411723', '平舆县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1877', '411724', '正阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1878', '411725', '确山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1879', '411726', '泌阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1880', '411727', '汝南县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1881', '411728', '遂平县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1882', '411729', '新蔡县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1883', '419000', '省直辖县级行政区划', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1884', '419001', '济源市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1885', '420000', '湖北省', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1886', '420100', '武汉市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1887', '420101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1888', '420102', '江岸区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1889', '420103', '江汉区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1890', '420104', '硚口区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1891', '420105', '汉阳区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1892', '420106', '武昌区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1893', '420107', '青山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1894', '420111', '洪山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1895', '420112', '东西湖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1896', '420113', '汉南区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1897', '420114', '蔡甸区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1898', '420115', '江夏区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1899', '420116', '黄陂区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1900', '420117', '新洲区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1901', '420118', '湖北省武汉市武汉市经济开发区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1473', '360900', '宜春市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1474', '360901', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1475', '360902', '袁州区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1476', '360921', '奉新县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1477', '360922', '万载县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1478', '360923', '上高县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1479', '360924', '宜丰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1480', '360925', '靖安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1481', '360926', '铜鼓县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1482', '360981', '丰城市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1483', '360982', '樟树市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1484', '360983', '高安市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1485', '361000', '抚州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1486', '361001', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1487', '361002', '临川区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1488', '361021', '南城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1489', '361022', '黎川县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1490', '361023', '南丰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1491', '361024', '崇仁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1492', '361025', '乐安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1493', '361026', '宜黄县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1494', '361027', '金溪县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1495', '361028', '资溪县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1496', '361029', '东乡县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1497', '361030', '广昌县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1498', '361100', '上饶市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1499', '361101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1500', '361102', '信州区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1501', '361121', '上饶县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1502', '361122', '广丰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1503', '361123', '玉山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1504', '361124', '铅山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1505', '361125', '横峰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1506', '361126', '弋阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1507', '361127', '余干县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1508', '361128', '鄱阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1509', '361129', '万年县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1510', '361130', '婺源县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1511', '361181', '德兴市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1512', '370000', '山东省', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1513', '370100', '济南市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1514', '370101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1515', '370102', '历下区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1516', '370103', '市中区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1517', '370104', '槐荫区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1518', '370105', '天桥区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1519', '370112', '历城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1520', '370113', '长清区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1521', '370124', '平阴县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1522', '370125', '济阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1523', '370126', '商河县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1524', '370181', '章丘市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2126', '431101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2127', '431102', '零陵区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2128', '431103', '冷水滩区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2129', '431121', '祁阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2130', '431122', '东安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2131', '431123', '双牌县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2132', '431124', '道县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2133', '431125', '江永县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2134', '431126', '宁远县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2135', '431127', '蓝山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2136', '431128', '新田县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2137', '431129', '江华瑶族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2138', '431200', '怀化市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2139', '431201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2140', '431202', '鹤城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2141', '431221', '中方县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2142', '431222', '沅陵县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2143', '431223', '辰溪县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2144', '431224', '溆浦县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2145', '431225', '会同县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2146', '431226', '麻阳苗族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2147', '431227', '新晃侗族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2148', '431228', '芷江侗族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2149', '431229', '靖州苗族侗族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2150', '431230', '通道侗族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2151', '431281', '洪江市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2152', '431300', '娄底市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2153', '431301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2154', '431302', '娄星区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2155', '431321', '双峰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2156', '431322', '新化县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2157', '431381', '冷水江市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2158', '431382', '涟源市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2159', '433100', '湘西土家族苗族自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2160', '433101', '吉首市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2161', '433122', '泸溪县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2162', '433123', '凤凰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2163', '433124', '花垣县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2164', '433125', '保靖县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2165', '433126', '古丈县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2166', '433127', '永顺县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2167', '433130', '龙山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2168', '440000', '广东省', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2169', '440100', '广州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2170', '440101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2171', '440102', '广州东山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2172', '440103', '荔湾区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2173', '440104', '越秀区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2174', '440105', '海珠区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2175', '440106', '天河区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2176', '440107', '广州芳村区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2177', '440111', '白云区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2178', '440112', '黄埔区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2179', '440113', '番禺区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2180', '440114', '花都区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2181', '440115', '南沙区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2182', '440116', '萝岗区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2183', '440183', '增城市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2184', '440184', '从化市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2185', '440200', '韶关市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2186', '440201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2187', '440203', '武江区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2188', '440204', '浈江区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2189', '440205', '曲江区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2190', '440222', '始兴县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2191', '440224', '仁化县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2192', '440229', '翁源县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2193', '440232', '乳源瑶族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2194', '440233', '新丰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2195', '440281', '乐昌市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2196', '440282', '南雄市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2197', '440300', '深圳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2198', '440301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2199', '440303', '罗湖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2200', '440304', '福田区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2201', '440305', '南山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2202', '440306', '宝安区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2203', '440307', '龙岗区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2204', '440308', '盐田区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2205', '440400', '珠海市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2206', '440401', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2207', '440402', '香洲区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('539', '210321', '台安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('540', '210323', '岫岩满族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('541', '210381', '海城市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('542', '210400', '抚顺市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('543', '210401', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('544', '210402', '新抚区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('545', '210403', '东洲区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('546', '210404', '望花区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('547', '210411', '顺城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('548', '210421', '抚顺县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('549', '210422', '新宾满族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('550', '210423', '清原满族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('551', '210500', '本溪市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('552', '210501', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('553', '210502', '平山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('554', '210503', '溪湖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('555', '210504', '明山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('556', '210505', '南芬区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('557', '210521', '本溪满族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('558', '210522', '桓仁满族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('559', '210600', '丹东市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('560', '210601', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('561', '210602', '元宝区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('562', '210603', '振兴区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('563', '210604', '振安区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('564', '210624', '宽甸满族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('565', '210681', '东港市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('566', '210682', '凤城市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('567', '210700', '锦州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('568', '210701', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('569', '210702', '古塔区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('570', '210703', '凌河区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('571', '210711', '太和区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('572', '210726', '黑山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('573', '210727', '义县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('574', '210781', '凌海市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('575', '210782', '北镇市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('576', '210800', '营口市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('577', '210801', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('578', '210802', '站前区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('579', '210803', '西市区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('580', '210804', '鲅鱼圈区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('581', '210811', '老边区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('582', '210881', '盖州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('583', '210882', '大石桥市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('584', '210900', '阜新市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('585', '210901', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('586', '210902', '海州区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('587', '210903', '新邱区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('588', '210904', '太平区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('589', '210905', '清河门区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('590', '210911', '细河区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('591', '210921', '阜新蒙古族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('592', '210922', '彰武县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('593', '211000', '辽阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('594', '211001', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('595', '211002', '白塔区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('596', '211003', '文圣区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('597', '211004', '宏伟区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('598', '211005', '弓长岭区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('599', '211011', '太子河区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('600', '211021', '辽阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('601', '211081', '灯塔市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('602', '211100', '盘锦市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('603', '211101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('604', '211102', '双台子区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('605', '211103', '兴隆台区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('606', '211121', '大洼县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('607', '211122', '盘山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('608', '211200', '铁岭市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('609', '211201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('610', '211202', '银州区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('611', '211204', '清河区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('612', '211221', '铁岭县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('613', '211223', '西丰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('614', '211224', '昌图县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('615', '211281', '调兵山市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('616', '211282', '开原市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('617', '211300', '朝阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('618', '211301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('619', '211302', '双塔区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('620', '211304', '开发区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('621', '211303', '龙城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('622', '211321', '朝阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('623', '211322', '建平县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('624', '211324', '喀喇沁左翼蒙古族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('625', '211381', '北票市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('626', '211382', '凌源市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('627', '211400', '葫芦岛市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('628', '211401', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('629', '211402', '连山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('630', '211403', '龙港区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('631', '211404', '南票区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('632', '211421', '绥中县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('633', '211422', '建昌县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('634', '211481', '兴城市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('635', '220000', '吉林省', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('636', '220100', '长春市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('637', '220101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('638', '220102', '南关区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('639', '220103', '宽城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('640', '220104', '朝阳区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('641', '220105', '二道区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('642', '220106', '绿园区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('643', '220112', '双阳区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('644', '220122', '农安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('645', '220181', '九台市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('646', '220182', '榆树市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('647', '220183', '德惠市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('648', '220200', '吉林市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('649', '220201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('650', '220202', '昌邑区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('651', '220203', '龙潭区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('652', '220204', '船营区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('653', '220211', '丰满区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('654', '220221', '永吉县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('655', '220281', '蛟河市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('656', '220282', '桦甸市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('657', '220283', '舒兰市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('658', '220284', '磐石市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('659', '220300', '四平市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('660', '220301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('661', '220302', '铁西区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('662', '220303', '铁东区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('663', '220322', '梨树县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('664', '220323', '伊通满族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('665', '220381', '公主岭市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('666', '220382', '双辽市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('667', '220400', '辽源市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('668', '220401', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('669', '220402', '龙山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('670', '220403', '西安区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('671', '220421', '东丰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('672', '220422', '东辽县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('673', '220500', '通化市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('674', '220501', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('675', '220502', '东昌区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('676', '220503', '二道江区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('677', '220521', '通化县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('678', '220523', '辉南县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('679', '220524', '柳河县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('680', '220581', '梅河口市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('681', '220582', '集安市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('682', '220600', '白山市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('683', '220601', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('684', '220602', '八道江区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('685', '220605', '江源区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('686', '220621', '抚松县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('687', '220622', '靖宇县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('688', '220623', '长白朝鲜族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('689', '220625', '白山江源县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('690', '220681', '临江市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('691', '220700', '松原市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('692', '220701', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('693', '220702', '宁江区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('694', '220721', '前郭尔罗斯蒙古族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('695', '220722', '长岭县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('696', '220723', '乾安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('697', '220724', '扶余县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('698', '220800', '白城市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('699', '220801', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('700', '220802', '洮北区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('701', '220821', '镇赉县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('702', '220822', '通榆县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('703', '220881', '洮南市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('704', '220882', '大安市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('705', '222400', '延边朝鲜族自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('706', '222401', '延吉市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('707', '222402', '图们市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('708', '222403', '敦化市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('709', '222404', '珲春市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('710', '222405', '龙井市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('711', '222406', '和龙市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('712', '222424', '汪清县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('713', '222426', '安图县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('714', '230000', '黑龙江省', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('715', '230100', '哈尔滨市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('716', '230101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('717', '230102', '道里区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('718', '230103', '南岗区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3076', '542322', '南木林县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3077', '542323', '江孜县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3078', '542324', '定日县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3079', '542325', '萨迦县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3080', '542326', '拉孜县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3081', '542327', '昂仁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3082', '542328', '谢通门县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3083', '542329', '白朗县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3084', '542330', '仁布县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3085', '542331', '康马县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3086', '542332', '定结县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3087', '542333', '仲巴县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3088', '542334', '亚东县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3089', '542335', '吉隆县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3090', '542336', '聂拉木县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3091', '542337', '萨嘎县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3092', '542338', '岗巴县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3093', '542400', '那曲地区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3094', '542421', '那曲县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3095', '542422', '嘉黎县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3096', '542423', '比如县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3097', '542424', '聂荣县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3098', '542425', '安多县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3099', '542426', '申扎县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3100', '542427', '索县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3101', '542428', '班戈县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3102', '542429', '巴青县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3103', '542430', '尼玛县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3104', '542500', '阿里地区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3105', '542521', '普兰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3106', '542522', '札达县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3107', '542523', '噶尔县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3108', '542524', '日土县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3109', '542525', '革吉县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3110', '542526', '改则县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3111', '542527', '措勤县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3112', '542600', '林芝地区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3113', '542621', '林芝县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3114', '542622', '工布江达县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3115', '542623', '米林县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3116', '542624', '墨脱县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3117', '542625', '波密县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3118', '542626', '察隅县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3119', '542627', '朗县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3120', '610000', '陕西省', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3121', '610100', '西安市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3122', '610101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3123', '610102', '新城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3124', '610103', '碑林区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3125', '610104', '莲湖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3126', '610111', '灞桥区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3127', '610112', '未央区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3128', '610113', '雁塔区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3129', '610114', '阎良区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3130', '610115', '临潼区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3131', '610116', '长安区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3132', '610122', '蓝田县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3133', '610124', '周至县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3134', '610125', '户县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3135', '610126', '高陵县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3136', '610200', '铜川市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3137', '610201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3138', '610202', '王益区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3139', '610203', '印台区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3140', '610204', '耀州区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3141', '610222', '宜君县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3142', '610300', '宝鸡市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3143', '610301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3144', '610302', '渭滨区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3145', '610303', '金台区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3146', '610304', '陈仓区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3147', '610322', '凤翔县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3148', '610323', '岐山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3149', '610324', '扶风县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3150', '610326', '眉县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3151', '610327', '陇县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3152', '610328', '千阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3153', '610329', '麟游县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3154', '610330', '凤县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3155', '610331', '太白县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3156', '610400', '咸阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3157', '610401', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3158', '610402', '秦都区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3159', '610403', '杨凌区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3160', '610404', '渭城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3161', '610422', '三原县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3162', '610423', '泾阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3163', '610424', '乾县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3164', '610425', '礼泉县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3165', '610426', '永寿县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3166', '610427', '彬县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3167', '610428', '长武县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3168', '610429', '旬邑县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3169', '610430', '淳化县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3170', '610431', '武功县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3171', '610481', '兴平市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3172', '610500', '渭南市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3173', '610501', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3174', '610502', '临渭区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3175', '610521', '华县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3176', '610522', '潼关县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3177', '610523', '大荔县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3178', '610524', '合阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3179', '610525', '澄城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3180', '610526', '蒲城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3181', '610527', '白水县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3182', '610528', '富平县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3183', '610581', '韩城市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3184', '610582', '华阴市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3185', '610600', '延安市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3186', '610601', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3187', '610602', '宝塔区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3188', '610621', '延长县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3189', '610622', '延川县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3190', '610623', '子长县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3191', '610624', '安塞县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3192', '610625', '志丹县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3193', '610626', '吴起县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3194', '610627', '甘泉县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3195', '610628', '富县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3196', '610629', '洛川县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3197', '610630', '宜川县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3198', '610631', '黄龙县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3199', '610632', '黄陵县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3200', '610700', '汉中市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3201', '610701', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3202', '610702', '汉台区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3203', '610721', '南郑县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3204', '610722', '城固县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3205', '610723', '洋县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3206', '610724', '西乡县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3207', '610725', '勉县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3208', '610726', '宁强县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3209', '610727', '略阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3210', '610728', '镇巴县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3211', '610729', '留坝县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3212', '610730', '佛坪县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3213', '610800', '榆林市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3214', '610801', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3215', '610802', '榆阳区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3216', '610821', '神木县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3217', '610822', '府谷县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3218', '610823', '横山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3219', '610824', '靖边县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3220', '610825', '定边县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3221', '610826', '绥德县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3222', '610827', '米脂县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3223', '610828', '佳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3224', '610829', '吴堡县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3225', '610830', '清涧县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3226', '610831', '子洲县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3227', '610900', '安康市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3228', '610901', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3229', '610902', '汉滨区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3230', '610921', '汉阴县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3231', '610922', '石泉县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3232', '610923', '宁陕县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3233', '610924', '紫阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3234', '610925', '岚皋县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3235', '610926', '平利县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3236', '610927', '镇坪县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3237', '610928', '旬阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3238', '610929', '白河县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3239', '611000', '商洛市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3240', '611001', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3241', '611002', '商州区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3242', '611021', '洛南县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3243', '611022', '丹凤县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3244', '611023', '商南县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3245', '611024', '山阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3246', '611025', '镇安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3247', '611026', '柞水县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3248', '620000', '甘肃省', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3249', '620100', '兰州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3250', '620101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3251', '620102', '城关区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3252', '620103', '七里河区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3253', '620104', '西固区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3254', '620105', '安宁区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3255', '620111', '红古区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3256', '620121', '永登县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3257', '620122', '皋兰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3258', '620123', '榆中县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3259', '620200', '嘉峪关市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3260', '620201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3261', '620300', '金昌市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3262', '620301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3263', '620302', '金川区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3264', '620321', '永昌县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3265', '620400', '白银市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3266', '620401', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3267', '620402', '白银区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3268', '620403', '平川区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3269', '620421', '靖远县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3270', '620422', '会宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3271', '620423', '景泰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3272', '620500', '天水市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3273', '620501', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3274', '620502', '秦州区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3275', '620503', '麦积区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3276', '620521', '清水县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3277', '620522', '秦安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3278', '620523', '甘谷县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3279', '620524', '武山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3280', '620525', '张家川回族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3281', '620600', '武威市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3282', '620601', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3283', '620602', '凉州区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3284', '620621', '民勤县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3285', '620622', '古浪县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3286', '620623', '天祝藏族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3287', '620700', '张掖市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3288', '620701', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3289', '620702', '甘州区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3290', '620721', '肃南裕固族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3291', '620722', '民乐县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3292', '620723', '临泽县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3293', '620724', '高台县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3294', '620725', '山丹县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3295', '620800', '平凉市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3296', '620801', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3297', '620802', '崆峒区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3298', '620821', '泾川县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3299', '620822', '灵台县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3300', '620823', '崇信县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3301', '620824', '华亭县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3302', '620825', '庄浪县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2208', '440403', '斗门区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2209', '440404', '金湾区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2210', '440500', '汕头市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2211', '440501', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2212', '440507', '龙湖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2213', '440511', '金平区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2214', '440512', '濠江区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2215', '440513', '潮阳区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2216', '440514', '潮南区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2217', '440515', '澄海区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2218', '440523', '南澳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2219', '440600', '佛山市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2220', '440601', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2221', '440604', '禅城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2222', '440605', '南海区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2223', '440606', '顺德区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2224', '440607', '三水区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2225', '440608', '高明区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2226', '440700', '江门市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2227', '440701', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2228', '440703', '蓬江区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2229', '440704', '江海区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2230', '440705', '新会区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2231', '440781', '台山市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2232', '440783', '开平市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2233', '440784', '鹤山市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2234', '440785', '恩平市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2235', '440800', '湛江市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2236', '440801', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2237', '440802', '赤坎区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2238', '440803', '霞山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2239', '440804', '坡头区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2240', '440811', '麻章区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2241', '440823', '遂溪县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2242', '440825', '徐闻县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2243', '440881', '廉江市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2244', '440882', '雷州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2245', '440883', '吴川市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2246', '440900', '茂名市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2247', '440901', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1366', '350781', '邵武市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('938', '320400', '常州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3011', '532901', '大理市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3012', '532922', '漾濞彝族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3013', '532923', '祥云县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3014', '532924', '宾川县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3015', '532925', '弥渡县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3016', '532926', '南涧彝族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3017', '532927', '巍山彝族回族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3018', '532928', '永平县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3019', '532929', '云龙县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3020', '532930', '洱源县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3021', '532931', '剑川县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3022', '532932', '鹤庆县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3023', '533100', '德宏傣族景颇族自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3024', '533102', '瑞丽市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3025', '533103', '潞西市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3026', '533122', '梁河县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3027', '533123', '盈江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3028', '533124', '陇川县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3029', '533300', '怒江傈僳族自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3030', '533321', '泸水县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3031', '533323', '福贡县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3032', '533324', '贡山独龙族怒族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3033', '533325', '兰坪白族普米族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3034', '533400', '迪庆藏族自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3035', '533421', '香格里拉县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3036', '533422', '德钦县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3037', '533423', '维西傈僳族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3038', '540000', '西藏自治区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3039', '540100', '拉萨市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3040', '540101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3041', '540102', '城关区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3042', '540121', '林周县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3043', '540122', '当雄县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3044', '540123', '尼木县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3045', '540124', '曲水县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3046', '540125', '堆龙德庆县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3047', '540126', '达孜县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('92', '130323', '抚宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('93', '130324', '卢龙县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('94', '130400', '邯郸市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('95', '130401', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('96', '130402', '邯山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('97', '130403', '丛台区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('98', '130404', '复兴区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('99', '130406', '峰峰矿区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('100', '130421', '邯郸县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('101', '130423', '临漳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('102', '130424', '成安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('103', '130425', '大名县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('104', '130426', '涉县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('105', '130427', '磁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('106', '130428', '肥乡县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('107', '130429', '永年县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('108', '130430', '邱县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('109', '130431', '鸡泽县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('110', '130432', '广平县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('111', '130433', '馆陶县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('112', '130434', '魏县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('113', '130435', '曲周县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('114', '130481', '武安市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('115', '130500', '邢台市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('116', '130501', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('117', '130502', '桥东区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('118', '130503', '桥西区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('119', '130521', '邢台县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('120', '130522', '临城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('121', '130523', '内丘县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('122', '130524', '柏乡县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('123', '130525', '隆尧县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('124', '130526', '任县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('125', '130527', '南和县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('126', '130528', '宁晋县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('127', '130529', '巨鹿县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('128', '130530', '新河县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('129', '130531', '广宗县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('130', '130532', '平乡县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('131', '130533', '威县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('132', '130534', '清河县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('133', '130535', '临西县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('134', '130581', '南宫市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('135', '130582', '沙河市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('136', '130600', '保定市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('137', '130601', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('138', '130602', '新市区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('139', '130603', '北市区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('140', '130604', '南市区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('141', '130605', '高开区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('142', '130621', '满城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('143', '130622', '清苑县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('144', '130623', '涞水县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('145', '130624', '阜平县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('146', '130625', '徐水县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('147', '130626', '定兴县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('148', '130627', '唐县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('149', '130628', '高阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('150', '130629', '容城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('151', '130630', '涞源县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('152', '130631', '望都县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('153', '130632', '安新县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('154', '130633', '易县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('155', '130634', '曲阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('156', '130635', '蠡县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('157', '130636', '顺平县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('158', '130637', '博野县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('159', '130638', '雄县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('160', '130681', '涿州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('161', '130682', '定州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('162', '130683', '安国市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('163', '130684', '高碑店市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('164', '130700', '张家口市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('165', '130701', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('166', '130702', '桥东区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('167', '130703', '桥西区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('168', '130705', '宣化区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('169', '130706', '下花园区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('170', '130721', '宣化县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('171', '130722', '张北县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('172', '130723', '康保县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('173', '130724', '沽源县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('174', '130725', '尚义县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('175', '130726', '蔚县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('176', '130727', '阳原县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('177', '130728', '怀安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('178', '130729', '万全县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('179', '130730', '怀来县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('180', '130731', '涿鹿县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('181', '130732', '赤城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('182', '130733', '崇礼县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('183', '130800', '承德市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('184', '130801', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('185', '130802', '双桥区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('186', '130803', '双滦区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('187', '130804', '鹰手营子矿区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('188', '130821', '承德县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('189', '130822', '兴隆县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('190', '130823', '平泉县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('191', '130824', '滦平县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('192', '130825', '隆化县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('193', '130826', '丰宁满族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('194', '130827', '宽城满族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('195', '130828', '围场满族蒙古族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('196', '130900', '沧州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('197', '130901', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('198', '130902', '新华区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('199', '130903', '运河区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('200', '130921', '沧县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('201', '130922', '青县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('202', '130923', '东光县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('203', '130924', '海兴县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('204', '130925', '盐山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('205', '130926', '肃宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('206', '130927', '南皮县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('207', '130928', '吴桥县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('208', '130929', '献县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('209', '130930', '孟村回族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('210', '130981', '泊头市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('211', '130982', '任丘市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('212', '130983', '黄骅市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('213', '130984', '河间市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('214', '131000', '廊坊市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('215', '131001', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('216', '131002', '安次区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('217', '131003', '广阳区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('218', '131022', '固安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('219', '131023', '永清县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('220', '131024', '香河县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('221', '131025', '大城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('222', '131026', '文安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('223', '131028', '大厂回族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('224', '131081', '霸州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('225', '131082', '三河市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('226', '131100', '衡水市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('227', '131101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('228', '131102', '桃城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('229', '131121', '枣强县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('230', '131122', '武邑县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('231', '131123', '武强县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('232', '131124', '饶阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('233', '131125', '安平县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3303', '620826', '静宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3304', '620900', '酒泉市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3305', '620901', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3306', '620902', '肃州区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3307', '620921', '金塔县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3308', '620922', '瓜州县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3309', '620923', '肃北蒙古族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3310', '620924', '阿克塞哈萨克族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3311', '620981', '玉门市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3312', '620982', '敦煌市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3313', '621000', '庆阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3314', '621001', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3315', '621002', '西峰区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3316', '621021', '庆城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3317', '621022', '环县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3318', '621023', '华池县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3319', '621024', '合水县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3320', '621025', '正宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3321', '621026', '宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3322', '621027', '镇原县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3323', '621100', '定西市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3324', '621101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3325', '621102', '安定区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3326', '621121', '通渭县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3327', '621122', '陇西县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3328', '621123', '渭源县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3329', '621124', '临洮县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3330', '621125', '漳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3331', '621126', '岷县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3332', '621200', '陇南市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3333', '621201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3334', '621202', '武都区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3335', '621221', '成县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3336', '621222', '文县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3337', '621223', '宕昌县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3338', '621224', '康县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3339', '621225', '西和县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3340', '621226', '礼县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3341', '621227', '徽县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3342', '621228', '两当县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3343', '622900', '临夏回族自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3344', '622901', '临夏市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3345', '622921', '临夏县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3346', '622922', '康乐县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3347', '622923', '永靖县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3348', '622924', '广河县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3349', '622925', '和政县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3350', '622926', '东乡族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3351', '622927', '积石山保安族东乡族撒拉族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3352', '623000', '甘南藏族自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3353', '623001', '合作市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3354', '623021', '临潭县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3355', '623022', '卓尼县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3356', '623023', '舟曲县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3357', '623024', '迭部县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3048', '540127', '墨竹工卡县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3049', '542100', '昌都地区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3050', '542121', '昌都县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3051', '542122', '江达县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3052', '542123', '贡觉县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3053', '542124', '类乌齐县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3054', '542125', '丁青县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3055', '542126', '察雅县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3056', '542127', '八宿县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3057', '542128', '左贡县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3058', '542129', '芒康县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3059', '542132', '洛隆县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3060', '542133', '边坝县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3061', '542200', '山南地区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3062', '542221', '乃东县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3063', '542222', '扎囊县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3064', '542223', '贡嘎县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3065', '542224', '桑日县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3066', '542225', '琼结县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3067', '542226', '曲松县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3068', '542227', '措美县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3069', '542228', '洛扎县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3070', '542229', '加查县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3071', '542231', '隆子县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3072', '542232', '错那县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3073', '542233', '浪卡子县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3074', '542300', '日喀则地区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3075', '542301', '日喀则市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2710', '511800', '雅安市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2250', '440923', '电白县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2251', '440981', '高州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2252', '440982', '化州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2253', '440983', '信宜市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2254', '441200', '肇庆市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2255', '441201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2256', '441202', '端州区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2257', '441203', '鼎湖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2258', '441223', '广宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2259', '441224', '怀集县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2260', '441225', '封开县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2261', '441226', '德庆县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2262', '441283', '高要市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2263', '441284', '四会市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2264', '441300', '惠州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2265', '441301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2266', '441302', '惠城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2267', '441303', '惠阳区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2268', '441322', '博罗县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2269', '441323', '惠东县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2270', '441324', '龙门县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2271', '441400', '梅州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2272', '441401', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2273', '441402', '梅江区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2274', '441421', '梅县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2275', '441422', '大埔县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2276', '441423', '丰顺县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2277', '441424', '五华县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2278', '441426', '平远县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2279', '441427', '蕉岭县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2280', '441481', '兴宁市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2281', '441500', '汕尾市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2282', '441501', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2283', '441502', '城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2284', '441521', '海丰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2285', '441523', '陆河县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2286', '441581', '陆丰市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2287', '441600', '河源市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2288', '441601', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2289', '441602', '源城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2290', '441621', '紫金县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2291', '441622', '龙川县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2292', '441623', '连平县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2293', '441624', '和平县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2294', '441625', '东源县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2295', '441700', '阳江市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2296', '441701', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2297', '441702', '江城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2298', '441721', '阳西县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2299', '441723', '阳东县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2300', '441733', '广东省阳江市海陵区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2301', '441781', '阳春市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2302', '441800', '清远市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2303', '441801', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2304', '441802', '清城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2305', '441821', '佛冈县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2306', '441823', '阳山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2307', '441825', '连山壮族瑶族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2308', '441826', '连南瑶族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2309', '441827', '清新县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2310', '441881', '英德市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2311', '441882', '连州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2312', '441900', '东莞市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2313', '442000', '中山市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2314', '442001', '广东省中山市市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2315', '442800', '广东省肇庆市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2316', '442801', '广东省肇庆市高要市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2317', '442802', '广东省肇庆市四会市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2318', '442803', '广东省肇庆市广宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2319', '442804', '广东省肇庆市怀集县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2320', '442805', '广东省肇庆市封开县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2321', '442806', '广东省肇庆市德庆县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2322', '442807', '广东省肇庆市端州区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2323', '442808', '广东省肇庆市鼎湖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2324', '442809', '广东省肇庆市市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2325', '445100', '潮州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2326', '445101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2327', '445102', '湘桥区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2328', '445121', '潮安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2329', '445122', '饶平县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2330', '445200', '揭阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2331', '445201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2332', '445202', '榕城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2333', '445221', '揭东县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2334', '445222', '揭西县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2335', '445224', '惠来县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2336', '445281', '普宁市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2337', '445300', '云浮市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2338', '445301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2339', '445302', '云城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2340', '445321', '新兴县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2341', '445322', '郁南县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2342', '445323', '云安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2343', '445381', '罗定市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2344', '450000', '广西壮族自治区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2345', '450100', '南宁市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2346', '450101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2347', '450102', '兴宁区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2348', '450103', '青秀区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2349', '450105', '江南区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2350', '450107', '西乡塘区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2351', '450108', '良庆区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2352', '450109', '邕宁区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2353', '450122', '武鸣县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2354', '450123', '隆安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2355', '450124', '马山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2356', '450125', '上林县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2357', '450126', '宾阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2358', '450127', '横县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2359', '450200', '柳州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2360', '450201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2361', '450202', '城中区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2362', '450203', '鱼峰区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2363', '450204', '柳南区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2364', '450205', '柳北区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2365', '450221', '柳江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2366', '450222', '柳城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2367', '450223', '鹿寨县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2368', '450224', '融安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2369', '450225', '融水苗族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2370', '450226', '三江侗族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2371', '450300', '桂林市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2372', '450301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2373', '450302', '秀峰区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2374', '450303', '叠彩区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2375', '450304', '象山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2376', '450305', '七星区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2377', '450311', '雁山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2378', '450321', '阳朔县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2379', '450322', '临桂县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2380', '450323', '灵川县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2381', '450324', '全州县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2382', '450325', '兴安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2383', '450326', '永福县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2384', '450327', '灌阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2385', '450328', '龙胜各族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2386', '450329', '资源县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2387', '450330', '平乐县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2388', '450331', '荔蒲县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2389', '450332', '恭城瑶族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2390', '450400', '梧州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2391', '450401', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2392', '450403', '万秀区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2393', '450404', '蝶山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2394', '450405', '长洲区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2395', '450421', '苍梧县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2396', '450422', '藤县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2397', '450423', '蒙山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2398', '450481', '岑溪市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2399', '450500', '北海市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2400', '450501', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1158', '340203', '弋江区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1159', '340204', '新芜区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1160', '340207', '鸠江区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1161', '340208', '三山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1162', '340221', '芜湖县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1163', '340222', '繁昌县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1164', '340223', '南陵县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1165', '340300', '蚌埠市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1166', '340301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1167', '340302', '龙子湖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1168', '340303', '蚌山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1169', '340304', '禹会区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1170', '340311', '淮上区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1171', '340321', '怀远县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1172', '340322', '五河县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1173', '340323', '固镇县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1174', '340400', '淮南市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1175', '340401', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1176', '340402', '大通区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1177', '340403', '田家庵区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1178', '340404', '谢家集区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1179', '340405', '八公山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1180', '340406', '潘集区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1181', '340421', '凤台县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1182', '340500', '马鞍山市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1183', '340501', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1184', '340502', '金家庄区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1185', '340503', '花山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1186', '340504', '雨山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1187', '340521', '当涂县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1188', '340600', '淮北市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1189', '340601', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1190', '340602', '杜集区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1191', '340603', '相山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1192', '340604', '烈山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1193', '340621', '濉溪县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1194', '340700', '铜陵市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1195', '340701', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1196', '340702', '铜官山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1197', '340703', '狮子山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1198', '340711', '郊区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1199', '340721', '铜陵县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1200', '340800', '安庆市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1201', '340801', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1202', '340802', '迎江区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1203', '340803', '大观区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1204', '340811', '宜秀区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1205', '340822', '怀宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1206', '340823', '枞阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1207', '340824', '潜山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1208', '340825', '太湖县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1209', '340826', '宿松县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1210', '340827', '望江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1211', '340828', '岳西县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1212', '340881', '桐城市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1213', '341000', '黄山市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1214', '341001', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1215', '341002', '屯溪区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1216', '341003', '黄山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1217', '341004', '徽州区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1218', '341021', '歙县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1219', '341022', '休宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1220', '341023', '黟县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1221', '341024', '祁门县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1222', '341100', '滁州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1223', '341101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1224', '341102', '琅琊区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1225', '341103', '南谯区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1226', '341122', '来安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1227', '341124', '全椒县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1228', '341125', '定远县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1229', '341126', '凤阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1230', '341181', '天长市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1231', '341182', '明光市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1232', '341200', '阜阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1233', '341201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1234', '341202', '颍州区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1235', '341203', '颍东区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1236', '341204', '颍泉区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1237', '341221', '临泉县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1238', '341222', '太和县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1239', '341225', '阜南县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1240', '341226', '颍上县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1241', '341282', '界首市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1242', '341300', '宿州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1', '110000', '北京市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2', '110100', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3', '110101', '东城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('4', '110102', '西城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('5', '110103', '崇文区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('6', '110104', '宣武区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('7', '110105', '朝阳区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('8', '110106', '丰台区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('9', '110107', '石景山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('10', '110108', '海淀区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('11', '110109', '门头沟区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('12', '110111', '房山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('13', '110112', '通州区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('14', '110113', '顺义区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('15', '110114', '昌平区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('16', '110115', '大兴区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('17', '110116', '怀柔区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('18', '110117', '平谷区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('19', '110200', '县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('20', '110228', '密云县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('21', '110229', '延庆县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('22', '120000', '天津市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('23', '120100', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('24', '120101', '和平区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('25', '120102', '河东区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('26', '120103', '河西区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('27', '120104', '南开区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('28', '120105', '河北区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('29', '120106', '红桥区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('30', '120107', '塘沽区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('31', '120108', '汉沽区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('32', '120109', '大港区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('33', '120110', '东丽区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('34', '120111', '西青区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('35', '120112', '津南区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('36', '120113', '北辰区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('37', '120114', '武清区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('38', '120115', '宝坻区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('39', '120200', '县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('40', '120221', '宁河县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('41', '120223', '静海县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('42', '120225', '蓟县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('43', '130000', '河北省', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('44', '130100', '石家庄市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('45', '130101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('46', '130102', '长安区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('47', '130103', '桥东区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('48', '130104', '桥西区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('49', '130105', '新华区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('50', '130107', '井陉矿区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('51', '130108', '裕华区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('52', '130121', '井陉县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('53', '130123', '正定县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('54', '130124', '栾城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('55', '130125', '行唐县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('56', '130126', '灵寿县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('57', '130127', '高邑县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('58', '130128', '深泽县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('59', '130129', '赞皇县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('60', '130130', '无极县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('61', '130131', '平山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('62', '130132', '元氏县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('63', '130133', '赵县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('64', '130181', '辛集市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('65', '130182', '藁城市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('66', '130183', '晋州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('67', '130184', '新乐市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('68', '130185', '鹿泉市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('69', '130200', '唐山市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('70', '130201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('71', '130202', '路南区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('72', '130203', '路北区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('73', '130204', '古冶区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('74', '130205', '开平区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('75', '130207', '丰南区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('76', '130208', '丰润区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('77', '130223', '滦县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('78', '130224', '滦南县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('79', '130225', '乐亭县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('80', '130227', '迁西县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('81', '130229', '玉田县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('82', '130230', '唐海县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('83', '130281', '遵化市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('84', '130283', '迁安市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('85', '130300', '秦皇岛市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('86', '130301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('87', '130302', '海港区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('88', '130303', '山海关区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('89', '130304', '北戴河区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('90', '130321', '青龙满族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('91', '130322', '昌黎县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3358', '623025', '玛曲县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3359', '623026', '碌曲县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3360', '623027', '夏河县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3361', '630000', '青海省', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3362', '630100', '西宁市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3363', '630101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3364', '630102', '城东区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3365', '630103', '城中区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3366', '630104', '城西区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3367', '630105', '城北区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3368', '630121', '大通回族土族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3369', '630122', '湟中县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3370', '630123', '湟源县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3371', '632100', '海东地区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3372', '632121', '平安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3373', '632122', '民和回族土族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3374', '632123', '乐都县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3375', '632126', '互助土族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3376', '632127', '化隆回族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3377', '632128', '循化撒拉族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3378', '632200', '海北藏族自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3379', '632221', '门源回族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3380', '632222', '祁连县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3381', '632223', '海晏县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3382', '632224', '刚察县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3383', '632300', '黄南藏族自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3384', '632321', '同仁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3385', '632322', '尖扎县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3386', '632323', '泽库县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3387', '632324', '河南蒙古族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3388', '632500', '海南藏族自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3389', '632521', '共和县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3390', '632522', '同德县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3391', '632523', '贵德县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3392', '632524', '兴海县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3393', '632525', '贵南县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3394', '632600', '果洛藏族自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3395', '632621', '玛沁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3396', '632622', '班玛县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3397', '632623', '甘德县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3398', '632624', '达日县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3399', '632625', '久治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3400', '632626', '玛多县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3401', '632700', '玉树藏族自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3402', '632721', '玉树县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3403', '632722', '杂多县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3404', '632723', '称多县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3405', '632724', '治多县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3406', '632725', '囊谦县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3407', '632726', '曲麻莱县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3408', '632800', '海西蒙古族藏族自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3409', '632801', '格尔木市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3410', '632802', '德令哈市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3411', '632821', '乌兰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3412', '632822', '都兰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3413', '632823', '天峻县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3414', '640000', '宁夏回族自治区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3415', '640100', '银川市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3416', '640101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3417', '640104', '兴庆区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3418', '640105', '西夏区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3419', '640106', '金凤区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3420', '640121', '永宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3421', '640122', '贺兰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3422', '640181', '灵武市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3423', '640200', '石嘴山市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3424', '640201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3425', '640202', '大武口区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3426', '640205', '惠农区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3427', '640221', '平罗县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3428', '640300', '吴忠市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3429', '640301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3430', '640302', '利通区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3431', '640323', '盐池县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3432', '640324', '同心县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3433', '640381', '青铜峡市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3434', '640400', '固原市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3435', '640401', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3436', '640402', '原州区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3437', '640422', '西吉县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3438', '640423', '隆德县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3439', '640424', '泾源县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3440', '640425', '彭阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3441', '640500', '中卫市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3442', '640501', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3443', '640502', '沙坡头区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3444', '640521', '中宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3445', '640522', '海原县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3446', '650000', '新疆维吾尔自治区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3447', '650100', '乌鲁木齐市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3448', '650101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3449', '650102', '天山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3450', '650103', '沙依巴克区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3451', '650104', '新市区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3452', '650105', '水磨沟区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3453', '650106', '头屯河区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3454', '650107', '达坂城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3455', '650109', '米东区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3456', '650121', '乌鲁木齐县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3457', '650200', '克拉玛依市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3458', '650201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3459', '650202', '独山子区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3460', '650203', '克拉玛依区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3461', '650204', '白碱滩区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3462', '650205', '乌尔禾区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3463', '652100', '吐鲁番地区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3464', '652101', '吐鲁番市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3465', '652122', '鄯善县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3466', '652123', '托克逊县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3467', '652200', '哈密地区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3468', '652201', '哈密市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3469', '652222', '巴里坤哈萨克自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3470', '652223', '伊吾县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3471', '652300', '昌吉回族自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3472', '652301', '昌吉市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3473', '652302', '阜康市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3474', '652323', '呼图壁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3475', '652324', '玛纳斯县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3476', '652325', '奇台县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3477', '652327', '吉木萨尔县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3478', '652328', '木垒哈萨克自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3479', '652700', '博尔塔拉蒙古自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3480', '652701', '博乐市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3481', '652722', '精河县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3482', '652723', '温泉县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3483', '652800', '巴音郭楞蒙古自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3484', '652801', '库尔勒市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3485', '652822', '轮台县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3486', '652823', '尉犁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3487', '652824', '若羌县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3488', '652825', '且末县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3489', '652826', '焉耆回族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3490', '652827', '和静县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3491', '652828', '和硕县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3492', '652829', '博湖县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3493', '652900', '阿克苏地区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3494', '652901', '阿克苏市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3495', '652922', '温宿县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3496', '652923', '库车县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3497', '652924', '沙雅县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3498', '652925', '新和县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3499', '652926', '拜城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3500', '652927', '乌什县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3501', '652928', '阿瓦提县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3502', '652929', '柯坪县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3503', '653000', '克孜勒苏柯尔克孜自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3504', '653001', '阿图什市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3505', '653022', '阿克陶县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3506', '653023', '阿合奇县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3507', '653024', '乌恰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3508', '653100', '喀什地区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3509', '653101', '喀什市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3510', '653121', '疏附县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3511', '653122', '疏勒县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3512', '653123', '英吉沙县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3513', '653124', '泽普县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3514', '653125', '莎车县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3515', '653126', '叶城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3516', '653127', '麦盖提县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3517', '653128', '岳普湖县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3518', '653129', '伽师县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3519', '653130', '巴楚县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3520', '653131', '塔什库尔干塔吉克自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3521', '653200', '和田地区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3522', '653201', '和田市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3523', '653221', '和田县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3524', '653222', '墨玉县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3525', '653223', '皮山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3526', '653224', '洛浦县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3527', '653225', '策勒县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3528', '653226', '于田县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3529', '653227', '民丰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3530', '654000', '伊犁哈萨克自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3531', '654002', '伊宁市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3532', '654003', '奎屯市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3533', '654021', '伊宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3534', '654022', '察布查尔锡伯自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3535', '654023', '霍城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3536', '654024', '巩留县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3537', '654025', '新源县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3538', '654026', '昭苏县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3539', '654027', '特克斯县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3540', '654028', '尼勒克县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1367', '350782', '武夷山市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1368', '350783', '建瓯市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1369', '350784', '建阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1370', '350800', '龙岩市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1371', '350801', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1372', '350802', '新罗区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1373', '350821', '长汀县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1374', '350822', '永定县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1375', '350823', '上杭县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1376', '350824', '武平县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1377', '350825', '连城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1378', '350881', '漳平市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1379', '350900', '宁德市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1380', '350901', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1381', '350902', '蕉城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1382', '350921', '霞浦县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1383', '350922', '古田县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1384', '350923', '屏南县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1385', '350924', '寿宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1386', '350925', '周宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1387', '350926', '柘荣县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1388', '350981', '福安市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1389', '350982', '福鼎市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1390', '360000', '江西省', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1391', '360100', '南昌市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1392', '360101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1393', '360102', '东湖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1394', '360103', '西湖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1395', '360104', '青云谱区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1396', '360105', '湾里区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1397', '360111', '青山湖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1398', '360121', '南昌县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1399', '360122', '新建县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1400', '360123', '安义县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1401', '360124', '进贤县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1402', '360200', '景德镇市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1403', '360201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1404', '360202', '昌江区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1405', '360203', '珠山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1406', '360222', '浮梁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1407', '360281', '乐平市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1408', '360300', '萍乡市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1409', '360301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1410', '360302', '安源区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1411', '360313', '湘东区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1412', '360321', '莲花县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1413', '360322', '上栗县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1414', '360323', '芦溪县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1415', '360400', '九江市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1416', '360401', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1417', '360402', '庐山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1418', '360403', '浔阳区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1419', '360421', '九江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1420', '360423', '武宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1421', '360424', '修水县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1422', '360425', '永修县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1423', '360426', '德安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1424', '360427', '星子县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1425', '360428', '都昌县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1426', '360429', '湖口县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1427', '360430', '彭泽县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1428', '360481', '瑞昌市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1429', '360500', '新余市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1430', '360501', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1431', '360502', '渝水区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1432', '360521', '分宜县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1433', '360600', '鹰潭市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1434', '360601', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1435', '360602', '月湖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1436', '360622', '余江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1437', '360681', '贵溪市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1438', '360700', '赣州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1439', '360701', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1440', '360702', '章贡区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1441', '360721', '赣县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1442', '360722', '信丰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1443', '360723', '大余县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1444', '360724', '上犹县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1445', '360725', '崇义县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1446', '360726', '安远县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1447', '360727', '龙南县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1448', '360728', '定南县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1449', '360729', '全南县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1450', '360730', '宁都县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1451', '360731', '于都县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1452', '360732', '兴国县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1453', '360733', '会昌县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1454', '360734', '寻乌县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1455', '360735', '石城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1456', '360781', '瑞金市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1457', '360782', '南康市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1458', '360800', '吉安市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1459', '360801', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1460', '360802', '吉州区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1461', '360803', '青原区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1462', '360821', '吉安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1463', '360822', '吉水县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1464', '360823', '峡江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1465', '360824', '新干县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1466', '360825', '永丰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1467', '360826', '泰和县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1468', '360827', '遂川县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1469', '360828', '万安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1470', '360829', '安福县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1471', '360830', '永新县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1472', '360881', '井冈山市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('234', '131126', '故城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('235', '131127', '景县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('236', '131128', '阜城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('237', '131181', '冀州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('238', '131182', '深州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('239', '140000', '山西省', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('240', '140100', '太原市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('241', '140101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('242', '140105', '小店区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('243', '140106', '迎泽区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('244', '140107', '杏花岭区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('245', '140108', '尖草坪区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('246', '140109', '万柏林区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('247', '140110', '晋源区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('248', '140121', '清徐县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('249', '140122', '阳曲县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('250', '140123', '娄烦县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('251', '140181', '古交市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('252', '140200', '大同市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('253', '140201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('254', '140202', '城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('255', '140203', '矿区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('256', '140211', '南郊区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('257', '140212', '新荣区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('258', '140221', '阳高县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('259', '140222', '天镇县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('260', '140223', '广灵县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('261', '140224', '灵丘县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('262', '140225', '浑源县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('263', '140226', '左云县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('264', '140227', '大同县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('265', '140300', '阳泉市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('266', '140301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('267', '140302', '城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('268', '140303', '矿区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('269', '140311', '郊区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('270', '140321', '平定县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('271', '140322', '盂县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('272', '140400', '长治市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('273', '140401', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('274', '140402', '城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('275', '140411', '郊区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('276', '140421', '长治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('277', '140423', '襄垣县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('278', '140424', '屯留县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('279', '140425', '平顺县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('280', '140426', '黎城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('281', '140427', '壶关县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('282', '140428', '长子县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('283', '140429', '武乡县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('284', '140430', '沁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('285', '140431', '沁源县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('286', '140481', '潞城市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('287', '140500', '晋城市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('288', '140501', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('289', '140502', '城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('290', '140521', '沁水县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('291', '140522', '阳城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('292', '140524', '陵川县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('293', '140525', '泽州县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('294', '140581', '高平市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('295', '140600', '朔州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('296', '140601', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('297', '140602', '朔城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('298', '140603', '平鲁区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('299', '140621', '山阴县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('300', '140622', '应县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('301', '140623', '右玉县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('302', '140624', '怀仁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('303', '140700', '晋中市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('304', '140701', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('305', '140702', '榆次区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('306', '140721', '榆社县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('307', '140722', '左权县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('308', '140723', '和顺县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('309', '140724', '昔阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('310', '140725', '寿阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('311', '140726', '太谷县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('312', '140727', '祁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('313', '140728', '平遥县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('314', '140729', '灵石县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('315', '140781', '介休市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('316', '140800', '运城市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('317', '140801', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('318', '140802', '盐湖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('319', '140821', '临猗县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2482', '451481', '凭祥市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2483', '460000', '海南省', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2484', '460100', '海口市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2485', '460101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2486', '460105', '秀英区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2487', '460106', '龙华区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2488', '460107', '琼山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2489', '460108', '美兰区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2490', '460200', '三亚市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2491', '460201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2492', '469000', '省直辖县级行政区划', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2493', '469001', '五指山市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2494', '469002', '琼海市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2495', '469003', '儋州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2496', '469005', '文昌市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2497', '469006', '万宁市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2498', '469007', '东方市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2499', '469021', '定安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2500', '469022', '屯昌县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2501', '469023', '澄迈县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2502', '469024', '临高县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2503', '469025', '白沙黎族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2504', '469026', '昌江黎族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2505', '469027', '乐东黎族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2506', '469028', '陵水黎族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2507', '469029', '保亭黎族苗族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2508', '469030', '琼中黎族苗族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2509', '469031', '西沙群岛', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2510', '469032', '南沙群岛', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2511', '469033', '中沙群岛的岛礁及其海域', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2512', '469037', '省直辖县级行政单位西沙群岛', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2513', '469038', '省直辖县级行政单位南沙群岛', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2515', '500000', '重庆市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2516', '500100', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2517', '500101', '万州区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2518', '500102', '涪陵区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2519', '500103', '渝中区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2520', '500104', '大渡口区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2521', '500105', '江北区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2522', '500106', '沙坪坝区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2523', '500107', '九龙坡区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2524', '500108', '南岸区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2525', '500109', '北碚区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2526', '500110', '万盛区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2527', '500111', '双桥区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2528', '500112', '渝北区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2529', '500113', '巴南区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2530', '500114', '黔江区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2531', '500115', '长寿区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2532', '500116', '江津区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2533', '500117', '合川区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2534', '500118', '永川区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2535', '500119', '南川区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2536', '500200', '县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2537', '500222', '綦江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2538', '500223', '潼南县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2539', '500224', '铜梁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2540', '500225', '大足县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2541', '500226', '荣昌县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2542', '500227', '璧山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2543', '500228', '梁平县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2544', '500229', '城口县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2545', '500230', '丰都县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2546', '500231', '垫江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2547', '500232', '武隆县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2548', '500233', '忠县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2549', '500234', '开县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2550', '500235', '云阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2551', '500236', '奉节县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2552', '500237', '巫山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2553', '500238', '巫溪县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2554', '500240', '石柱土家族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2555', '500241', '秀山土家族苗族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2556', '500242', '酉阳土家族苗族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2557', '500243', '彭水苗族土家族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2558', '500381', '重庆市江津市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2559', '500382', '重庆市合川市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2560', '500383', '重庆市永川市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2561', '500384', '重庆市南川市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2562', '510000', '四川省', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2563', '510100', '成都市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2564', '510101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2565', '510104', '锦江区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2566', '510105', '青羊区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2567', '510106', '金牛区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2568', '510107', '武侯区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2569', '510108', '成华区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2570', '510112', '龙泉驿区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2571', '510113', '青白江区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2572', '510114', '新都区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2573', '510115', '温江区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2574', '510121', '金堂县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2575', '510122', '双流县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2576', '510124', '郫县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2577', '510129', '大邑县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2578', '510131', '蒲江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2579', '510132', '新津县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2580', '510181', '都江堰市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2581', '510182', '彭州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2582', '510183', '邛崃市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2583', '510184', '崇州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2584', '510300', '自贡市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2585', '510301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2586', '510302', '自流井区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2587', '510303', '贡井区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2588', '510304', '大安区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2589', '510311', '沿滩区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2590', '510321', '荣县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2591', '510322', '富顺县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2592', '510400', '攀枝花市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2593', '510401', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2594', '510402', '东区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2595', '510403', '西区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2596', '510411', '仁和区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2597', '510421', '米易县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2598', '510422', '盐边县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2599', '510500', '泸州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2600', '510501', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2601', '510502', '江阳区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2602', '510503', '纳溪区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2603', '510504', '龙马潭区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2604', '510521', '泸县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2605', '510522', '合江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2606', '510524', '叙永县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2607', '510525', '古蔺县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2608', '510600', '德阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2609', '510601', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2610', '510603', '旌阳区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2611', '510623', '中江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2612', '510626', '罗江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2613', '510681', '广汉市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2614', '510682', '什邡市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2615', '510683', '绵竹市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2616', '510700', '绵阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2617', '510701', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2618', '510703', '涪城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2619', '510704', '游仙区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2620', '510722', '三台县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2621', '510723', '盐亭县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2622', '510724', '安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2623', '510725', '梓潼县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2624', '510726', '北川羌族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2625', '510727', '平武县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2626', '510781', '江油市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2627', '510800', '广元市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2628', '510801', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2629', '510802', '市中区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2630', '510811', '元坝区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2631', '510812', '朝天区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2632', '510821', '旺苍县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2633', '510822', '青川县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2634', '510823', '剑阁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2635', '510824', '苍溪县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2636', '510900', '遂宁市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2637', '510901', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2638', '510903', '船山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2639', '510904', '安居区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2640', '510921', '蓬溪县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2641', '510922', '射洪县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2642', '510923', '大英县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2643', '511000', '内江市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2644', '511001', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2645', '511002', '市中区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2646', '511011', '东兴区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2647', '511024', '威远县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2648', '511025', '资中县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2649', '511028', '隆昌县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2650', '511100', '乐山市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2651', '511101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2652', '511102', '市中区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2653', '511111', '沙湾区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2654', '511112', '五通桥区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2655', '511113', '金口河区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2656', '511123', '犍为县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2657', '511124', '井研县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2658', '511126', '夹江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2659', '511129', '沐川县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2660', '511132', '峨边彝族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2661', '511133', '马边彝族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2662', '511181', '峨眉山市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2663', '511300', '南充市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2664', '511301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2665', '511302', '顺庆区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2666', '511303', '高坪区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2667', '511304', '嘉陵区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2668', '511321', '南部县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2669', '511322', '营山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2670', '511323', '蓬安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2671', '511324', '仪陇县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2672', '511325', '西充县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2673', '511381', '阆中市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2674', '511400', '眉山市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2675', '511401', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2676', '511402', '东坡区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2677', '511421', '仁寿县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2678', '511422', '彭山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2679', '511423', '洪雅县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2680', '511424', '丹棱县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2681', '511425', '青神县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2682', '511500', '宜宾市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2683', '511501', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2684', '511502', '翠屏区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2685', '511521', '宜宾县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2686', '511522', '南溪县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2687', '511523', '江安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2688', '511524', '长宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2689', '511525', '高县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2690', '511526', '珙县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2691', '511527', '筠连县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2692', '511528', '兴文县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2693', '511529', '屏山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2694', '511600', '广安市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2695', '511601', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2696', '511602', '广安区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2697', '511621', '岳池县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2698', '511622', '武胜县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2699', '511623', '邻水县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2700', '511681', '华蓥市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2701', '511700', '达州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2702', '511701', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1588', '370783', '寿光市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1589', '370784', '安丘市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1590', '370785', '高密市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1591', '370786', '昌邑市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1592', '370800', '济宁市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1593', '370801', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1594', '370802', '市中区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1595', '370811', '任城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1596', '370826', '微山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1597', '370827', '鱼台县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1598', '370828', '金乡县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1599', '370829', '嘉祥县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1600', '370830', '汶上县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1601', '370831', '泗水县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1602', '370832', '梁山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1603', '370881', '曲阜市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1604', '370882', '兖州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1605', '370883', '邹城市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1606', '370900', '泰安市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1607', '370901', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1608', '370902', '泰山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1609', '370903', '泰安岱岳区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1610', '370911', '岱岳区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1611', '370921', '宁阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1612', '370923', '东平县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1613', '370982', '新泰市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1614', '370983', '肥城市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1615', '371000', '威海市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1616', '371001', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1617', '371002', '环翠区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1618', '371081', '文登市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1619', '371082', '荣成市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1620', '371083', '乳山市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1621', '371100', '日照市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1622', '371101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1623', '371102', '东港区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1624', '371103', '岚山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1625', '371121', '五莲县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1626', '371122', '莒县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1627', '371200', '莱芜市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1628', '371201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1629', '371202', '莱城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1630', '371203', '钢城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1631', '371300', '临沂市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1632', '371301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1633', '371302', '兰山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1634', '371311', '罗庄区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1635', '371312', '河东区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1636', '371321', '沂南县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1637', '371322', '郯城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1638', '371323', '沂水县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1639', '371324', '苍山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1640', '371325', '费县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1641', '371326', '平邑县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1642', '371327', '莒南县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1643', '371328', '蒙阴县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1644', '371329', '临沭县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1645', '371400', '德州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1646', '371401', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1647', '371402', '德城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1648', '371421', '陵县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1649', '371422', '宁津县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1650', '371423', '庆云县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1651', '371424', '临邑县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1652', '371425', '齐河县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1653', '371426', '平原县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1654', '371427', '夏津县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1655', '371428', '武城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1656', '371481', '乐陵市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1657', '371482', '禹城市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1658', '371500', '聊城市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1659', '371501', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1660', '371502', '东昌府区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1661', '371521', '阳谷县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1662', '371522', '莘县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1663', '371523', '茌平县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1664', '371524', '东阿县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1665', '371525', '冠县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1666', '371526', '高唐县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1667', '371581', '临清市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1668', '371600', '滨州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1669', '371601', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1670', '371602', '滨城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1671', '371621', '惠民县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1672', '371622', '阳信县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1673', '371623', '无棣县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1674', '371624', '沾化县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1675', '371625', '博兴县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1676', '371626', '邹平县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1677', '371700', '菏泽市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1678', '371701', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1679', '371702', '牡丹区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1680', '371721', '曹县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1681', '371722', '单县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1682', '371723', '成武县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1683', '371724', '巨野县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1684', '371725', '郓城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1685', '371726', '鄄城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1686', '371727', '定陶县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1687', '371728', '东明县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1688', '410000', '河南省', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1689', '410100', '郑州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1690', '410101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1691', '410102', '中原区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1692', '410103', '二七区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1693', '410104', '管城回族区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1694', '410105', '金水区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1695', '410106', '上街区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1696', '410108', '惠济区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1697', '410122', '中牟县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1698', '410181', '巩义市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1699', '410182', '荥阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1700', '410183', '新密市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1701', '410184', '新郑市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2248', '440902', '茂南区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2249', '440903', '茂港区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1702', '410185', '登封市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2711', '511801', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2712', '511802', '雨城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2713', '511821', '名山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2714', '511822', '荥经县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2715', '511823', '汉源县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2716', '511824', '石棉县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2717', '511825', '天全县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2718', '511826', '芦山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2719', '511827', '宝兴县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2720', '511900', '巴中市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2721', '511901', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2722', '511902', '巴州区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2723', '511921', '通江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2724', '511922', '南江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2725', '511923', '平昌县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2726', '512000', '资阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2727', '512001', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2728', '512002', '雁江区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2729', '512021', '安岳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2730', '512022', '乐至县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2731', '512081', '简阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2732', '513200', '阿坝藏族羌族自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2733', '513221', '汶川县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2734', '513222', '理县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2735', '513223', '茂县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2736', '513224', '松潘县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2737', '513225', '九寨沟县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2738', '513226', '金川县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2739', '513227', '小金县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2740', '513228', '黑水县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2741', '513229', '马尔康县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2742', '513230', '壤塘县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2743', '513231', '阿坝县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2744', '513232', '若尔盖县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2745', '513233', '红原县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2746', '513300', '甘孜藏族自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2747', '513321', '康定县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2748', '513322', '泸定县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2749', '513323', '丹巴县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2750', '513324', '九龙县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2751', '513325', '雅江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2752', '513326', '道孚县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2753', '513327', '炉霍县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2754', '513328', '甘孜县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2755', '513329', '新龙县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2756', '513330', '德格县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2757', '513331', '白玉县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2758', '513332', '石渠县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2759', '513333', '色达县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2760', '513334', '理塘县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2761', '513335', '巴塘县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2762', '513336', '乡城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2763', '513337', '稻城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2764', '513338', '得荣县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2765', '513400', '凉山彝族自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2766', '513401', '西昌市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2767', '513422', '木里藏族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2768', '513423', '盐源县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2769', '513424', '德昌县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2770', '513425', '会理县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2771', '513426', '会东县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2772', '513427', '宁南县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2773', '513428', '普格县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2774', '513429', '布拖县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2775', '513430', '金阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2776', '513431', '昭觉县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2777', '513432', '喜德县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2778', '513433', '冕宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2779', '513434', '越西县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2780', '513435', '甘洛县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2781', '513436', '美姑县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2782', '513437', '雷波县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2783', '520000', '贵州省', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2784', '520100', '贵阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2785', '520101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2786', '520102', '南明区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2787', '520103', '云岩区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2788', '520111', '花溪区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2789', '520112', '乌当区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2790', '520113', '白云区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2791', '520114', '小河区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2792', '520121', '开阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2793', '520122', '息烽县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2794', '520123', '修文县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2795', '520181', '清镇市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2796', '520200', '六盘水市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2797', '520201', '钟山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2798', '520203', '六枝特区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2799', '520221', '水城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2800', '520222', '盘县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2801', '520300', '遵义市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2802', '520301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2803', '520302', '红花岗区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2804', '520303', '汇川区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2805', '520321', '遵义县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2806', '520322', '桐梓县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2807', '520323', '绥阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2808', '520324', '正安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2809', '520325', '道真仡佬族苗族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2810', '520326', '务川仡佬族苗族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2811', '520327', '凤冈县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2812', '520328', '湄潭县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2813', '520329', '余庆县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2814', '520330', '习水县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2815', '520381', '赤水市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2816', '520382', '仁怀市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2817', '520400', '安顺市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2818', '520401', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2819', '520402', '西秀区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2820', '520421', '平坝县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2821', '520422', '普定县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2822', '520423', '镇宁布依族苗族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2823', '520424', '关岭布依族苗族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2824', '520425', '紫云苗族布依族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2825', '522200', '铜仁地区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2826', '522201', '铜仁市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2827', '522222', '江口县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2828', '522223', '玉屏侗族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2829', '522224', '石阡县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2830', '522225', '思南县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2831', '522226', '印江土家族苗族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2832', '522227', '德江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2833', '522228', '沿河土家族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2834', '522229', '松桃苗族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2835', '522230', '万山特区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2836', '522300', '黔西南布依族苗族自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2837', '522301', '兴义市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2838', '522322', '兴仁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2839', '522323', '普安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2840', '522324', '晴隆县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2841', '522325', '贞丰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2842', '522326', '望谟县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2843', '522327', '册亨县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2844', '522328', '安龙县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2845', '522400', '毕节地区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2846', '522401', '毕节市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2847', '522422', '大方县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2848', '522423', '黔西县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2849', '522424', '金沙县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2850', '522425', '织金县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2851', '522426', '纳雍县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2852', '522427', '威宁彝族回族苗族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2853', '522428', '赫章县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2854', '522600', '黔东南苗族侗族自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2855', '522601', '凯里市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2856', '522622', '黄平县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2857', '522623', '施秉县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2858', '522624', '三穗县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2859', '522625', '镇远县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2860', '522626', '岑巩县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2861', '522627', '天柱县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2862', '522628', '锦屏县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2863', '522629', '剑河县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2864', '522630', '台江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2865', '522631', '黎平县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2866', '522632', '榕江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2867', '522633', '从江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2868', '522634', '雷山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2869', '522635', '麻江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2870', '522636', '丹寨县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2871', '522700', '黔南布依族苗族自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2872', '522701', '都匀市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2873', '522702', '福泉市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2874', '522722', '荔波县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2875', '522723', '贵定县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2876', '522725', '瓮安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2877', '522726', '独山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2878', '522727', '平塘县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2879', '522728', '罗甸县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2880', '522729', '长顺县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2881', '522730', '龙里县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2882', '522731', '惠水县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2883', '522732', '三都水族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2884', '530000', '云南省', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2885', '530100', '昆明市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2886', '530101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2887', '530102', '五华区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2888', '530103', '盘龙区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2889', '530111', '官渡区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2890', '530112', '西山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2891', '530113', '东川区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2892', '530121', '呈贡县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2893', '530122', '晋宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2894', '530124', '富民县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2895', '530125', '宜良县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2896', '530126', '石林彝族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2897', '530127', '嵩明县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2898', '530128', '禄劝彝族苗族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2899', '530129', '寻甸回族彝族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2900', '530181', '安宁市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2901', '530300', '曲靖市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2902', '530301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2903', '530302', '麒麟区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2904', '530321', '马龙县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2905', '530322', '陆良县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2906', '530323', '师宗县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2907', '530324', '罗平县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2908', '530325', '富源县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2909', '530326', '会泽县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2910', '530328', '沾益县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2911', '530381', '宣威市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2912', '530400', '玉溪市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2913', '530401', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2914', '530402', '红塔区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2915', '530421', '江川县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2916', '530422', '澄江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2917', '530423', '通海县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2918', '530424', '华宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2919', '530425', '易门县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2920', '530426', '峨山彝族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1132', '331081', '温岭市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1133', '331082', '临海市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1134', '331100', '丽水市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1135', '331101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1136', '331102', '莲都区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1137', '331121', '青田县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1138', '331122', '缙云县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1139', '331123', '遂昌县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1140', '331124', '松阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1141', '331125', '云和县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1142', '331126', '庆元县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1143', '331127', '景宁畲族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1144', '331181', '龙泉市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1145', '340000', '安徽省', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1146', '340100', '合肥市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1147', '340101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1148', '340102', '瑶海区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1149', '340103', '庐阳区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1150', '340104', '蜀山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1151', '340111', '包河区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1152', '340121', '长丰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1153', '340122', '肥东县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1154', '340123', '肥西县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1155', '340200', '芜湖市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1156', '340201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1157', '340202', '镜湖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2996', '532532', '河口瑶族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2997', '532600', '文山壮族苗族自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2998', '532621', '文山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2999', '532622', '砚山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3000', '532623', '西畴县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3001', '532624', '麻栗坡县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3002', '532625', '马关县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3003', '532626', '丘北县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3004', '532627', '广南县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3005', '532628', '富宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3006', '532800', '西双版纳傣族自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3007', '532801', '景洪市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3008', '532822', '勐海县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3009', '532823', '勐腊县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3010', '532900', '大理白族自治州', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3542', '654201', '塔城市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3543', '654202', '乌苏市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3544', '654221', '额敏县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3545', '654223', '沙湾县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3546', '654224', '托里县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3547', '654225', '裕民县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3548', '654226', '和布克赛尔蒙古自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3549', '654300', '阿勒泰地区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3550', '654301', '阿勒泰市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3551', '654321', '布尔津县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3552', '654322', '富蕴县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3553', '654323', '福海县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3554', '654324', '哈巴河县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3555', '654325', '青河县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3556', '654326', '吉木乃县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3557', '659000', '自治区直辖县级行政区划', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3558', '659001', '石河子市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3559', '659002', '阿拉尔市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3560', '659003', '图木舒克市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3561', '659004', '五家渠市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3562', '710000', '台湾省', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3563', '810000', '香港特别行政区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3564', '820000', '澳门特别行政区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2514', '469039', '省直辖县级行政单位中沙群岛的岛礁及其海域', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1558', '370501', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1559', '370502', '东营区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1560', '370503', '河口区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1561', '370521', '垦利县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1562', '370522', '利津县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1563', '370523', '广饶县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1564', '370600', '烟台市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1565', '370601', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1566', '370602', '芝罘区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1567', '370611', '福山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1568', '370612', '牟平区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1569', '370613', '莱山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1570', '370634', '长岛县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1571', '370681', '龙口市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1572', '370682', '莱阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1573', '370683', '莱州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1574', '370684', '蓬莱市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1575', '370685', '招远市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1576', '370686', '栖霞市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1577', '370687', '海阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1578', '370700', '潍坊市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1579', '370701', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1580', '370702', '潍城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1581', '370703', '寒亭区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1582', '370704', '坊子区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1583', '370705', '奎文区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1584', '370724', '临朐县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1585', '370725', '昌乐县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1586', '370781', '青州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1587', '370782', '诸城市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2401', '450502', '海城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2402', '450503', '银海区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2403', '450512', '铁山港区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2404', '450521', '合浦县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2405', '450600', '防城港市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2406', '450601', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2407', '450602', '港口区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2408', '450603', '防城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2409', '450621', '上思县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2410', '450681', '东兴市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2411', '450700', '钦州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2412', '450701', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2413', '450702', '钦南区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2414', '450703', '钦北区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2415', '450721', '灵山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2416', '450722', '浦北县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2417', '450800', '贵港市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2418', '450801', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2419', '450802', '港北区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2420', '450803', '港南区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2421', '450804', '覃塘区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2422', '450821', '平南县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2423', '450881', '桂平市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2424', '450900', '玉林市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2425', '450901', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2426', '450902', '玉州区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2427', '450903', '广西省玉林市福绵区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2428', '450921', '容县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2429', '450922', '陆川县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2430', '450923', '博白县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2431', '450924', '兴业县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2432', '450981', '北流市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2433', '451000', '百色市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2434', '451001', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2435', '451002', '右江区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2436', '451021', '田阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2437', '451022', '田东县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2438', '451023', '平果县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2439', '451024', '德保县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2440', '451025', '靖西县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2441', '451026', '那坡县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2442', '451027', '凌云县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2443', '451028', '乐业县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2444', '451029', '田林县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2445', '451030', '西林县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2446', '451031', '隆林各族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2447', '451100', '贺州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2448', '451101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2449', '451102', '八步区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2450', '451121', '昭平县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2451', '451122', '钟山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2452', '451123', '富川瑶族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2453', '451200', '河池市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2454', '451201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2455', '451202', '金城江区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2456', '451221', '南丹县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2457', '451222', '天峨县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2458', '451223', '凤山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2459', '451224', '东兰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2460', '451225', '罗城仫佬族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2461', '451226', '环江毛南族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2462', '451227', '巴马瑶族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2463', '451228', '都安瑶族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2464', '451229', '大化瑶族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2465', '451281', '宜州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2466', '451300', '来宾市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2467', '451301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2468', '451302', '兴宾区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2469', '451321', '忻城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2470', '451322', '象州县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2471', '451323', '武宣县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2472', '451324', '金秀瑶族自治县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2473', '451381', '合山市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2474', '451400', '崇左市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2475', '451401', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2476', '451402', '江洲区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2477', '451421', '扶绥县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2478', '451422', '宁明县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2479', '451423', '龙州县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2480', '451424', '大新县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('2481', '451425', '天等县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('320', '140822', '万荣县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1243', '341301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1244', '341302', '埇桥区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1245', '341321', '砀山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1246', '341322', '萧县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1247', '341323', '灵璧县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1248', '341324', '泗县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1249', '341400', '巢湖市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1250', '341401', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1251', '341402', '居巢区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1252', '341421', '庐江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1253', '341422', '无为县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1254', '341423', '含山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1255', '341424', '和县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1256', '341500', '六安市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1257', '341501', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1258', '341502', '金安区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1259', '341503', '裕安区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1260', '341521', '寿县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1261', '341522', '霍邱县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1262', '341523', '舒城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1263', '341524', '金寨县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1264', '341525', '霍山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1265', '341600', '亳州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1266', '341601', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1267', '341602', '谯城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1268', '341621', '涡阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1269', '341622', '蒙城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1270', '341623', '利辛县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1271', '341700', '池州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1272', '341701', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1273', '341702', '贵池区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1274', '341721', '东至县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1275', '341722', '石台县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1276', '341723', '青阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1277', '341800', '宣城市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1278', '341801', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1279', '341802', '宣州区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1280', '341821', '郎溪县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1281', '341822', '广德县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1282', '341823', '泾县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1283', '341824', '绩溪县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1284', '341825', '旌德县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1285', '341881', '宁国市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1286', '350000', '福建省', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1287', '350100', '福州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1288', '350101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1289', '350102', '鼓楼区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1290', '350103', '台江区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1291', '350104', '仓山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1292', '350105', '马尾区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1293', '350111', '晋安区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1294', '350121', '闽侯县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1295', '350122', '连江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1296', '350123', '罗源县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1297', '350124', '闽清县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1298', '350125', '永泰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1299', '350128', '平潭县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1300', '350181', '福清市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1301', '350182', '长乐市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1302', '350200', '厦门市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1303', '350201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1304', '350203', '思明区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1305', '350205', '海沧区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1306', '350206', '湖里区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1307', '350211', '集美区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1308', '350212', '同安区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1309', '350213', '翔安区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1310', '350300', '莆田市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1311', '350301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1312', '350302', '城厢区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1313', '350303', '涵江区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1314', '350304', '荔城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1315', '350305', '秀屿区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1316', '350322', '仙游县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1317', '350400', '三明市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1318', '350401', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1319', '350402', '梅列区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1320', '350403', '三元区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1321', '350421', '明溪县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1322', '350423', '清流县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1323', '350424', '宁化县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1324', '350425', '大田县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1325', '350426', '尤溪县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1326', '350427', '沙县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1327', '350428', '将乐县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1328', '350429', '泰宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1329', '350430', '建宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1330', '350481', '永安市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1331', '350500', '泉州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1332', '350501', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1333', '350502', '鲤城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1334', '350503', '丰泽区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1335', '350504', '洛江区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1336', '350505', '泉港区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1337', '350521', '惠安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1338', '350524', '安溪县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1339', '350525', '永春县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1340', '350526', '德化县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1341', '350527', '金门县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1342', '350581', '石狮市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1343', '350582', '晋江市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1344', '350583', '南安市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1345', '350600', '漳州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1346', '350601', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1347', '350602', '芗城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1348', '350603', '龙文区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1349', '350622', '云霄县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1350', '350623', '漳浦县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1351', '350624', '诏安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1352', '350625', '长泰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1353', '350626', '东山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1354', '350627', '南靖县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1355', '350628', '平和县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1356', '350629', '华安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1357', '350681', '龙海市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1358', '350700', '南平市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1359', '350701', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1360', '350702', '延平区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1361', '350721', '顺昌县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1362', '350722', '浦城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1363', '350723', '光泽县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('3541', '654200', '塔城地区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1364', '350724', '松溪县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1365', '350725', '政和县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1703', '410200', '开封市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1704', '410201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1705', '410202', '龙亭区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1706', '410203', '顺河回族区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1707', '410204', '鼓楼区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1708', '410205', '禹王台区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1709', '410211', '金明区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1710', '410221', '杞县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1711', '410222', '通许县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1712', '410223', '尉氏县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1713', '410224', '开封县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1714', '410225', '兰考县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1715', '410300', '洛阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1716', '410301', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1717', '410302', '老城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1718', '410303', '西工区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1719', '410304', '瀍河回族区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1720', '410305', '涧西区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1721', '410306', '吉利区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1722', '410311', '洛龙区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1723', '410322', '孟津县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1724', '410323', '新安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1725', '410324', '栾川县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1726', '410325', '嵩县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1727', '410326', '汝阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1728', '410327', '宜阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1729', '410328', '洛宁县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1730', '410329', '伊川县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1731', '410381', '偃师市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1732', '410400', '平顶山市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1733', '410401', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1734', '410402', '新华区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1735', '410403', '卫东区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1736', '410404', '石龙区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1737', '410411', '湛河区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1738', '410421', '宝丰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1739', '410422', '叶县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1740', '410423', '鲁山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1741', '410425', '郏县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1742', '410481', '舞钢市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1743', '410482', '汝州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1744', '410500', '安阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1745', '410501', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1746', '410502', '文峰区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1747', '410503', '北关区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1748', '410505', '殷都区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1749', '410506', '龙安区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1750', '410522', '安阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1751', '410523', '汤阴县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1752', '410526', '滑县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1753', '410527', '内黄县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1754', '410581', '林州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1755', '410600', '鹤壁市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1756', '410601', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1757', '410602', '鹤山区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1758', '410603', '山城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1759', '410611', '淇滨区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1760', '410621', '浚县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1761', '410622', '淇县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1762', '410700', '新乡市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1763', '410701', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1764', '410702', '红旗区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1765', '410703', '卫滨区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1766', '410704', '凤泉区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1767', '410711', '牧野区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1768', '410721', '新乡县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1769', '410724', '获嘉县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1770', '410725', '原阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1771', '410726', '延津县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1772', '410727', '封丘县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1773', '410728', '长垣县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1774', '410781', '卫辉市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1775', '410782', '辉县市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1776', '410800', '焦作市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1777', '410801', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1778', '410802', '解放区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1779', '410803', '中站区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1780', '410804', '马村区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1781', '410811', '山阳区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1782', '410821', '修武县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1783', '410822', '博爱县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1784', '410823', '武陟县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1785', '410825', '温县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1786', '410881', '焦作济源市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1787', '410882', '沁阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1788', '410883', '孟州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1789', '410900', '濮阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1790', '410901', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1791', '410902', '华龙区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1792', '410922', '清丰县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1793', '410923', '南乐县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1794', '410926', '范县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1795', '410927', '台前县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1796', '410928', '濮阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1797', '411000', '许昌市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1798', '411001', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1799', '411002', '魏都区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1800', '411023', '许昌县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1801', '411024', '鄢陵县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1802', '411025', '襄城县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1803', '411081', '禹州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1804', '411082', '长葛市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1805', '411100', '漯河市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1806', '411101', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1807', '411102', '源汇区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1808', '411103', '郾城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1809', '411104', '召陵区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1810', '411121', '舞阳县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1811', '411122', '临颍县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1812', '411200', '三门峡市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1813', '411201', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1814', '411202', '湖滨区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1815', '411221', '渑池县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1816', '411222', '陕县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1817', '411224', '卢氏县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1073', '330382', '乐清市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1074', '330400', '嘉兴市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1075', '330401', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1076', '330402', '南湖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1077', '330411', '秀洲区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1078', '330421', '嘉善县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1079', '330424', '海盐县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1080', '330481', '海宁市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1081', '330482', '平湖市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1082', '330483', '桐乡市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1083', '330500', '湖州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1084', '330501', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1085', '330502', '吴兴区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1086', '330503', '南浔区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1087', '330521', '德清县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1088', '330522', '长兴县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1089', '330523', '安吉县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1090', '330600', '绍兴市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1091', '330601', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1092', '330602', '越城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1093', '330621', '绍兴县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1094', '330624', '新昌县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1095', '330681', '诸暨市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1096', '330682', '上虞市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1097', '330683', '嵊州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1098', '330700', '金华市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1099', '330701', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1100', '330702', '婺城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1101', '330703', '金东区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1102', '330723', '武义县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1103', '330726', '浦江县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1104', '330727', '磐安县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1105', '330781', '兰溪市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1106', '330782', '义乌市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1107', '330783', '东阳市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1108', '330784', '永康市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1109', '330800', '衢州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1110', '330801', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1111', '330802', '柯城区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1112', '330803', '衢江区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1113', '330822', '常山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1114', '330824', '开化县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1115', '330825', '龙游县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1116', '330881', '江山市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1117', '330900', '舟山市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1118', '330901', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1119', '330902', '定海区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1120', '330903', '普陀区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1121', '330921', '岱山县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1122', '330922', '嵊泗县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1123', '331000', '台州市', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1124', '331001', '市辖区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1125', '331002', '椒江区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1126', '331003', '黄岩区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1127', '331004', '路桥区', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1128', '331021', '玉环县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1129', '331022', '三门县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1130', '331023', '天台县', null);

insert into B_SYS_REGION (ID, REGION_CODE, REGION_NAME, FULL_NAME)
values ('1131', '331024', '仙居县', null);

commit;
