﻿
insert into B_SYS_CHK_CNFG (CHK_IT_ID, REM, CLAZZ)
values ('CNFG201612230008', '检查担保合同信息完整性', 'ChkLnConGntyConCallServiceImpl');

insert into B_SYS_CHK_CNFG (CHK_IT_ID, REM, CLAZZ)
values ('CNFG201612150004', '检查业务申请产品信息', 'ChkPrdInfoCallServiceImpl');

insert into B_SYS_CHK_CNFG (CHK_IT_ID, REM, CLAZZ)
values ('CNFG201701090012', '检查出账模式', 'ChkDuebillAppCallServiceImpl');

insert into B_SYS_CHK_CNFG (CHK_IT_ID, REM, CLAZZ)
values ('CNFG201612090002', '检查客户综合授信唯一性', 'chkCusCreditLineCallServiceImpl');

insert into B_SYS_CHK_CNFG (CHK_IT_ID, REM, CLAZZ)
values ('CNFG201612300010', '检查冻结保证金列表是否为空', 'ChkMrnNullCallServiceImpl');

insert into B_SYS_CHK_CNFG (CHK_IT_ID, REM, CLAZZ)
values ('CNFG201612100003', '检查客户分项额度', 'chkSubCreditLineCallServiceImpl');

insert into B_SYS_CHK_CNFG (CHK_IT_ID, REM, CLAZZ)
values ('CNFG201612150005', '检查业务申请担保合同信息', 'ChkGntyConCallServiceImpl');

insert into B_SYS_CHK_CNFG (CHK_IT_ID, REM, CLAZZ)
values ('CNFG201612220007', '检查业务申请与担保合同类型一致性', 'ChkLnAppGntyConCallServiceImpl');

insert into B_SYS_CHK_CNFG (CHK_IT_ID, REM, CLAZZ)
values ('CNFG201612230009', '检查业务合同信息完整性', 'ChkLnConCallServiceImpl');

insert into B_SYS_CHK_CNFG (CHK_IT_ID, REM, CLAZZ)
values ('CNFG201701090014', '检查抵/质押合同是否补录成功', 'ChkGntyConAddCallServiceImpl');

insert into B_SYS_CHK_CNFG (CHK_IT_ID, REM, CLAZZ)
values ('CNFG201612150006', '检查业务申请担保物信息', 'ChkGntyInfoCallServiceImpl');

insert into B_SYS_CHK_CNFG (CHK_IT_ID, REM, CLAZZ)
values ('CNFG201705270033', '检查放款申请数据准确性', 'ChkFfkCallSerivceImpl');

insert into B_SYS_CHK_CNFG (CHK_IT_ID, REM, CLAZZ)
values ('CNFG201706070035', '应收类转让单据查重确保唯一', 'CheckZRdebtInfoCallServiceImpl');

insert into B_SYS_CHK_CNFG (CHK_IT_ID, REM, CLAZZ)
values ('CNFG201706150036', '检查应收账款催收申请信息完整性', 'ChkFPressCallSerivceImpl');

insert into B_SYS_CHK_CNFG (CHK_IT_ID, REM, CLAZZ)
values ('CNFG201706210037', '检查应收类业务申请文件完整性', 'ChkFAppliFileCallServiceImpl');

insert into B_SYS_CHK_CNFG (CHK_IT_ID, REM, CLAZZ)
values ('CNFG201705190032', '应收类业务校验', 'ChkFAppliCallSerivceImpl');

insert into B_SYS_CHK_CNFG (CHK_IT_ID, REM, CLAZZ)
values ('CNFG201706010034', '检查业务合同数据完整性', 'ChkFcntCallSerivceImpl');

insert into B_SYS_CHK_CNFG (CHK_IT_ID, REM, CLAZZ)
values ('CNFG201703030026', '检查出账模式	ChkDuebillAppCallServiceImpl', '检查出账模式	ChkDuebillAppCallServiceImpl');

insert into B_SYS_CHK_CNFG (CHK_IT_ID, REM, CLAZZ)
values ('CNFG201707180038', '检查池信息是否出现风险敞口', 'ChkPoolUseableAmountCallSerivceImpl');

commit;
