﻿
insert into B_CRR_PRD_MD (PRD_ID, PRD_NM, PRD_TYP, ADD_URL, UPD_URL, FIN_URL, STAT, TIT_NM, OBJ, PAGE_URL, TLR_NO, TLR_NM, BR_CD, BR_NM, INP_DT, LST_UPD_TLR, LST_UPD_TLR_NM, LST_UPD_BR_CD, LST_UPD_BR_NM, LST_UPD_DT, STATU, LOAN_WAY, IS_LIST)
values ('003', '信用证', 'lcinfo', 'bCrrLcInfoService/add', 'bCrrLcInfoService/update', 'bCrrLcInfoService/findBCrrLcInfoById', '1', '信用证信息', 'bCrrLcInfo', null, '008', 'meng', '101235456', '农商行', '20161201', '008', 'meng', '101235456', '农商行', '2016-12-20 20:38:58', '1', '06', '0');

insert into B_CRR_PRD_MD (PRD_ID, PRD_NM, PRD_TYP, ADD_URL, UPD_URL, FIN_URL, STAT, TIT_NM, OBJ, PAGE_URL, TLR_NO, TLR_NM, BR_CD, BR_NM, INP_DT, LST_UPD_TLR, LST_UPD_TLR_NM, LST_UPD_BR_CD, LST_UPD_BR_NM, LST_UPD_DT, STATU, LOAN_WAY, IS_LIST)
values ('01', '流贷', null, null, null, null, '0', null, null, null, '008', 'meng', '101235456', '农商行', '20161208', '008', 'meng', '101235456', '农商行', '2016-12-20 20:39:49', '1', '01', '0');

insert into B_CRR_PRD_MD (PRD_ID, PRD_NM, PRD_TYP, ADD_URL, UPD_URL, FIN_URL, STAT, TIT_NM, OBJ, PAGE_URL, TLR_NO, TLR_NM, BR_CD, BR_NM, INP_DT, LST_UPD_TLR, LST_UPD_TLR_NM, LST_UPD_BR_CD, LST_UPD_BR_NM, LST_UPD_DT, STATU, LOAN_WAY, IS_LIST)
values ('005', '发票', 'invinfo', 'bCrrInvInfoService/add', 'bCrrInvInfoService/update', 'bCrrInvInfoService/findBCrrInvInfoById', '1', '发票信息', 'bCrrInvInfo', 'bCrrInvInfoService/findBCrrInvInfoByPage', '008', 'meng', '101235456', '农商行', '20161201', '008', 'meng', '101235456', '农商行', '2016-12-20 20:39:42', '0', '00', '1');

insert into B_CRR_PRD_MD (PRD_ID, PRD_NM, PRD_TYP, ADD_URL, UPD_URL, FIN_URL, STAT, TIT_NM, OBJ, PAGE_URL, TLR_NO, TLR_NM, BR_CD, BR_NM, INP_DT, LST_UPD_TLR, LST_UPD_TLR_NM, LST_UPD_BR_CD, LST_UPD_BR_NM, LST_UPD_DT, STATU, LOAN_WAY, IS_LIST)
values ('004', '银承', 'billinfo', 'bCrrBillInfoService/add', 'bCrrBillInfoService/update', 'bCrrBillInfoService/findBCrrBillInfoById', '1', '银承信息', 'bCrrBillInfo', 'bCrrBillInfoService/findBCrrBillInfoByPage', '008', 'meng', '101235456', '农商行', '20161201', '008', 'meng', '101235456', '农商行', '2016-12-20 20:39:04', '1', '02', '1');

insert into B_CRR_PRD_MD (PRD_ID, PRD_NM, PRD_TYP, ADD_URL, UPD_URL, FIN_URL, STAT, TIT_NM, OBJ, PAGE_URL, TLR_NO, TLR_NM, BR_CD, BR_NM, INP_DT, LST_UPD_TLR, LST_UPD_TLR_NM, LST_UPD_BR_CD, LST_UPD_BR_NM, LST_UPD_DT, STATU, LOAN_WAY, IS_LIST)
values ('002', '设备', 'eqptinfo', 'bCrrEqptInfoService/add', 'bCrrEqptInfoService/update', 'bCrrEqptInfoService/findBCrrEqptInfoById', '1', '设备信息', 'bCrrEqptInfo', null, '008', 'meng', '101235456', '农商行', '20161201', '008', 'meng', '101235456', '农商行', '2016-12-20 20:38:50', '0', '03', '0');

insert into B_CRR_PRD_MD (PRD_ID, PRD_NM, PRD_TYP, ADD_URL, UPD_URL, FIN_URL, STAT, TIT_NM, OBJ, PAGE_URL, TLR_NO, TLR_NM, BR_CD, BR_NM, INP_DT, LST_UPD_TLR, LST_UPD_TLR_NM, LST_UPD_BR_CD, LST_UPD_BR_NM, LST_UPD_DT, STATU, LOAN_WAY, IS_LIST)
values ('123', '123', '123', '123', '123', '123', '1', '123', '123', '123', 'wbz', 'wbz', '100', '建设银行总行', '2017-07-21 10:09:09', 'wbz', 'wbz', '100', '建设银行总行', '2017-07-21 10:09:09', '1', '00', '1');

commit;
