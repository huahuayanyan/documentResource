﻿
insert into S_BCP_PRODUCT_BILL (PRODUCT_ID, BILL_TYPE)
values ('1201', '1');

insert into S_BCP_PRODUCT_BILL (PRODUCT_ID, BILL_TYPE)
values ('1202', '2');

commit;
